"""Cancelable diagnostics with a global deadline and privacy-safe results."""

import threading
import time

from resources.lib.flixtor import BASE


def run_checks(client, metadata_probe, voice_probe=None, allow_voice=lambda: True,
               cancelled=lambda: False, progress=lambda *_: None, timeout=30):
    deadline = time.monotonic() + timeout
    results = []
    session_ok = False

    def session():
        document = client._get(BASE + '/show/movies')
        if client._looks_like_auth_failure(document):
            return 'failed', 'Session expired. Open Account settings and sign in.'
        if 'showPageType' not in document or 'show-content' not in document:
            return 'failed', 'Unexpected account response. Check your connection and retry.'
        client._logged_in = True
        return 'passed', 'Account session is valid.'

    def catalog():
        first = client.browse_catalog('movies', sort='best', page=1)
        second = client.browse_catalog('movies', sort='best', page=2)
        if first.get('error') or second.get('error'):
            return 'failed', 'Catalog validation failed. Retry browsing; check Account settings if your session expired.'
        ids = lambda result: [(i['media_type'], i['pid']) for i in result['items']]
        if ids(first) == ids(second):
            return 'failed', 'Catalog repeated a page. Retry later or check for an add-on update.'
        return 'passed', 'Distinct catalog pages and categories validated.'

    def metadata():
        if metadata_probe():
            return 'passed', 'Metadata service is available.'
        return 'failed', 'Metadata unavailable. Basic browsing still works; retry later.'

    def voice():
        if not voice_probe or not allow_voice():
            return 'skipped', 'Companion check deferred during playback or unavailable on this platform.'
        result = voice_probe()
        if result.get('status') == 'ready':
            return 'passed', 'Companion connected (%s). Dictation still needs a New Search test.' % result.get('version_name', 'unknown version')
        return 'failed', 'Companion did not connect. Use Set up / update Alexa voice search.'

    for index, (name, check) in enumerate((('Account', session), ('Catalog', catalog), ('Metadata', metadata), ('Voice companion', voice))):
        if cancelled() or time.monotonic() >= deadline:
            results.append({'name': name, 'status': 'skipped', 'detail': 'Canceled or diagnostic time limit reached.'})
            continue
        if name == 'Catalog' and not session_ok:
            results.append({'name': name, 'status': 'skipped', 'detail': 'Restore the account connection first.'})
            continue
        progress(index * 25, name)
        done = threading.Event()
        answer = []

        def work(check=check, done=done, answer=answer):
            try:
                answer.append(check())
            except Exception:
                answer.append(('failed', 'Connection failed. Check your connection and retry.'))
            finally:
                done.set()

        threading.Thread(target=work, daemon=True).start()
        while not done.wait(0.05):
            if cancelled() or time.monotonic() >= deadline:
                break
        status, detail = answer[0] if done.is_set() else ('skipped', 'Canceled or diagnostic time limit reached.')
        results.append({'name': name, 'status': status, 'detail': detail})
        if name == 'Account':
            session_ok = status == 'passed'
    return results
