"""Structural checks for server-rendered catalog pages (no network or Kodi)."""

import re


def element_contents(document, element_id, attribute="id"):
    """Extract a complete div, excluding unrelated recommendations/navigation."""
    start = None
    for candidate in re.finditer(r'<div\b[^>]*>', document or '', re.I):
        value = re.search(r"\b" + attribute + r"\s*=\s*(['\"])(.*?)\1", candidate.group(), re.I)
        if value and (element_id in value.group(2).split() if attribute == 'class' else value.group(2) == element_id):
            start = candidate
            break
    if not start:
        return None
    depth = 1
    for tag in re.finditer(r'</?div\b[^>]*>', document[start.end():], re.I):
        depth += -1 if tag.group().startswith('</') else 1
        if depth == 0:
            return document[start.end():start.end() + tag.start()]
    return None


def page_identity(content, attr):
    pages, active = [], []
    for tag in re.findall(r'<[^>]+>', content or ''):
        classes = attr(tag, 'class').split()
        value = attr(tag, 'data-p')
        if 'searchnav' in classes and value.isdigit():
            pages.append(int(value))
            if 'font-weight-bold' in classes or 'active' in classes:
                active.append(int(value))
    return (active[0] if len(set(active)) == 1 else None), max(pages or [1])


def validate_catalog(document, kind, sort, page, attr):
    kind_match = re.search(r'\bshowPageType\s*=\s*[\"\']([^\"\']+)', document or '')
    content = element_contents(document, 'show-content')
    if not kind_match or kind_match.group(1) != kind or content is None:
        return None
    sorts = [attr(tag, 'data-s') for tag in re.findall(r'<[^>]+>', content)
             if 'active' in attr(tag, 'class').split() and attr(tag, 'data-s')]
    active, total = page_identity(content, attr)
    # A genuinely single-page catalog may omit its pager entirely.
    if active is None and 'searchnav' not in content:
        active = 1
    if sorts != [sort] or active != page or total < page:
        return None
    return content, total


def has_empty_results(content):
    visible = re.sub(r'<[^>]*>', ' ', content or '')
    return bool(re.search(r'\b(?:no\s+(?:search\s+)?results|no\s+matches|nothing\s+found|no\s+(?:movies|shows|titles)\s+found)\b', visible, re.I))
