"""Validated local library backup and recoverable, merging restoration."""

import json
import math
import os
import time
import uuid

from resources.lib.storage import atomic_json, profile_lock, read_json, recover_library

MAX_BACKUP_BYTES = 10 * 1024 * 1024
FIELDS = {'pid', 'title', 'slug', 'media_type', 'poster', 'year', 'rating',
          'rating_provider', 'genres', 'timestamp', 'season', 'episode',
          'resume_seconds', 'total_seconds', 'completed', 'quality', 'up_next'}


def _record(value, history=False):
    if not isinstance(value, dict):
        raise ValueError('Invalid library record')
    record = {k: v for k, v in value.items() if k in FIELDS}
    if isinstance(record.get('pid'), bool) or not isinstance(record.get('pid'), (str, int)) or not str(record['pid']).strip():
        raise ValueError('Missing content identity')
    record['pid'] = str(record['pid'])
    if record.get('media_type') not in ('movie', 'tv'):
        raise ValueError('Invalid media type')
    for key in ('timestamp', 'resume_seconds', 'total_seconds'):
        if key in record:
            number = record[key]
            if isinstance(number, bool) or not isinstance(number, (float, int)) or not math.isfinite(number) or number < 0:
                raise ValueError('Invalid playback position or timestamp')
    for key in ('completed', 'up_next'):
        if key in record and not isinstance(record[key], bool):
            raise ValueError('Invalid completion state')
    for key in ('season', 'episode'):
        if key in record and record[key] is not None:
            if isinstance(record[key], bool) or not str(record[key]).isdigit():
                raise ValueError('Invalid episode identity')
            record[key] = int(record[key])
    if history and record.get('season') is not None and record.get('episode') is None:
        raise ValueError('Missing episode identity')
    if history and record.get('episode') is not None and record.get('season') is None:
        raise ValueError('Missing season identity')
    year = str(record.get('year') or '')
    if year and (len(year) != 4 or not year.isdigit()):
        raise ValueError('Invalid release year')
    if record.get('rating') not in (None, ''):
        try:
            rating = float(record['rating'])
        except (ValueError, TypeError):
            raise ValueError('Invalid rating') from None
        if not math.isfinite(rating) or not 0 <= rating <= 10:
            raise ValueError('Invalid rating')
    for key, value in record.items():
        if key not in {'timestamp', 'resume_seconds', 'total_seconds', 'completed', 'up_next', 'season', 'episode'}:
            if not isinstance(value, (str, int, float)) or len(str(value)) > 4096:
                raise ValueError('Invalid content details')
    if record.get('completed') is True and record.get('resume_seconds', 0) > 0:
        raise ValueError('Completed records cannot have an active resume position')
    if record.get('total_seconds', 0) > 0 and record.get('resume_seconds', 0) > record['total_seconds']:
        raise ValueError('Resume position exceeds duration')
    return record


def _snapshot(folder):
    favorites = read_json(os.path.join(folder, 'favorites.json'), [])
    history = read_json(os.path.join(folder, 'watch_history.json'), [])
    if not isinstance(favorites, list) or not isinstance(history, list):
        raise ValueError('Invalid local library; it has been preserved')
    return {'schema_version': 1, 'created_at': time.time(),
            'favorites': [_record(r) for r in favorites],
            'watch_history': [_record(r, True) for r in history]}


def export_library(folder):
    with profile_lock(folder):
        recover_library(folder)
        return json.dumps(_snapshot(folder), ensure_ascii=False, allow_nan=False).encode('utf-8')


def validate_backup(payload):
    if len(payload) > MAX_BACKUP_BYTES:
        raise ValueError('Backup exceeds 10 MB')
    data = json.loads(payload)
    if not isinstance(data, dict) or type(data.get('schema_version')) is not int or data['schema_version'] != 1:
        raise ValueError('Unsupported backup version')
    for key in ('favorites', 'watch_history'):
        if not isinstance(data.get(key), list):
            raise ValueError('Missing library data')
        data[key] = [_record(r, key == 'watch_history') for r in data[key]]
    return data


def restore_library(folder, payload):
    from resources.lib.watchhistory import _record_key, MAX_HISTORY
    incoming = validate_backup(payload)  # validate everything before any write
    with profile_lock(folder):
        recover_library(folder)
        local = _snapshot(folder)
        before = {name: read_json(os.path.join(folder, name + '.json'), [])
                  for name in ('favorites', 'watch_history')}
        favorites = {str(r['pid']): r for r in before['favorites']}
        for record in incoming['favorites']:
            favorites.setdefault(record['pid'], record)
        history = {_record_key(r): r for r in before['watch_history']}
        for record in incoming['watch_history']:
            key = _record_key(record)
            if key not in history or record.get('timestamp', 0) > history[key].get('timestamp', 0):
                history[key] = record
        records = sorted(history.values(), key=lambda r: r.get('timestamp', 0), reverse=True)[:MAX_HISTORY]
        backup = os.path.join(folder, 'backups', 'before-restore-' + uuid.uuid4().hex + '.json')
        atomic_json(backup, local)
        journal = os.path.join(folder, 'library_restore.journal.json')
        atomic_json(journal, before)
        try:
            atomic_json(os.path.join(folder, 'favorites.json'), list(favorites.values()))
            atomic_json(os.path.join(folder, 'watch_history.json'), records)
            os.remove(journal)
        except Exception:
            recover_library(folder)
            raise
        return {'favorites': len(favorites), 'watch_history': len(records), 'backup': backup}
