"""Pure helpers for Flixtor Home-screen widget routes.

Skins load widgets in the background on the Home window. These routes must
never open dialogs, prompt for login, or change Flixtor's navigation state,
so only plain listing routes are allowed.
"""

WIDGET_ACTION_PREFIX = "widget_"
WIDGET_BASE_ROUTES = frozenset({
    "home",
    "recent",
    "favorites",
    "movies_latest",
    "movies_new",
    "movies_best",
    "tvshows_latest",
    "tvshows_new",
    "tvshows_best",
})


def is_widget_action(action):
    """Whether the action belongs to the quiet widget namespace."""
    return str(action or "").startswith(WIDGET_ACTION_PREFIX)


def widget_base_route(action):
    """Return the allowed listing route behind a widget action, or None."""
    if not is_widget_action(action):
        return None
    base = str(action)[len(WIDGET_ACTION_PREFIX):]
    return base if base in WIDGET_BASE_ROUTES else None
