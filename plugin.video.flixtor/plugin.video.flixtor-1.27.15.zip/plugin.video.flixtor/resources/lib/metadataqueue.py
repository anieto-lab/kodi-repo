"""Bounded, deduplicated metadata work owned by the resident Kodi service."""

import json
import os
import sqlite3
import threading
import time


def _connect(folder):
    os.makedirs(folder, exist_ok=True)
    connection = sqlite3.connect(os.path.join(folder, 'tmdb_jobs.sqlite'), timeout=0.2)
    connection.execute('CREATE TABLE IF NOT EXISTS jobs (key TEXT PRIMARY KEY, payload TEXT, due REAL, expires REAL)')
    return connection


def enqueue(folder, requests):
    now = time.time()
    connection = _connect(folder)
    try:
        with connection:
            connection.execute('DELETE FROM jobs WHERE expires < ?', (now,))
            for key, title, year, media_type in requests:
                connection.execute('INSERT OR IGNORE INTO jobs SELECT ?,?,?,? WHERE (SELECT count(*) FROM jobs) < 256',
                                   (key, json.dumps([title, year, media_type]), now, now + 900))
    finally:
        connection.close()


def _claim(folder):
    connection = _connect(folder)
    try:
        connection.execute('BEGIN IMMEDIATE')
        now = time.time()
        connection.execute('DELETE FROM jobs WHERE expires < ?', (now,))
        row = connection.execute('SELECT key,payload FROM jobs WHERE due <= ? ORDER BY due LIMIT 1', (now,)).fetchone()
        if row:
            connection.execute('UPDATE jobs SET due=? WHERE key=?', (now + 30, row[0]))
        connection.commit()
        return (row[0], json.loads(row[1])) if row else None
    finally:
        connection.close()


class MetadataWorkers:
    def __init__(self, folder, can_run):
        self.folder = folder
        self.can_run = can_run
        self.stopped = threading.Event()
        self.threads = [threading.Thread(target=self._run, daemon=True, name='FlixtorMetadata') for _ in range(4)]

    def start(self):
        for thread in self.threads:
            thread.start()

    def close(self):
        self.stopped.set()

    def _run(self):
        from resources.lib.tmdb import TmdbClient, _entry_is_usable
        while not self.stopped.wait(0.1):
            try:
                if not self.can_run():
                    continue
                job = _claim(self.folder)
                if not job:
                    self.stopped.wait(0.2)
                    continue
                key, args = job
                if not self.can_run():
                    continue
                client = TmdbClient()
                client.lookup_info(*args)
                success = _entry_is_usable(client._mem_cache.get(key))
                connection = _connect(self.folder)
                try:
                    with connection:
                        if success:
                            connection.execute('DELETE FROM jobs WHERE key=?', (key,))
                        else:
                            connection.execute('UPDATE jobs SET due=? WHERE key=?', (time.time() + 60, key))
                finally:
                    connection.close()
            except Exception:
                # Optional enrichment must never terminate playback monitoring.
                self.stopped.wait(1)
