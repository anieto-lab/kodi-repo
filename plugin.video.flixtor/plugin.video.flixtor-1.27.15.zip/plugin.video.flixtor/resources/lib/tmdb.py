"""TMDb v3 search client — resolves Flixtor (title, year, media_type) → TMDb ID.

The addon attaches the resulting ID to every ListItem via ``setUniqueIDs``. Arctic
Horizon 2's rating strip (IMDb / TMDb / Metacritic / RT / Popcorn / Letterboxd)
is populated by TMDb Helper's service monitor reading ``Container(99950)``, and
TMDb Helper needs a ``uniqueid.tmdb`` or ``uniqueid.imdb`` on the focused item to
enrich it. Flixtor's HTML exposes neither, so this module looks them up and
caches to disk (TTL'd by cachemaint: hits 90d, misses 30d, 4000-entry cap).

Since the search response already carries them, entries also store ``plot``
(overview), ``backdrop`` (path; full URL via ``fanart_url()``), and ``vote`` —
zero extra API calls — so every ListItem gets a synopsis, real landscape
fanart, and a rating fallback for titles Flixtor serves without one.

Zero external dependencies — Python standard library only.
"""

import json
import math
import os
import re
import socket
import sqlite3
import time
from resources.lib.storage import atomic_json, read_json, profile_lock
from resources.lib.metadataqueue import enqueue
import urllib.error
import urllib.parse
import urllib.request

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon

    def _log(msg):
        xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)

    def _cache_path():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        d = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return os.path.join(d, "tmdb_cache.json")

    def _get_user_api_key():
        try:
            return (xbmcaddon.Addon("plugin.video.flixtor").getSetting("tmdb_api_key") or "").strip()
        except Exception:
            return ""
except ImportError:
    def _log(msg):
        print("FLIXTOR: " + msg)

    def _cache_path():
        d = os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata")
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return os.path.join(d, "tmdb_cache.json")

    def _get_user_api_key():
        return ""


TMDB_API = "https://api.themoviedb.org/3"

# Widely-known public TMDb v3 read key shipped with TMDb Helper. Read-only usage
# (search + metadata fetch) is covered by TMDb's API terms for free tier. If
# revoked, the addon silently degrades — lookups return None and the rating strip
# stays empty (today's behavior). Users can override via the settings key
# `tmdb_api_key` in Settings > Account.
_DEFAULT_TMDB_KEY = "a07324c669cac4d96789197134ce272b"

_SEARCH_TIMEOUT = 3  # one slow lookup must not stall the page render long
_UA = "plugin.video.flixtor/1 (Kodi)"

TMDB_IMG_BASE = "https://image.tmdb.org/t/p"


def fanart_url(backdrop_path):
    """Full TMDb backdrop URL for a stored path ('' for falsy)."""
    if not backdrop_path:
        return ""
    return "%s/w1280%s" % (TMDB_IMG_BASE, backdrop_path)


def _entry_is_usable(cached):
    """A cache entry is servable if it's a miss marker or a v2 hit.
    Legacy id-only entries (pre-1.24.0, no 'plot' key) count as absent so
    they progressively re-resolve with plot/backdrop/vote attached."""
    if not isinstance(cached, dict):
        return False
    return cached.get("generation") == 3 and (bool(cached.get("miss")) or "plot" in cached)

# Non-identifying punctuation stripped when normalizing titles for the cache
# key. Keeps unicode letters (é, ñ, ö, etc.) so cache keys round-trip cleanly.
_NORMALIZE_STRIP = re.compile(r"[^\w\s]", re.UNICODE)


def _normalize_title(title):
    if not title:
        return ""
    return _NORMALIZE_STRIP.sub("", title).lower().strip()


def _cache_key(title, year, media_type):
    return "|".join((_normalize_title(title), str(year or ""), media_type or ""))


class TmdbClient:
    def __init__(self):
        self._mem_cache = None
        self._loaded = False
        self._pending_entries = {}
        self._api_key = _get_user_api_key() or _DEFAULT_TMDB_KEY

    # ── Cache I/O ────────────────────────────────────────────────────

    def _ensure_loaded(self):
        if self._loaded:
            return
        self._loaded = True
        try:
            with open(_cache_path(), "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                self._mem_cache = data
                return
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        self._mem_cache = {}

    def _save(self):
        if not self._pending_entries:
            return
        path = _cache_path()
        with profile_lock(os.path.dirname(path)):
            try:
                current = read_json(path, {})
            except (ValueError, OSError):
                current = {}
            if not isinstance(current, dict):
                current = {}
            current.update(self._pending_entries)
            atomic_json(path, current)
            self._mem_cache = current
            self._pending_entries.clear()

    def clear_cache(self):
        self._mem_cache = {}
        self._pending_entries = {}
        self._loaded = True
        path = _cache_path()
        with profile_lock(os.path.dirname(path)):
            atomic_json(path, {})

    # ── Public lookup API ────────────────────────────────────────────

    @staticmethod
    def _apply_entry(item, entry):
        """Mutate an item dict with the fields a cache entry provides."""
        if not entry or entry.get("miss"):
            item["tmdb_id"] = None
            item["tmdb_plot"] = ""
            item["tmdb_fanart"] = ""
            item["tmdb_vote"] = 0.0
            return
        item["tmdb_id"] = entry.get("tmdb_id") or None
        item["tmdb_plot"] = entry.get("plot") or ""
        item["tmdb_fanart"] = fanart_url(entry.get("backdrop") or "")
        item["tmdb_vote"] = entry.get("vote") or 0.0

    def lookup_info(self, title, year, media_type):
        """Full cached TMDb info for (title, year, media_type):
        ``{"tmdb_id", "plot", "fanart", "vote"}`` with empty values when
        unknown. Caches hits and genuine no-result misses ("ts" feeds
        cachemaint's TTLs: hits 90d, misses 30d). Network errors are NOT
        cached — a transient timeout must not blank the rating strip for
        a month. media_type must be "movie" or "tv".
        """
        out = {"tmdb_id": None, "plot": "", "fanart": "", "vote": 0.0}
        if not title or media_type not in ("movie", "tv") or not self._api_key:
            return out
        key = _cache_key(title, year, media_type)
        self._ensure_loaded()
        cached = self._mem_cache.get(key)
        if not _entry_is_usable(cached):
            result = self._search_online(title, year, media_type)
            if result is None:  # network error — serve empty, don't cache
                return out
            if result:
                cached = dict(result, ts=int(time.time()), generation=3)
            else:
                cached = {"miss": True, "ts": int(time.time()), "generation": 3}
            self._mem_cache[key] = cached
            self._pending_entries[key] = cached
            self._save()
        if cached.get("miss"):
            return out
        out["tmdb_id"] = cached.get("tmdb_id") or None
        out["plot"] = cached.get("plot") or ""
        out["fanart"] = fanart_url(cached.get("backdrop") or "")
        out["vote"] = cached.get("vote") or 0.0
        return out

    def lookup(self, title, year, media_type):
        """Back-compat shim: just the TMDb integer id (or None)."""
        return self.lookup_info(title, year, media_type)["tmdb_id"]

    def lookup_cached_info(self, title, year, media_type):
        item = {"title": title, "year": year, "media_type": media_type}
        self.lookup_many([item], budget=0)
        return {"tmdb_id": item.get("tmdb_id"), "plot": item.get("tmdb_plot", ""),
                "fanart": item.get("tmdb_fanart", ""), "vote": item.get("tmdb_vote", 0)}

    def lookup_many(self, items, budget=2.0, stop_requested=None):
        """One foreground deadline; the resident service finishes outstanding jobs."""
        deadline = time.monotonic() + max(0.0, min(2.0, budget))
        if not items:
            return items
        self._loaded = False
        self._ensure_loaded()
        requests = []
        for item in items:
            title, year, media = item.get("title", ""), item.get("year", ""), item.get("media_type", "movie")
            key = _cache_key(title, year, media)
            if title and self._api_key and media in ("movie", "tv") and not _entry_is_usable(self._mem_cache.get(key)):
                requests.append((key, title, year, media))
        if requests:
            try:
                enqueue(os.path.dirname(_cache_path()), requests)
            except (OSError, sqlite3.Error):
                pass  # the listing remains useful if optional cache work fails
        while requests and time.monotonic() < deadline:
            if stop_requested and stop_requested():
                break
            self._loaded = False
            self._ensure_loaded()
            if all(_entry_is_usable(self._mem_cache.get(r[0])) for r in requests):
                break
            time.sleep(min(0.05, max(0, deadline - time.monotonic())))
        for item in items:
            entry = self._mem_cache.get(_cache_key(item.get("title", ""), item.get("year", ""), item.get("media_type", "movie")))
            self._apply_entry(item, entry if _entry_is_usable(entry) else None)
        return items

    # ── Network ──────────────────────────────────────────────────────

    def _search_online(self, title, year, media_type):
        """One TMDb search call. Returns:

        - ``{tmdb_id, plot, backdrop, vote}`` on a hit
        - ``{}`` when TMDb genuinely has no results (cacheable miss)
        - ``None`` on a network/parse error (transient — must NOT be cached)
        """
        params = {
            "api_key": self._api_key,
            "query": title,
            "include_adult": "false",
            "language": "en-US",
        }
        if year:
            if media_type == "movie":
                params["year"] = str(year)
            else:
                params["first_air_date_year"] = str(year)
        url = "%s/search/%s?%s" % (TMDB_API, media_type, urllib.parse.urlencode(params))
        req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=_SEARCH_TIMEOUT) as resp:
                payload = json.loads(resp.read(2 * 1024 * 1024 + 1).decode("utf-8"))
        except (urllib.error.URLError, socket.timeout, ValueError) as exc:
            _log("tmdb: search request failed (%s)" % media_type)
            return None
        if not isinstance(payload, dict) or not isinstance(payload.get("results"), list):
            return None
        results = payload["results"]
        if not results:
            return {}
        wanted = _normalize_title(title)
        matches = []
        for candidate in results:
            if not isinstance(candidate, dict):
                return None
            names = (candidate.get("title"), candidate.get("original_title"),
                     candidate.get("name"), candidate.get("original_name"))
            released = candidate.get("release_date" if media_type == "movie" else "first_air_date") or ""
            if wanted not in {_normalize_title(name) for name in names if isinstance(name, str)}:
                continue
            if not isinstance(released, str) or not year or released[:4] != str(year):
                continue
            if candidate.get("media_type", media_type) != media_type:
                continue
            matches.append(candidate)
        if len(matches) != 1:
            return {}
        top = matches[0]
        try:
            tmdb_id = int(top.get("id") or 0)
        except (TypeError, ValueError):
            tmdb_id = 0
        if tmdb_id <= 0:
            return {}
        try:
            vote = round(float(top.get("vote_average") or 0), 1)
        except (TypeError, ValueError):
            vote = 0.0
        if not math.isfinite(vote):
            vote = 0.0
        plot = top.get("overview")
        backdrop = top.get("backdrop_path")
        return {
            "tmdb_id": tmdb_id,
            "plot": plot.strip() if isinstance(plot, str) else "",
            "backdrop": backdrop if isinstance(backdrop, str) else "",
            "vote": vote,
        }
