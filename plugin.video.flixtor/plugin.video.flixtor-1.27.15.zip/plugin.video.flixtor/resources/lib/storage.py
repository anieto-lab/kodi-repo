"""Cross-process JSON updates for Kodi's independent plugin/service instances."""

from contextlib import contextmanager
import json
import os
import sqlite3
import tempfile
import threading

_local = threading.local()


def read_json(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as source:
            return json.load(source)
    except FileNotFoundError:
        return default
    # Corruption and permission failures must not silently overwrite user data.


def atomic_json(path, value):
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.flixtor-', suffix='.tmp', dir=folder)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as output:
            json.dump(value, output, ensure_ascii=False, allow_nan=False)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


@contextmanager
def profile_lock(folder):
    """SQLite supplies crash-safe, OS-released locks on Windows and Android."""
    folder = os.path.abspath(folder)
    held = getattr(_local, 'held', {})
    if folder in held:
        yield
        return
    os.makedirs(folder, exist_ok=True)
    connection = sqlite3.connect(os.path.join(folder, 'state-lock.sqlite'), timeout=2)
    try:
        connection.execute('BEGIN IMMEDIATE')
        held[folder] = connection
        _local.held = held
        yield
        connection.commit()
    finally:
        held.pop(folder, None)
        connection.close()


def recover_library(folder):
    """Called under the profile lock before reading or changing either store."""
    journal = os.path.join(folder, 'library_restore.journal.json')
    before = read_json(journal)
    if before is not None:
        for name in ('favorites', 'watch_history'):
            atomic_json(os.path.join(folder, name + '.json'), before[name])
        os.remove(journal)
