"""Flixtor Kodi addon — browse, search, and stream movies/TV from Flixtor VIP."""

import base64
import hashlib
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import xbmc
from resources.lib import cachemaint
from resources.lib import voicebridge
from resources.lib.flixtor import FlixtorClient, _cookie_path, _api_cache_path
from resources.lib.kodiui import set_parent_folder_items
from resources.lib.navigation import (
    AH2_DETAILS_CONTROL_IDS,
    ROOT_EXIT_ALLOW_PROPERTY,
    ROOT_ROUTE_PROPERTY,
    canonical_show_title,
    collapse_recent_items,
    select_flixtor_match,
    should_guard_flixtor_root_back,
    should_open_one_press_details,
)
from resources.lib.subtitles import webvtt_to_srt
from resources.lib.tmdb import TmdbClient
from resources.lib.watchhistory import (
    WatchHistory, SearchHistory, FavoritesHistory,
    _make_key as _watch_key, _record_key as _watch_record_key,
)

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
PAGE_SIZE = 24
CONTINUE_WATCHING_MAX = 2  # distinct titles shown in the Continue Watching band
NEXT_PAGE_ICON = "special://home/addons/plugin.video.flixtor/resources/media/next.png"
CARD_ART_BASE = "special://home/addons/plugin.video.flixtor/resources/media/cards"
ACTIVE_SEARCH_QUERY_PROPERTY = "Flixtor.ActiveSearchQuery"


def _card_art(slug):
    """Return setArt() dict for a bundled card image. AH2 picks different art
    types per view (icon/thumb/poster/landscape), so set them all to the same
    image to ensure the card image renders regardless of the active view."""
    path = "%s/%s.jpg" % (CARD_ART_BASE, slug)
    return {
        "icon": path, "thumb": path, "poster": path,
        "landscape": path, "fanart": path,
    }


# Genre-name → card slug. Movie and TV genre lists differ but several share a
# concept (Movies "Action" + TV "Action-Adventure" → genre_action), so the map
# folds aliases onto a single slug to keep the card-image set small.
_GENRE_CARD_SLUGS = {
    "Action": "genre_action", "Action-Adventure": "genre_action",
    "Adventure": "genre_adventure",
    "Animation": "genre_animation",
    "Comedy": "genre_comedy",
    "Crime": "genre_crime",
    "Documentary": "genre_documentary",
    "Drama": "genre_drama",
    "Family": "genre_family",
    "Fantasy": "genre_fantasy",
    "History": "genre_history",
    "Horror": "genre_horror",
    "Kids": "genre_kids",
    "Music": "genre_music",
    "Musical": "genre_musical",
    "Mystery": "genre_mystery",
    "News": "genre_news",
    "Reality": "genre_reality",
    "Romance": "genre_romance",
    "Science-Fiction": "genre_scifi", "Sci-Fi-Fantasy": "genre_scifi",
    "Soap": "genre_soap",
    "Talk": "genre_talk",
    "Thriller": "genre_thriller",
    "TV-Movie": "genre_tvmovie",
    "War": "genre_war", "War-Politics": "genre_war",
    "Western": "genre_western",
}
_OBF_PREFIX = "__obf1__"

_client = None
_tmdb = None
_has_youtube_cached = None
_device_key_cached = None


def _rating_enrichment_enabled():
    """True unless the user disabled the rating-strip TMDb lookup in Settings."""
    return ADDON.getSetting("rating_enrichment") != "false"


def _get_tmdb():
    """Lazy TmdbClient singleton. Returns None when enrichment is disabled so
    callers can skip lookups without additional conditionals."""
    global _tmdb
    if not _rating_enrichment_enabled():
        return None
    if _tmdb is None:
        _tmdb = TmdbClient()
    return _tmdb


def _attach_tmdb_id(li, tmdb_id):
    """Set uniqueid.tmdb on a ListItem so TMDb Helper's service monitor can
    enrich container 99950 (powers AH2's rating strip). No-op on falsy ids."""
    if not tmdb_id:
        return
    try:
        li.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
    except Exception as exc:
        _log("tmdb: setUniqueIDs failed: %s" % exc)


_favorites_pid_cache = None


def _favorites_pid_set():
    """Lazily load the favorited pid set for this plugin process. Avoids
    re-reading favorites.json for every item in a directory listing."""
    global _favorites_pid_cache
    if _favorites_pid_cache is None:
        _favorites_pid_cache = {
            str(i.get("pid", "")) for i in FavoritesHistory().get_all()
        }
    return _favorites_pid_cache


def _favorites_context_item(pid, item_payload=None):
    """Return a (label, RunPlugin(...)) context menu tuple that toggles
    between adding and removing from the addon's Favorites depending on
    current state. ``item_payload`` is the dict of fields to persist on add
    (title, slug, poster, etc.); only the pid is needed for remove."""
    pid_str = str(pid)
    if pid_str in _favorites_pid_set():
        return (
            "Remove from Favorites",
            "RunPlugin(%s)" % build_url("ctx_remove_favorite", pid=pid_str),
        )
    payload = dict(item_payload or {})
    payload["pid"] = pid_str
    return (
        "Add to Favorites",
        "RunPlugin(%s)" % build_url("ctx_add_favorite", **payload),
    )


def _prefetch_tmdb(items):
    """Batch-resolve TMDb info for a list of item dicts. Mutates each item
    with ``tmdb_id``/``tmdb_plot``/``tmdb_fanart``/``tmdb_vote`` keys.
    No-op when enrichment is disabled."""
    client = _get_tmdb()
    if client and items:
        client.lookup_many(items)


_watch_state_cache = None


def _watch_state():
    """Lazily-loaded watch-history map for this plugin process:
    record key (pid, or (pid, season, episode)) → record. One file read
    per process so every listing can show native watched ticks/progress."""
    global _watch_state_cache
    if _watch_state_cache is None:
        _watch_state_cache = {
            _watch_record_key(rec): rec
            for rec in WatchHistory().get_recent(limit=50)
            if rec.get("pid")
        }
    return _watch_state_cache


def _apply_watch_state(li, info, pid, season=None, episode=None):
    """Decorate a ListItem with the user's watch state: completed items get
    ``playcount`` (Kodi's native watched tick), partials get ResumeTime/
    TotalTime (native progress bar). Mutates ``info`` — call before
    li.setInfo()."""
    rec = _watch_state().get(_watch_key(pid, season, episode))
    if not rec:
        return
    resume = rec.get("resume_seconds") or 0
    total = rec.get("total_seconds") or 0
    if resume > 0 and total > 0:
        li.setProperty("ResumeTime", str(resume))
        li.setProperty("TotalTime", str(total))
    elif total > 0:
        # resume_seconds == 0 with a recorded duration means played to the end
        info["playcount"] = 1


def _log(msg):
    xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)


def _has_youtube():
    """Cached check for the YouTube plugin. Re-evaluated per plugin process."""
    global _has_youtube_cached
    if _has_youtube_cached is None:
        _has_youtube_cached = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.youtube)"
        ) == 1
    return _has_youtube_cached


def _device_key():
    """Stable per-device key derived from MAC address. Used for password obfuscation."""
    global _device_key_cached
    if _device_key_cached is None:
        _device_key_cached = hashlib.sha256(str(uuid.getnode()).encode()).digest()
    return _device_key_cached


def _legacy_deobfuscate(b64):
    """Best-effort reverse of the legacy v1.10-v1.13.x obfuscation. Returns '' on
    any decoding error. Kept only for one-shot migration away from the obfuscated
    form — the new code stores passwords as plaintext (masked in the UI via
    option='hidden'). The obfuscation used `uuid.getnode()` as its key, which on
    Fire TV falls back to a RANDOM value per plugin process when the Android
    sandbox blocks MAC discovery, silently corrupting the stored password."""
    if not b64:
        return ""
    try:
        xored = base64.b64decode(b64.encode("ascii"))
    except Exception:
        return ""
    key = _device_key()
    raw = bytes(b ^ key[i % len(key)] for i, b in enumerate(xored))
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return ""


def _read_password():
    """Read the VIP password from settings.

    Legacy obfuscated values (prefixed with `__obf1__`, written by v1.10-v1.13.x)
    are best-effort recovered and rewritten as plaintext. If recovery fails —
    likely because `uuid.getnode()` returned a different value than when the
    password was encoded — the setting is cleared to force a single re-auth.
    """
    raw = ADDON.getSetting("password") or ""
    if raw.startswith(_OBF_PREFIX):
        decoded = _legacy_deobfuscate(raw[len(_OBF_PREFIX):])
        # Sanity check: a real password is non-empty printable ASCII. Deobfuscation
        # with a mismatched key yields non-printable byte garbage that may still
        # pass the UTF-8 decode in _legacy_deobfuscate.
        if decoded and all(32 <= ord(c) < 127 for c in decoded):
            _log("password: migrated legacy obfuscated value to plaintext")
            ADDON.setSetting("password", decoded)
            return decoded
        _log("password: legacy obfuscated value unrecoverable; clearing (re-auth required)")
        ADDON.setSetting("password", "")
        return ""
    return raw


def _show_qr_dialog():
    """Show a fullscreen dialog with the QR code for flixtor.to/donate."""
    qr_path = os.path.join(ADDON.getAddonInfo("path"), "resources", "qr_donate.png")
    # Create a custom window with the QR code centered and instructions
    window = xbmcgui.WindowDialog()
    # Semi-transparent dark background
    window.addControl(xbmcgui.ControlImage(0, 0, 1920, 1080, "", colorDiffuse="CC000000"))
    # QR code centered (400x400 in the middle of 1280x720)
    qr_size = 400
    qr_x = (1280 - qr_size) // 2
    qr_y = 180
    window.addControl(xbmcgui.ControlImage(qr_x, qr_y, qr_size, qr_size, qr_path))
    # Instructions above
    label1 = xbmcgui.ControlLabel(0, 80, 1280, 60, "Scan with your phone to sign up for Flixtor VIP",
                                   alignment=0x00000002, textColor="FFFFFFFF", font="font14")
    window.addControl(label1)
    # URL below QR
    label2 = xbmcgui.ControlLabel(0, qr_y + qr_size + 30, 1280, 40, "flixtor.to/donate",
                                   alignment=0x00000002, textColor="FF00BFFF", font="font14")
    window.addControl(label2)
    # Dismiss instruction
    label3 = xbmcgui.ControlLabel(0, qr_y + qr_size + 90, 1280, 40, "Press any button to close",
                                   alignment=0x00000002, textColor="FF888888", font="font12")
    window.addControl(label3)
    window.doModal()
    del window


def _show_signup_prompt():
    """Show VIP signup info with pricing tiers, then offer to open settings or show QR code."""
    while True:
        choice = xbmcgui.Dialog().select(
            "Flixtor — VIP Account Required",
            [
                "Enter VIP Credentials (already have an account)",
                "Show QR Code to Sign Up (flixtor.to/donate)",
                "[COLOR grey]VIP Plans:  30 Days $14.95  |  90 Days $29.95  |  180 Days $49.95  |  2 Years $89.95[/COLOR]",
            ],
        )
        if choice == 0:
            ADDON.openSettings()
            break
        elif choice == 1:
            _show_qr_dialog()
            # After QR, loop back to let them enter credentials
        else:
            break


def _clear_stored_credentials():
    """Wipe email, password, persisted cookies, and the API response cache
    (it holds session-fingerprinted warm flags and the previous account's
    browse results). Caller handles _client reset."""
    ADDON.setSetting("email", "")
    ADDON.setSetting("password", "")
    for path in (_cookie_path(), _api_cache_path()):
        try:
            os.remove(path)
        except OSError:
            pass


def do_sign_out():
    """Clear stored credentials, persisted cookies, and the in-memory client."""
    if not xbmcgui.Dialog().yesno("Flixtor", "Sign out of Flixtor on this device?"):
        return
    global _client
    _clear_stored_credentials()
    _client = None
    _log("sign_out: credentials cleared")
    xbmcgui.Dialog().notification("Flixtor", "Signed out.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _handle_auth_failure(detail=""):
    """Prompt the user to fix their sign-in after a failed login.

    When Flixtor's rejection text differs from the plain wrong-credentials
    message, show it verbatim first (e.g. a VIP-expiry notice — exact body
    unknown until it happens, so trust the server's words) plus the
    renewal pointer."""
    if detail and "incorrect email" not in detail.lower():
        xbmcgui.Dialog().ok(
            "Flixtor — Sign-in failed",
            "%s\n\nIf your VIP expired, renew at flixtor.to/donate." % detail)
    choice = xbmcgui.Dialog().select(
        "Sign-in failed",
        [
            "Update email or password",
            "Sign in with a different account",
        ],
    )
    if choice == 0:
        ADDON.openSettings()
    elif choice == 1:
        _clear_stored_credentials()
        ADDON.openSettings()


def do_clear_watch_history():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your watch history? This can't be undone."):
        return
    WatchHistory().clear_all()
    _log("clear_watch_history: done")
    xbmcgui.Dialog().notification("Flixtor", "Watch history cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_favorites():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your favorites? This can't be undone."):
        return
    FavoritesHistory().clear_all()
    _log("clear_favorites: done")
    xbmcgui.Dialog().notification("Flixtor", "Favorites cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_searches():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your search history? This can't be undone."):
        return
    SearchHistory().clear_all()
    _log("clear_searches: done")
    xbmcgui.Dialog().notification("Flixtor", "Search history cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_tmdb_cache():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear cached TMDb lookups? Rating badges will refresh on next browse."):
        return
    TmdbClient().clear_cache()
    _log("clear_tmdb_cache: done")
    xbmcgui.Dialog().notification("Flixtor", "TMDb cache cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _counted(count, singular, plural):
    return "{:,} {}".format(count, singular if count == 1 else plural)


def do_show_cache_usage():
    """Settings > Maintenance > "View cache storage usage" — per-cache
    breakdown in a monospace textviewer, plus auto-clean status."""
    progress = xbmcgui.DialogProgressBG()
    progress.create("Flixtor", "Measuring caches...")
    try:
        report = cachemaint.measure_usage(
            progress=lambda done, total: progress.update(int(done * 100 / max(total, 1))))
    finally:
        progress.close()

    lines = []
    total = 0

    def row(label, size, detail=""):
        text = "%-28s %9s" % (label, size)
        lines.append(text + ("   " + detail if detail else ""))

    images = report.get("images")
    if images is None:
        row("Poster images (Kodi cache)", "n/a")
    else:
        count, size = images
        total += size
        row("Poster images (Kodi cache)", cachemaint.format_size(size),
            _counted(count, "image", "images"))
    count, size = report.get("tmdb", (0, 0))
    total += size
    row("TMDb rating cache", cachemaint.format_size(size),
        _counted(count, "entry", "entries"))
    count, size = report.get("subtitles", (0, 0))
    total += size
    row("Subtitle files", cachemaint.format_size(size),
        _counted(count, "file", "files"))
    count, size = report.get("packages", (0, 0))
    total += size
    row("Update zips (Kodi packages)", cachemaint.format_size(size),
        _counted(count, "zip", "zips"))
    size = report.get("other", 0)
    total += size
    row("History & settings data", cachemaint.format_size(size))
    lines.append("-" * 40)
    row("Total", cachemaint.format_size(total))
    lines.append("")

    if ADDON.getSetting("auto_cache_cleanup") != "false":
        lines.append("Auto-clean: on (daily). Removes posters unused")
        lines.append("30+ days, expired TMDb entries, week-old")
        lines.append("subtitles, and superseded update zips.")
    else:
        lines.append("Auto-clean: OFF (enable in Settings > General).")
    ts, stats = cachemaint.last_auto_run()
    if ts:
        freed = (stats.get("images_bytes", 0) + stats.get("subtitles_bytes", 0)
                 + stats.get("packages_bytes", 0))
        lines.append("Last auto-clean: %s — freed %s" % (
            time.strftime("%a %b %d, %H:%M", time.localtime(ts)),
            cachemaint.format_size(freed)))
    else:
        lines.append("Last auto-clean: not yet run (runs ~60s after")
        lines.append("Kodi starts).")

    _log("cache_usage: total=%d" % total)
    xbmcgui.Dialog().textviewer("Flixtor — Cache storage", "\n".join(lines), True)


def do_clear_image_cache():
    if not xbmcgui.Dialog().yesno(
            "Flixtor",
            "Remove all cached poster images? They re-download as you browse."):
        return
    progress = xbmcgui.DialogProgressBG()
    progress.create("Flixtor", "Clearing cached images...")

    def update(done, total):
        progress.update(int(done * 100 / max(total, 1)),
                        message="Removed %d of %d images" % (done, total))

    try:
        removed, freed = cachemaint.purge_all_images(progress=update)
    finally:
        progress.close()
    _log("clear_image_cache: removed=%d freed=%d" % (removed, freed))
    if removed:
        msg = "Removed %s (%s)." % (_counted(removed, "image", "images"),
                                    cachemaint.format_size(freed))
    else:
        msg = "No cached images to remove."
    xbmcgui.Dialog().notification("Flixtor", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def do_clear_subtitles():
    if not xbmcgui.Dialog().yesno(
            "Flixtor",
            "Remove downloaded subtitle files? They re-download when you play with subtitles on."):
        return
    removed, freed = cachemaint.purge_all_subtitles()
    _log("clear_subtitles: removed=%d freed=%d" % (removed, freed))
    if removed:
        msg = "Removed %s (%s)." % (_counted(removed, "subtitle file", "subtitle files"),
                                    cachemaint.format_size(freed))
    else:
        msg = "No subtitle files to remove."
    xbmcgui.Dialog().notification("Flixtor", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def do_clear_update_zips():
    if not xbmcgui.Dialog().yesno(
            "Flixtor",
            "Remove cached addon update zips? Kodi re-downloads them from the repo when needed."):
        return
    removed, freed = cachemaint.purge_all_packages()
    _log("clear_update_zips: removed=%d freed=%d" % (removed, freed))
    if removed:
        msg = "Removed %s (%s)." % (_counted(removed, "zip", "zips"),
                                    cachemaint.format_size(freed))
    else:
        msg = "No cached update zips to remove."
    xbmcgui.Dialog().notification("Flixtor", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def do_check_updates():
    """Refresh enabled Kodi repositories using Kodi's native update system."""
    _log("check_updates: requesting enabled repository refresh")
    xbmcgui.Dialog().notification(
        "Flixtor",
        "Checking for updates. Kodi will install any available version according to its update settings.",
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )
    xbmc.executebuiltin("UpdateAddonRepos")


def get_client():
    global _client
    if _client is None:
        email = ADDON.getSetting("email")
        password = _read_password()
        if not email or not password:
            _show_signup_prompt()
            email = ADDON.getSetting("email")
            password = _read_password()
        if not email or not password:
            return None
        _client = FlixtorClient(email, password)
        login_result = _client.login()
        if login_result == "network_error":
            _log("get_client: login network error")
            xbmcgui.Dialog().ok("Flixtor", "Could not connect to Flixtor. Check your internet or try again later.")
            _client = None
        elif not login_result:
            _log("get_client: login failed (bad credentials)")
            detail = getattr(_client, "last_login_error", "")
            _client = None
            _handle_auth_failure(detail)
    return _client


def build_url(action, **kwargs):
    kwargs["action"] = action
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def _attach_flixtor_context(li, entries):
    """Store the exact Flixtor context actions for the Fire TV keymap.

    Kodi always appends core actions such as Queue, Kodi favourites, and
    Play from here even when ``replaceItems=True`` is requested.  The custom
    keymap reads this property and shows only these add-on-owned actions.
    ``addContextMenuItems`` remains as a fallback for pointer-driven skins.
    """
    safe_entries = [
        [str(label), str(command)]
        for label, command in (entries or [])
        if label and command
    ]
    li.setProperty(
        "Flixtor.Context",
        json.dumps(safe_entries, ensure_ascii=False, separators=(",", ":")),
    )
    li.addContextMenuItems(entries, replaceItems=True)


# ── Main menu ────────────────────────────────────────────────────────

def main_menu():
    # Continue Watching band: one card per distinct title (deduped by pid),
    # capped at CONTINUE_WATCHING_MAX. Each card is the show's newest active
    # episode — an in-progress "Resume" or a queued "Up Next" (the successor of
    # an episode you just finished). Kodi focuses the first item on launch, so
    # power-on → auto-launch → one click resumes the last thing you watched.
    seen_pids = set()
    band = []
    for rec in WatchHistory().get_recent(limit=20):
        pid = rec.get("pid")
        if not pid or pid in seen_pids:
            continue
        resume = rec.get("resume_seconds") or 0
        if resume > 0:
            kind = "Resume"
        elif rec.get("up_next"):
            kind = "Up Next"
        else:
            continue  # completed with no queued successor — not eligible
        seen_pids.add(pid)
        band.append((kind, rec))
        if len(band) >= CONTINUE_WATCHING_MAX:
            break
    for kind, rec in band:
        url, li = _build_resume_item(rec)
        li.setLabel("[B]%s[/B]  %s" % (kind, li.getLabel()))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    items = [
        ("Recently Watched", build_url("recent"), "recent"),
        ("Favorites", build_url("favorites"), "favorites"),
        ("Search", build_url("search"), "search"),
        ("Movies", build_url("movies"), "movies"),
        ("TV Shows", build_url("tvshows"), "tvshows"),
        ("Browse All", build_url("home"), "browse_all"),
    ]
    for label, url, card_slug in items:
        li = xbmcgui.ListItem(label)
        li.setArt(_card_art(card_slug))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)
    _maybe_show_update_notice()


def _maybe_show_update_notice():
    """Schedule the curated notice after Kodi finishes rendering the root."""
    version = _installed_addon_version()
    if ADDON.getSetting("last_update_notice_version") == version:
        _log("update notice already shown for v%s" % version)
        return

    notice = _release_notice_for_version(version)
    if not notice:
        # Private/intermediate versions without curated notes stay silent.
        return

    # A modal dialog opened directly after endOfDirectory races AH2's folder
    # transition and can be discarded without ever becoming visible. Launch a
    # separate plug-in action after the view has settled instead.
    notice_url = build_url("show_update_notice", version=version)
    xbmc.executebuiltin("CancelAlarm(FlixtorUpdateNotice,true)")
    xbmc.executebuiltin(
        "AlarmClock(FlixtorUpdateNotice,RunPlugin(%s),00:00:02,silent)"
        % notice_url
    )
    _log("scheduled update notice for v%s" % version)


def _installed_addon_version():
    """Read the installed manifest so a hot update cannot use stale metadata."""
    addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
    manifest_path = os.path.join(addon_path, "addon.xml")
    try:
        return str(ET.parse(manifest_path).getroot().get("version") or "")
    except (ET.ParseError, OSError, TypeError, ValueError) as exc:
        _log("manifest version unavailable: %s" % exc)
        return str(ADDON.getAddonInfo("version") or "")


def _release_notice_for_version(version):
    """Return a curated notice, or None for silent/intermediate builds."""
    notice_path = os.path.join(
        xbmcvfs.translatePath(ADDON.getAddonInfo("path")),
        "resources",
        "release_notices.json",
    )
    try:
        with open(notice_path, "r", encoding="utf-8") as notice_file:
            return json.load(notice_file).get(version)
    except (OSError, TypeError, ValueError) as exc:
        _log("update notice unavailable: %s" % exc)
        return None


def _show_update_notice(expected_version=""):
    """Show and record one notice from the delayed utility action."""
    version = _installed_addon_version()
    if expected_version and expected_version != version:
        _log(
            "ignored stale update notice for v%s; installed v%s"
            % (expected_version, version)
        )
        return
    if ADDON.getSetting("last_update_notice_version") == version:
        _log("update notice already shown for v%s" % version)
        return

    notice = _release_notice_for_version(version)
    if not notice:
        return

    heading = str(notice.get("heading") or "Flixtor updated")
    message = str(notice.get("message") or "").strip()
    if not message:
        return
    _log("showing update notice for v%s" % version)
    xbmcgui.Dialog().ok("%s to v%s" % (heading, version), message)
    ADDON.setSetting("last_update_notice_version", version)
    _log("update notice acknowledged for v%s" % version)


def exit_flixtor():
    """Leave the add-on deliberately while bypassing its root Back guard."""
    set_parent_folder_items(True)
    window = xbmcgui.Window(10000)
    window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    window.setProperty(
        ROOT_EXIT_ALLOW_PROPERTY, str(time.time() + 5)
    )
    xbmc.executebuiltin("ActivateWindow(Home)")


def exit_kodi():
    """Close Kodi after explicit confirmation."""
    if not xbmcgui.Dialog().yesno(
            "Exit Kodi?", "Close Kodi and return to the Fire TV home screen?"):
        return
    set_parent_folder_items(True)
    window = xbmcgui.Window(10000)
    window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    window.setProperty(
        ROOT_EXIT_ALLOW_PROPERTY, str(time.time() + 5)
    )
    xbmc.executebuiltin("Quit")


def _add_empty_hint(message):
    """Friendly placeholder for an empty Favorites/Recently Watched list —
    links into the Movies picker instead of toasting over a blank screen."""
    li = xbmcgui.ListItem(message)
    li.setArt(_card_art("browse_all"))
    xbmcplugin.addDirectoryItem(HANDLE, build_url("movies"), li, isFolder=True)


# ── Search ────────────────────────────────────────────────────────────

def do_search():
    """Show search history menu: 'New Search...' + recent queries."""
    # ``new_search`` is an interactive directory route. Kodi reloads the
    # owning directory after playback stops, so keep its query only while the
    # user remains inside that one result set. Reaching this parent menu ends
    # the session and ensures the next New Search opens a fresh keyboard.
    xbmcgui.Window(10000).clearProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
    history = SearchHistory()
    recent = history.get_all()

    # "New Search..." always at top
    li = xbmcgui.ListItem("New Search...")
    li.setArt(_card_art("search"))
    xbmcplugin.addDirectoryItem(HANDLE, build_url("new_search"), li, isFolder=True)

    for query in recent:
        url = build_url("search_execute", q=query)
        li = xbmcgui.ListItem(query)
        li.setArt(_card_art("search"))
        li.addContextMenuItems([
            ("Remove from Search History",
             "RunPlugin(%s)" % build_url("remove_search", q=query)),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def do_new_search():
    """Collect a query from the configured Fire TV keyboard and search."""
    route_window = xbmcgui.Window(10000)
    active_query = route_window.getProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
    if active_query:
        # Playback completion rebuilds its owning Kodi directory. Re-render
        # the active results instead of treating that reload as another user
        # request to open the Alexa/Kodi keyboard.
        _log("search: restoring active result set after container reload")
        if not _do_search_execute(active_query, save=False, page=1):
            route_window.clearProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
        return

    query = None
    if _voice_keyboard_enabled():
        result = _request_voice_keyboard("search")
        if result["status"] == "query":
            query = result["query"]
        elif result["status"] == "cancel":
            return
        else:
            # Avoid adding a delay to every later search if the companion was
            # removed or became incompatible. The Test action can re-enable it.
            ADDON.setSetting("voice_keyboard_enabled", "false")
            xbmcgui.Dialog().notification(
                "Flixtor",
                "Voice keyboard unavailable — using the Kodi keyboard.",
                xbmcgui.NOTIFICATION_WARNING,
                3500,
            )
    if query is None:
        query = _kodi_keyboard_query()
    if not query:
        return
    if _do_search_execute(query, save=True, page=1):
        # Window properties are process-memory only. The query is never put in
        # an Android intent or diagnostic log, and do_search() clears it as
        # soon as the user returns to the Search menu.
        route_window.setProperty(ACTIVE_SEARCH_QUERY_PROPERTY, query)


def _kodi_keyboard_query():
    """Return text from Kodi's built-in keyboard, or an empty string."""
    kb = xbmc.Keyboard("", "Search Flixtor")
    kb.doModal()
    if not kb.isConfirmed():
        return ""
    return kb.getText().strip()


def _is_android():
    try:
        return bool(xbmc.getCondVisibility("System.Platform.Android"))
    except (AttributeError, RuntimeError):
        return False


def _voice_keyboard_enabled():
    return _is_android() and ADDON.getSetting("voice_keyboard_enabled") == "true"


def _launch_voice_keyboard(uri):
    """Open the optional Android companion with no query text in the intent."""
    command = "StartAndroidActivity(%s,android.intent.action.VIEW,,%s)" % (
        voicebridge.PACKAGE_NAME,
        uri,
    )
    xbmc.executebuiltin(command)


def _request_voice_keyboard(mode):
    monitor = xbmc.Monitor()
    result = voicebridge.request_input(
        _launch_voice_keyboard,
        mode=mode,
        accept_timeout=3.0,
        response_timeout=180.0 if mode == "search" else 5.0,
        stop_requested=monitor.abortRequested,
    )
    if result.get("version_name"):
        ADDON.setSetting("voice_helper_version", result["version_name"])
    # Deliberately omit the query from logs. Status and compatibility details
    # are sufficient to diagnose bridge failures without retaining searches.
    _log(
        "voice keyboard: mode=%s status=%s version=%s detail=%s"
        % (
            mode,
            result.get("status", ""),
            result.get("version_name", ""),
            result.get("detail", ""),
        )
    )
    return result


def _android_package_installed(package_name):
    """Use Kodi's Android-app VFS instead of private Android APIs."""
    if not _is_android():
        return False
    try:
        return bool(
            xbmcvfs.exists(
                "androidapp://sources/apps/%s.png" % package_name
            )
        )
    except (AttributeError, RuntimeError):
        return False


def _start_android_view(package_name, uri):
    command = "StartAndroidActivity(%s,android.intent.action.VIEW,,%s)" % (
        package_name,
        uri,
    )
    xbmc.executebuiltin(command)


def _voice_release_size_label(size_bytes):
    if not size_bytes:
        return "a small download"
    if size_bytes < 1024 * 1024:
        return "%d KB" % max(1, (size_bytes + 1023) // 1024)
    return "%.1f MB" % (size_bytes / float(1024 * 1024))


def _offer_downloader_install():
    """Guide the one-time prerequisite without making users hunt for it."""
    if not xbmcgui.Dialog().yesno(
        "One-time Fire TV setup",
        "Fire TV requires the free Downloader app to approve companion-app "
        "installs. Flixtor can open its Amazon Appstore page now.\n\n"
        "After Downloader is installed, return here and choose "
        "Set up / update Alexa voice search again.",
        yeslabel="Open Appstore",
        nolabel="Not now",
    ):
        return
    _start_android_view(
        voicebridge.AMAZON_APPSTORE_PACKAGE,
        voicebridge.DOWNLOADER_STORE_URI,
    )


def do_setup_voice_keyboard():
    """Check, install, repair, or update the Fire TV voice companion."""
    if not _is_android():
        xbmcgui.Dialog().ok(
            "Fire TV voice keyboard",
            "This optional keyboard is available only on Android-based Fire TV devices.",
        )
        return

    # The companion deliberately has no launcher icon, so Kodi's Android-app
    # VFS does not list it. Probe the authenticated loopback bridge instead;
    # this detects both installation and whether the helper actually works.
    result = _request_voice_keyboard("probe")
    current_version = ADDON.getSetting("voice_helper_version")
    if result.get("version_name"):
        current_version = result["version_name"]
    companion_installed = (
        result.get("status") == "ready" or bool(current_version)
    )

    try:
        release = voicebridge.fetch_release_metadata()
    except Exception as exc:
        _log("voice setup: release check failed: %s" % exc)
        if result and result["status"] == "ready":
            ADDON.setSetting("voice_keyboard_enabled", "true")
            xbmcgui.Dialog().ok(
                "Alexa voice search is connected",
                "Alexa voice search is working. Flixtor could not check "
                "for updates right now, so please try again later.",
            )
        else:
            xbmcgui.Dialog().ok(
                "Alexa voice search setup",
                "Flixtor could not reach the official companion repository. "
                "Check the Fire TV network connection and try again.",
            )
        return

    latest_version = release["version"]
    current_key = voicebridge.version_key(current_version)
    latest_key = voicebridge.version_key(latest_version)
    if (
        result
        and result["status"] == "ready"
        and current_key
        and current_key >= latest_key
    ):
        ADDON.setSetting("voice_keyboard_enabled", "true")
        xbmcgui.Dialog().ok(
            "Alexa voice search is ready",
            "Alexa voice search is installed, connected, and up to date.\n\n"
            "Search > New Search will now open the Fire TV keyboard. "
            "Type with the remote or hold the Alexa button to dictate.",
        )
        return

    if not _android_package_installed(voicebridge.DOWNLOADER_PACKAGE):
        _offer_downloader_install()
        return

    if result and result["status"] == "ready":
        heading = "Update Alexa voice search"
        prompt = (
            "An Alexa voice search update is available (%s).\n\n"
            "Flixtor will download it automatically. Fire TV "
            "will then ask you to choose Install."
            % (
                _voice_release_size_label(release.get("bytes")),
            )
        )
        yes_label = "Update"
    elif companion_installed:
        heading = "Repair Alexa voice search"
        prompt = (
            "Alexa voice search did not respond. Flixtor can download "
            "a fresh copy (%s) and reopen the Fire "
            "TV installer.\n\nYour Flixtor account and watch history are "
            "not affected."
            % (
                _voice_release_size_label(release.get("bytes")),
            )
        )
        yes_label = "Repair"
    else:
        heading = "Set up Alexa voice search"
        prompt = (
            "Flixtor will download the optional Alexa voice search helper "
            "(%s). Fire TV will then show its own installation screen; "
            "choose Install there to finish.\n\nThe companion only opens "
            "the Fire TV keyboard for Flixtor search."
            % (
                _voice_release_size_label(release.get("bytes")),
            )
        )
        yes_label = "Continue"

    if not xbmcgui.Dialog().yesno(
        heading,
        prompt,
        yeslabel=yes_label,
        nolabel="Not now",
    ):
        return

    try:
        downloader_uri = voicebridge.build_downloader_uri(
            release["download_url"]
        )
    except voicebridge.ReleaseMetadataError as exc:
        _log("voice setup: unsafe release handoff rejected: %s" % exc)
        xbmcgui.Dialog().ok(
            "Alexa voice search setup",
            "The published companion download did not pass Flixtor's "
            "safety checks. Nothing was downloaded.",
        )
        return

    # Downloader owns Fire OS's package-install permission. Stock Kodi does
    # not, so direct PackageInstaller intents are rejected before any prompt.
    # The deep link fills the verified URL, downloads it, and opens Fire OS's
    # required confirmation screen without exposing a manual address-entry step.
    ADDON.setSetting("voice_keyboard_enabled", "true")
    xbmcgui.Dialog().notification(
        "Flixtor",
        "Preparing Alexa voice search...",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )
    _start_android_view(voicebridge.DOWNLOADER_PACKAGE, downloader_uri)


def do_test_voice_keyboard():
    """Backward-compatible route used by pre-setup-action settings files."""
    do_setup_voice_keyboard()


def do_search_execute(query, page=1):
    """Re-execute a saved search query (or paginate through it)."""
    _do_search_execute(query, save=(page == 1), page=page)


def _do_search_execute(query, save=False, page=1):
    """Run a search query and display one page of results."""
    _log("search request: page=%d" % page)
    client = get_client()
    if not client:
        return False
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        result = client.search(query, page=page)
        items = result.get("items") or []
        # Inside the busy dialog so a cold TMDb cache doesn't leave dead
        # air between the spinner closing and the list appearing.
        _prefetch_tmdb(items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No results found.", xbmcgui.NOTIFICATION_INFO)
        return False
    if save:
        SearchHistory().add(query)

    total_pages = result.get("total_pages") or page
    if page > 1 or total_pages > 1:
        xbmcplugin.setPluginCategory(HANDLE, "Search: %s (page %d/%d)" % (query, page, total_pages))

    for item in items:
        add_content_item(item, show_type_label=True)

    if page < total_pages:
        url = build_url("search_execute", q=query, page=page + 1)
        li = xbmcgui.ListItem("Next Page (%d/%d) >>" % (page + 1, total_pages))
        li.setArt({"icon": NEXT_PAGE_ICON, "thumb": NEXT_PAGE_ICON, "poster": NEXT_PAGE_ICON})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "videos")
    # Server-paginated: client-side sorts would only reorder this 24-item
    # page, which reads as broken — offer the natural order only.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)
    return True


def do_remove_search(query):
    """Remove a query from search history and refresh the listing."""
    SearchHistory().remove(query)
    xbmc.executebuiltin("Container.Refresh")


# ── Browse home (paginated) ──────────────────────────────────────────

def do_home(filter_type=None, action="home", page=0):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        all_items = client.browse_home(filter_type=filter_type)
        # Paginate, then resolve TMDb inside the busy dialog (no dead air
        # between spinner close and list render on a cold cache).
        start = page * PAGE_SIZE
        end = start + PAGE_SIZE
        page_items = all_items[start:end]
        _prefetch_tmdb(page_items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not all_items:
        xbmcgui.Dialog().notification("Flixtor", "Could not load content. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # Show type labels only when content is mixed (Trending All)
    show_labels = filter_type is None
    for item in page_items:
        add_content_item(item, show_type_label=show_labels)

    # "Next Page" uses the same action so the filter stays implicit
    if end < len(all_items):
        url = build_url(action, page=page + 1)
        li = xbmcgui.ListItem(f"Next Page ({end}/{len(all_items)}) >>")
        li.setArt({"icon": NEXT_PAGE_ICON, "thumb": NEXT_PAGE_ICON, "poster": NEXT_PAGE_ICON})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    content = "movies" if filter_type == "movie" else "tvshows" if filter_type == "tv" else "videos"
    xbmcplugin.setContent(HANDLE, content)
    # Paginated view: per-page client sorts read as broken — natural order only.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Catalog (full Flixtor library, paginated server-side) ────────────

# Each row maps to a dedicated action (action=<route>) rather than a sort=<key>
# query param, because Kodi silently strips some param names (e.g. `filter`,
# `resume_mode`) from plugin URLs. Dedicated routes are the safe pattern.
# Tuple is (kind, sort, language, label). language="all" means no language
# filter; ISO 639-1 codes like "es" filter the catalog to originals in that
# language. Spanish entries surface ~480 movies / ~80 TV shows that Flixtor
# tags as Spanish-language originals (no dub functionality \u2014 Flixtor's player
# only loads one audio track per stream, see audio investigation in v1.19.0).
_CATALOG_ROUTES = {
    "movies_latest":    ("movies",   "latest", "all", "Latest Releases"),
    "movies_new":       ("movies",   "new",    "all", "Recently Added"),
    "movies_best":      ("movies",   "best",   "all", "Best Rated"),
    "movies_name":      ("movies",   "name",   "all", "A\u2013Z"),
    "movies_spanish":   ("movies",   "latest", "es",  "Spanish (Original Audio)"),
    "tvshows_latest":   ("tvshows",  "latest", "all", "Latest Releases"),
    "tvshows_new":      ("tvshows",  "new",    "all", "Recently Added"),
    "tvshows_best":     ("tvshows",  "best",   "all", "Best Rated"),
    "tvshows_name":     ("tvshows",  "name",   "all", "A\u2013Z"),
    "tvshows_spanish":  ("tvshows",  "latest", "es",  "Spanish (Original Audio)"),
}


_CATALOG_HEADINGS = {"movies": "Movies", "tvshows": "TV Shows"}

# Mapping from kind to the dedicated genre-picker action. Dedicated routes
# (rather than action=genres&kind=...) keep us safe from Kodi's URL param
# stripping, same reasoning as _CATALOG_ROUTES above.
_GENRE_PICKER_ROUTES = {
    "movies":  "genres_movies",
    "tvshows": "genres_tvshows",
}

# Catalog action suffix → card slug. Used by the sort picker and genre picker
# to look up the right bundled card image for each route.
_CATALOG_CARD_SLUGS = {
    "latest":  "sort_latest",
    "new":     "sort_new",
    "best":    "sort_best",
    "name":    "sort_az",
    "spanish": "lang_spanish",
}


def show_catalog_sort_picker(kind):
    """First level of Movies/TV Shows: pick a sort mode (or Browse by Genre)."""
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    # Breadcrumb carries the "Movies"/"TV Shows" context so the cards don't
    # need a redundant "Movies \u2014 " prefix that gets truncated in AH2.
    xbmcplugin.setPluginCategory(HANDLE, heading)
    for action, (k, _sort, lc, label) in _CATALOG_ROUTES.items():
        if k != kind or lc != "all":
            continue
        url = build_url(action, page=1)
        li = xbmcgui.ListItem(label)
        suffix = action.rsplit("_", 1)[1]
        li.setArt(_card_art(_CATALOG_CARD_SLUGS.get(suffix, "sort_latest")))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    genre_action = _GENRE_PICKER_ROUTES.get(kind)
    if genre_action:
        url = build_url(genre_action)
        li = xbmcgui.ListItem("Browse by Genre")
        li.setArt(_card_art("sort_genre"))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_genre_picker(kind):
    """Pick a genre, then jump straight to the Latest Additions catalog
    filtered to that genre."""
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        genres = client.get_genres(kind)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not genres:
        xbmcgui.Dialog().notification("Flixtor", "Could not load genres. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    xbmcplugin.setPluginCategory(HANDLE, "%s \u2014 Browse by Genre" % heading)
    # Language filters live alongside genres in this picker \u2014 they're a
    # separate dimension from genre, but to the user they're "another way to
    # browse" and belong in the same list. Listed first so they're prominent.
    for action, (k, _sort, lc, label) in _CATALOG_ROUTES.items():
        if k != kind or lc == "all":
            continue
        url = build_url(action, page=1)
        li = xbmcgui.ListItem(label)
        suffix = action.rsplit("_", 1)[1]
        li.setArt(_card_art(_CATALOG_CARD_SLUGS.get(suffix, "sort_latest")))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    latest_action = "%s_latest" % kind
    for genre in genres:
        url = build_url(latest_action, genre=genre, page=1)
        # Genre slugs use hyphens (e.g. "Science-Fiction") \u2014 show a friendlier label.
        label = genre.replace("-", " ")
        li = xbmcgui.ListItem(label)
        li.setArt(_card_art(_GENRE_CARD_SLUGS.get(genre, "sort_genre")))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def do_catalog(action, kind, sort, page, genre="all", language="all"):
    """Second level: one page of the paginated catalog, optionally
    constrained to a single genre and/or spoken language."""
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        result = client.browse_catalog(kind, sort=sort, page=page,
                                        genre=genre, language=language)
        items = result.get("items") or []
        # Inside the busy dialog so a cold TMDb cache doesn't leave dead
        # air between the spinner closing and the list appearing.
        _prefetch_tmdb(items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not items:
        xbmcgui.Dialog().notification("Flixtor", "Could not load content. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    total_pages = result.get("total_pages") or page

    # Breadcrumb always reflects where you are: sort label, filters, page \u2014
    # deep pagination otherwise leaves no orientation cues at all.
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    breadcrumb_parts = []
    route_label = _CATALOG_ROUTES.get(action, ("", "", "", ""))[3]
    if route_label:
        breadcrumb_parts.append(route_label)
    elif language and language != "all":
        breadcrumb_parts.append(language.upper())
    if genre and genre != "all":
        breadcrumb_parts.append(genre.replace("-", " "))
    crumb = "%s \u2014 %s" % (heading, " / ".join(breadcrumb_parts)) if breadcrumb_parts else heading
    if total_pages > 1:
        crumb += "  \u00b7  %d/%d" % (page, total_pages)
    xbmcplugin.setPluginCategory(HANDLE, crumb)

    for item in items:
        add_content_item(item, show_type_label=False)

    if page < total_pages:
        url = build_url(action, sort=sort, page=page + 1, genre=genre)
        li = xbmcgui.ListItem("Next Page (%d/%d) >>" % (page + 1, total_pages))
        li.setArt({"icon": NEXT_PAGE_ICON, "thumb": NEXT_PAGE_ICON, "poster": NEXT_PAGE_ICON})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    content = "movies" if kind == "movies" else "tvshows"
    xbmcplugin.setContent(HANDLE, content)
    # Server-paginated: client-side sorts would only reorder this 24-item
    # page, which reads as broken \u2014 offer the natural order only.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# ── TV show: seasons ──────────────────────────────────────────────────

def show_seasons(pid, slug, title, poster):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        seasons = client.get_seasons(pid, slug)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not seasons:
        xbmcgui.Dialog().notification("Flixtor", "No episodes found.", xbmcgui.NOTIFICATION_INFO)
        return

    # Get show info for plot — but keep the poster from the listing (Flixtor's
    # detail page sometimes returns wrong poster art, e.g. ER for The Pitt)
    info = client.get_show_info(pid, slug)
    show_poster = poster or info.get("poster", "")
    plot = info.get("plot", "")
    trailer = info.get("trailer", "")
    year = info.get("year", "")

    tmdb_client = _get_tmdb()
    show_tmdb_id = None
    show_fanart = show_poster
    if tmdb_client:
        tinfo = tmdb_client.lookup_info(title, year, "tv")
        show_tmdb_id = tinfo["tmdb_id"]
        plot = plot or tinfo["plot"]
        show_fanart = tinfo["fanart"] or show_poster

    for s_num in sorted(seasons.keys()):
        ep_count = len(seasons[s_num])
        label = f"Season {s_num} ({ep_count} episodes)"
        url = build_url("episodes", pid=pid, slug=slug, season=s_num, title=title, poster=show_poster)
        li = xbmcgui.ListItem(label)
        li.setArt({"poster": show_poster, "thumb": show_poster, "fanart": show_fanart})
        # Deliberately avoid mediatype="season" and tvshowtitle — those signals
        # make Arctic Horizon 2 render the TV-show-info panel (which pulls a
        # Similar TV Shows widget from TMDb Helper) and show seasons as small
        # buttons at the bottom. We want a plain poster grid.
        li.setInfo("video", {
            "title": label,
            "plot": plot,
        })
        if info.get("rating"):
            li.setRating("imdb", float(info["rating"]))
        _attach_tmdb_id(li, show_tmdb_id)
        if trailer:
            li.setProperty("trailer", trailer)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


# ── TV show: episodes (rich) ─────────────────────────────────────────

def show_episodes(pid, slug, season, title, poster):
    client = get_client()
    if not client:
        return

    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        # Get show info for plot
        show_info = client.get_show_info(pid, slug)
        show_plot = show_info.get("plot", "")
        episodes = client.get_episodes(pid, slug, int(season))
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not episodes:
        # Fallback to basic listing
        seasons = client.get_seasons(pid, slug)
        ep_nums = seasons.get(int(season), [])
        episodes = [{"episode": e, "title": "", "air_date": "", "thumb": ""} for e in ep_nums]

    tmdb_client = _get_tmdb()
    show_tmdb_id = None
    show_fanart = poster
    if tmdb_client:
        tinfo = tmdb_client.lookup_info(title, show_info.get("year", ""), "tv")
        show_tmdb_id = tinfo["tmdb_id"]
        show_plot = show_plot or tinfo["plot"]
        show_fanart = tinfo["fanart"] or poster

    for ep in episodes:
        ep_num = ep["episode"]
        ep_title = ep.get("title", "")
        air_date = ep.get("air_date", "")
        thumb = ep.get("thumb", "") or poster

        if ep_title:
            label = f"{ep_num}. {ep_title}"
        else:
            label = f"Episode {ep_num}"

        url = build_url(
            "play_episode", pid=pid, slug=slug,
            season=season, episode=ep_num, title=title, poster=poster,
        )
        li = xbmcgui.ListItem(label)
        li.setArt({"poster": poster, "thumb": thumb, "fanart": show_fanart, "icon": thumb})
        info = {
            "title": ep_title or label,
            "tvshowtitle": title,
            "season": int(season),
            "episode": ep_num,
            "plot": show_plot,
            "mediatype": "episode",
        }
        if air_date:
            info["aired"] = air_date
        # Watched tick / progress per episode — answers "which one was I on"
        # right in the list.
        _apply_watch_state(li, info, pid, season=int(season), episode=ep_num)
        li.setInfo("video", info)
        _attach_tmdb_id(li, show_tmdb_id)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


# ── Play ──────────────────────────────────────────────────────────────

def _format_time(seconds):
    h, m, s = int(seconds // 3600), int((seconds % 3600) // 60), int(seconds % 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _ask_resume(resume_seconds):
    """Show resume dialog. Returns seek position (0 = from start, >0 = resume, -1 = cancelled)."""
    label = _format_time(resume_seconds)
    choice = xbmcgui.Dialog().contextmenu([
        f"Resume from {label}",
        "Play from beginning",
    ])
    if choice < 0:
        return -1
    return resume_seconds if choice == 0 else 0


def _error_message(error_type):
    """Return a user-friendly error message for a given error type."""
    if error_type == "network":
        return "Network error. Check your connection."
    if error_type == "empty":
        return "Server returned an empty response."
    return "Could not load stream. Try again later."


def _resolve_with_retry(resolve_func):
    """Call resolve_func with progress dialog and one retry on failure."""
    progress = xbmcgui.DialogProgress()
    progress.create("Flixtor", "Loading stream...")
    try:
        stream = resolve_func()
    finally:
        progress.close()

    for attempt in range(2):
        if stream and "error" not in stream:
            return stream
        if stream and "error" in stream:
            msg = _error_message(stream["error"])
            _log("resolve error (attempt %d): %s — %s" % (attempt + 1, stream["error"], stream.get("detail", "")))
            if attempt == 0:
                if not xbmcgui.Dialog().yesno("Flixtor", msg, yeslabel="Retry", nolabel="Cancel"):
                    return None
                progress = xbmcgui.DialogProgress()
                progress.create("Flixtor", "Retrying...")
                try:
                    stream = resolve_func()
                finally:
                    progress.close()
            else:
                xbmcgui.Dialog().ok("Flixtor", msg)
                return None
        else:
            xbmcgui.Dialog().notification("Flixtor", "Could not resolve stream.", xbmcgui.NOTIFICATION_ERROR)
            return None
    return stream


def play_movie(pid, title, poster, slug="", resume_mode="", return_url=""):
    """resume_mode: '' = check history and ask, 'resume' = auto-resume, 'start' = play from beginning."""
    history = WatchHistory()
    seek_on_start = 0.0
    quality = ""

    if resume_mode == "resume":
        seek_on_start = history.get_resume_position(pid)
        quality = history.get_quality(pid)
    elif resume_mode == "start":
        pass  # seek_on_start = 0, quality = "" (ask)
    else:
        resume = history.get_resume_position(pid)
        if resume > 0:
            pref = ADDON.getSetting("resume_mode_default") or "0"
            if pref == "1":
                seek_on_start = resume
                quality = history.get_quality(pid)
            elif pref == "2":
                pass  # always start from beginning
            else:
                result = _ask_resume(resume)
                if result < 0:
                    return
                if result > 0:
                    seek_on_start = result
                    quality = history.get_quality(pid)

    client = get_client()
    if not client:
        return
    _log("play_movie: pid=%s slug=%s" % (pid, slug))
    stream = _resolve_with_retry(lambda: client.resolve_movie(pid, slug=slug))
    if not stream:
        return
    _play_stream(stream, title, poster, pid=pid, slug=slug,
                 media_type="movie", seek_on_start=seek_on_start, quality=quality,
                 return_url=return_url)


def play_episode(pid, season, episode, title, poster, slug="", resume_mode="",
                 return_url=""):
    """resume_mode: '' = check history and ask, 'resume' = auto-resume, 'start' = play from beginning."""
    history = WatchHistory()
    seek_on_start = 0.0
    quality = ""
    try:
        s, e = int(season), int(episode)
    except (ValueError, TypeError):
        xbmcgui.Dialog().notification("Flixtor", "Invalid episode.", xbmcgui.NOTIFICATION_ERROR)
        return

    if resume_mode == "resume":
        seek_on_start = history.get_resume_position(pid, season=s, episode=e)
        quality = history.get_quality(pid, season=s, episode=e)
    elif resume_mode == "start":
        pass
    else:
        resume = history.get_resume_position(pid, season=s, episode=e)
        if resume > 0:
            pref = ADDON.getSetting("resume_mode_default") or "0"
            if pref == "1":
                seek_on_start = resume
                quality = history.get_quality(pid, season=s, episode=e)
            elif pref == "2":
                pass  # always start from beginning
            else:
                result = _ask_resume(resume)
                if result < 0:
                    return
                if result > 0:
                    seek_on_start = result
                    quality = history.get_quality(pid, season=s, episode=e)

    client = get_client()
    if not client:
        return
    _log("play_episode: pid=%s s=%d e=%d" % (pid, s, e))
    stream = _resolve_with_retry(lambda: client.resolve_episode(pid, s, e, slug=slug))
    if not stream:
        return
    label = f"{title} S{s:02d}E{e:02d}"
    next_ep = _compute_next_episode(
        client, pid, slug, s, e, title, poster, return_url=return_url
    )
    _play_stream(stream, label, poster, pid=pid, slug=slug,
                 media_type="tv", season=s, episode=e,
                 seek_on_start=seek_on_start, quality=quality,
                 next_episode=next_ep, history_title=title,
                 return_url=return_url)


def _compute_next_episode(
        client, pid, slug, season, episode, show_title, poster,
        return_url=""):
    """Find the next episode after (season, episode). Returns a dict or None."""
    try:
        seasons = client.get_seasons(pid, slug)
    except Exception as exc:
        _log("next_episode: get_seasons failed: %s" % exc)
        return None
    if not seasons:
        return None
    current_eps = seasons.get(season, [])
    if episode + 1 in current_eps:
        next_s, next_e = season, episode + 1
    else:
        higher = [s for s in seasons if s > season and seasons[s]]
        if not higher:
            return None
        next_s = min(higher)
        next_e = min(seasons[next_s])
    result = {
        "pid": str(pid),
        "slug": slug,
        "season": next_s,
        "episode": next_e,
        "title": show_title,
        "poster": poster,
    }
    if return_url:
        # Keep a TMDb-recommendation landing target across auto-played episodes
        # so stopping anywhere in the chain still returns to the selected show.
        result["return_url"] = return_url
    return result


def _play_stream(stream, title, poster, pid="", slug="", media_type="movie",
                 season=None, episode=None, seek_on_start=0.0, quality="",
                 next_episode=None, history_title="", return_url=""):
    if not stream or "error" in stream or "file" not in stream:
        xbmcgui.Dialog().notification("Flixtor", "Could not resolve stream.", xbmcgui.NOTIFICATION_ERROR)
        return

    master_url = stream["file"]
    headers = "Referer=https://flixtor.to/&Origin=https://flixtor.to"

    # On resume, auto-select the same quality; otherwise show picker
    stream_url, selected_quality = _pick_quality(master_url, headers, preferred=quality)
    if not stream_url:
        return
    _log("play_stream: quality=%s" % selected_quality)

    li = xbmcgui.ListItem(title, path=stream_url)
    li.setArt({"poster": poster, "thumb": poster})
    li.setInfo("video", {"title": title, "mediatype": "video"})
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)

    # Use inputstream.adaptive for HLS if available
    try:
        import inputstreamhelper
        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            li.setProperty("inputstream", is_helper.inputstream_addon)
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            li.setProperty(
                "inputstream.adaptive.stream_headers",
                "Referer=https://flixtor.to/&Origin=https://flixtor.to",
            )
    except ImportError:
        pass

    # Localize subtitles to clean filenames (preferred-language first) so Kodi
    # displays readable labels and the service can deterministically pick the
    # right stream by ISO code.
    pref_label, pref_iso, _ = _preferred_subtitle_pref()
    subs = _localize_subtitles(stream.get("tracks", []), pref_label)
    if subs:
        li.setSubtitles(subs)

    # Write now_playing marker for the background service to pick up
    history = WatchHistory()
    auto_play_next = ADDON.getSetting("auto_play_next") != "false"
    subtitles_default = ADDON.getSetting("subtitles_default") == "true"
    history.set_now_playing({
        "pid": str(pid),
        "slug": slug,
        "media_type": media_type,
        "title": history_title or title,
        "poster": poster,
        "season": season,
        "episode": episode,
        "resume_seconds": 0.0,
        "total_seconds": 0.0,
        "quality": selected_quality,
        "timestamp": time.time(),
        "seek_on_start": seek_on_start,
        "next_episode": next_episode,
        "auto_play_next": auto_play_next,
        "subtitles_default": subtitles_default,
        "preferred_subtitle_iso": pref_iso,
        "preferred_subtitle_label": pref_label,
        # Only TMDb Helper recommendation playback supplies this. The resident
        # service consumes it after Stop/End to make the selected recommendation
        # the active Flixtor title instead of revealing the original movie.
        "return_url": return_url,
    })

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _pick_quality(master_url, headers, preferred=""):
    """Fetch the master m3u8 and let the user choose a quality.
    Returns (stream_url, quality_name) or (None, "") if cancelled."""
    try:
        req = urllib.request.Request(master_url)
        req.add_header("User-Agent", "Mozilla/5.0")
        req.add_header("Referer", "https://flixtor.to/")
        req.add_header("Origin", "https://flixtor.to")
        resp = urllib.request.urlopen(req, timeout=8)
        manifest = resp.read().decode("utf-8")
    except Exception:
        return f"{master_url}|{headers}", preferred or ""

    parsed = urllib.parse.urlparse(master_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    variants = []
    for m in re.finditer(
        r'#EXT-X-STREAM-INF:.*?RESOLUTION=(\d+x\d+).*?NAME=(\w+)\s*\n(.+)',
        manifest,
    ):
        res, name, path = m.group(1), m.group(2), m.group(3).strip()
        full_url = base + path if path.startswith("/") else path
        variants.append((name, res, full_url))

    if not variants:
        return f"{master_url}|{headers}", ""

    if len(variants) == 1:
        return f"{variants[0][2]}|{headers}", variants[0][0]

    # Sort by resolution height descending (1080p first)
    variants.sort(key=lambda v: int(v[1].split("x")[1]), reverse=True)

    # Auto-select preferred quality on resume
    if preferred:
        for name, res, full_url in variants:
            if name == preferred:
                return f"{full_url}|{headers}", name

    default_pref, default_height = _default_quality_pref()
    if default_pref:
        for name, res, full_url in variants:
            if name == default_pref:
                return f"{full_url}|{headers}", name
        # Exact match not in manifest — pick the closest resolution.
        closest = min(variants, key=lambda v: abs(int(v[1].split("x")[1]) - default_height))
        _log("quality: default %s unavailable, picked %s (%s)" % (default_pref, closest[0], closest[1]))
        return f"{closest[2]}|{headers}", closest[0]

    labels = [f"{name} ({res})" for name, res, _ in variants]
    choice = xbmcgui.Dialog().select("Select Quality", labels)
    if choice < 0:
        return None, ""

    return f"{variants[choice][2]}|{headers}", variants[choice][0]


_QUALITY_INDEX_MAP = {
    "1": ("1080p", 1080),
    "2": ("720p", 720),
    "3": ("480p", 480),
    "4": ("360p", 360),
}


def _default_quality_pref():
    """Resolve the default_quality enum setting to (name, height) or ('', 0) if 'Ask'."""
    idx = ADDON.getSetting("default_quality") or "0"
    return _QUALITY_INDEX_MAP.get(idx, ("", 0))


# (label, iso-639-2/B 3-letter, iso-639-1 2-letter). Order matches the
# subtitles_language enum in settings.xml — index = setting value.
_SUBTITLE_LANGUAGES = [
    ("English",    "eng", "en"),
    ("Spanish",    "spa", "es"),
    ("French",     "fre", "fr"),
    ("German",     "ger", "de"),
    ("Portuguese", "por", "pt"),
    ("Italian",    "ita", "it"),
    ("Arabic",     "ara", "ar"),
    ("Russian",    "rus", "ru"),
    ("Japanese",   "jpn", "ja"),
    ("Korean",     "kor", "ko"),
    ("Chinese",    "chi", "zh"),
]

# Wider Flixtor → ISO 639-2/B map. Only used to put ISO codes in downloaded
# filenames so Kodi displays clean labels in its subtitle picker.
_LABEL_TO_ISO = [
    ("english",    "eng"), ("spanish",    "spa"), ("french",     "fre"),
    ("german",     "ger"), ("portuguese", "por"), ("italian",    "ita"),
    ("arabic",     "ara"), ("russian",    "rus"), ("japanese",   "jpn"),
    ("korean",     "kor"), ("chinese",    "chi"), ("dutch",      "dut"),
    ("polish",     "pol"), ("greek",      "gre"), ("turkish",    "tur"),
    ("czech",      "cze"), ("danish",     "dan"), ("finnish",    "fin"),
    ("swedish",    "swe"), ("norwegian",  "nor"), ("hebrew",     "heb"),
    ("vietnamese", "vie"), ("thai",       "tha"), ("hungarian",  "hun"),
    ("romanian",   "rum"), ("bulgarian",  "bul"), ("croatian",   "hrv"),
    ("serbian",    "srp"), ("slovenian",  "slv"), ("slovak",     "slo"),
    ("ukrainian",  "ukr"), ("estonian",   "est"), ("latvian",    "lav"),
    ("lithuanian", "lit"), ("indonesian", "ind"), ("malay",      "may"),
    ("persian",    "per"), ("hindi",      "hin"), ("bengali",    "ben"),
    ("urdu",       "urd"), ("tamil",      "tam"), ("telugu",     "tel"),
]


def _preferred_subtitle_pref():
    """Return (label, iso-639-2, iso-639-1) for the user's preferred language."""
    idx = ADDON.getSetting("subtitles_language") or "0"
    try:
        return _SUBTITLE_LANGUAGES[int(idx)]
    except (ValueError, IndexError):
        return _SUBTITLE_LANGUAGES[0]


def _label_to_iso(label):
    """Map a Flixtor subtitle label (e.g. 'Chinese (traditional)') to an
    ISO 639-2/B 3-letter code. Falls back to 'und' for unknown languages."""
    if not label:
        return "und"
    label_low = label.lower()
    for name, iso in _LABEL_TO_ISO:
        if name in label_low:
            return iso
    return "und"


def _safe_subtitle_url(url):
    """URL-encode a Flixtor subtitle URL so spaces in labels don't make
    urllib reject it. Flixtor labels like 'Portuguese (BR)' end up in the
    path component and break a naked Request() otherwise."""
    parts = urllib.parse.urlsplit(url)
    encoded_path = urllib.parse.quote(parts.path, safe="/.")
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, encoded_path, parts.query, parts.fragment)
    )


def _localize_subtitles(tracks, preferred_label):
    """Return subtitle paths/URLs to feed into ListItem.setSubtitles().

    The preferred-language track is downloaded to a local file with a clean,
    language-coded name (e.g. ``English_8e45dea82d.eng.srt``). Everything
    else is passed through as a URL-encoded URL so Kodi can lazily fetch on
    demand if the user switches.

    Two reasons we localize at all:
      1. Flixtor URLs bury the language name behind a long hash
         (``…01e54e2ad0937b7a.bc37a136ff…English.vtt``), which Kodi shows
         in its subtitle picker — surfacing as garbage like
         ``ENG 01e54e2ad0937b7a.bc37…``.
      2. Without a recognizable ISO code in the filename, Kodi can't
         match the user's preferred language and may pick the wrong track.

    Eagerly downloading every track adds ~3-6s to playback start (which is
    a noticeable regression for users who don't use subtitles) so we only
    fetch the one Kodi will auto-select. Returns the preferred path first
    (so it's stream index 0) followed by the rest — preserves switchability.
    """
    captions = [t for t in (tracks or []) if t.get("kind") == "captions" and t.get("file")]
    if not captions:
        return []

    pref_low = (preferred_label or "").lower()

    # Find the preferred track (substring match handles "Chinese (traditional)" etc.)
    preferred_track = None
    if pref_low:
        for t in captions:
            if pref_low in (t.get("label") or "").lower():
                preferred_track = t
                break

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    subs_dir = os.path.join(profile, "subtitles")
    local_path = None
    if preferred_track:
        try:
            os.makedirs(subs_dir, exist_ok=True)
            # Prune old cached subs (>7 days) to keep the dir small.
            cutoff = time.time() - 7 * 86400
            for f in os.listdir(subs_dir):
                p = os.path.join(subs_dir, f)
                try:
                    if os.path.getmtime(p) < cutoff:
                        os.remove(p)
                except OSError:
                    pass
            local_path = _download_subtitle(preferred_track, subs_dir)
        except OSError as e:
            _log("subs: profile dir error: %s" % e)

    out = []
    if local_path:
        out.append(local_path)
    for t in captions:
        if t is preferred_track and local_path:
            continue
        out.append(_safe_subtitle_url(t["file"]))
    return out


def _download_subtitle(track, subs_dir):
    """Cache one preferred subtitle track locally.

    Flixtor currently serves WebVTT. Convert complete documents to SRT because
    Kodi's external SRT path has simpler timing state across pause/resume and
    seeks. If a future response cannot be converted, retain it as VTT rather
    than dropping subtitles entirely.
    """
    url = track["file"]
    label = track.get("label", "") or "Subtitle"
    iso = _label_to_iso(label)
    url_tag = hashlib.md5(url.encode("utf-8")).hexdigest()[:10]
    safe_label = re.sub(r'[^A-Za-z0-9 -]', "_", label).strip()[:40] or "Subtitle"
    stem = "%s_%s.%s" % (safe_label, url_tag, iso)
    srt_path = os.path.join(subs_dir, stem + ".srt")
    vtt_path = os.path.join(subs_dir, stem + ".vtt")
    if os.path.exists(srt_path) and os.path.getsize(srt_path) > 0:
        return srt_path

    data = None
    # Upgrade an existing v1.26.1 VTT cache entry without another request.
    if os.path.exists(vtt_path) and os.path.getsize(vtt_path) > 0:
        try:
            with open(vtt_path, "rb") as f:
                data = f.read()
        except OSError:
            data = None

    safe_url = _safe_subtitle_url(url)
    try:
        if data is None:
            req = urllib.request.Request(safe_url, headers={
                "User-Agent": "Mozilla/5.0",
                "Referer": "https://flixtor.to/",
            })
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = resp.read()

        srt_text = webvtt_to_srt(data)
        if srt_text:
            tmp = srt_path + ".tmp"
            with open(tmp, "wb") as f:
                f.write(srt_text.encode("utf-8"))
            os.replace(tmp, srt_path)
            _log("subs: cached %s as SRT" % label)
            return srt_path

        tmp = vtt_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, vtt_path)
        _log("subs: response was not convertible; retained VTT for %s" % label)
        return vtt_path
    except Exception as e:
        _log("subs: download failed (%s): %s" % (label, e))
        return None


# ── Recently Watched ──────────────────────────────────────────────────

def _build_resume_item(rec):
    """Build a (url, ListItem) pair for a watch-history record. Used by
    show_recent() and main_menu()'s Continue Watching band (the latter
    re-labels with a Resume prefix)."""
    title = rec.get("title", "")
    pid = rec.get("pid", "")
    slug = rec.get("slug", "")
    poster = rec.get("poster", "")
    media_type = rec.get("media_type", "movie")
    if media_type == "tv":
        title = canonical_show_title(title)
    resume = rec.get("resume_seconds", 0)
    total = rec.get("total_seconds", 0)
    season = rec.get("season")
    episode = rec.get("episode")

    if media_type == "tv" and season is not None:
        label = f"{title} S{season:02d}E{episode:02d}"
    else:
        label = title

    if resume > 0 and total > 0:
        remaining = total - resume
        label += f"  [COLOR grey]({_format_time(remaining)} left)[/COLOR]"

    if media_type == "movie":
        action = "resume_movie" if resume > 0 else "play_movie"
        url = build_url(action, pid=pid, slug=slug, title=title, poster=poster)
    else:
        action = "resume_episode" if resume > 0 else "play_episode"
        url = build_url(action, pid=pid, slug=slug, season=season,
                        episode=episode, title=title, poster=poster)

    li = xbmcgui.ListItem(label)
    li.setProperty("IsPlayable", "true")

    tmdb_id = rec.get("tmdb_id")
    plot = ""
    fanart = poster
    tmdb_client = _get_tmdb()
    if tmdb_client:
        mtype = "movie" if media_type == "movie" else "tv"
        tinfo = tmdb_client.lookup_info(title, rec.get("year", ""), mtype)
        tmdb_id = tmdb_id or tinfo["tmdb_id"]
        plot = tinfo["plot"]
        fanart = tinfo["fanart"] or poster
    li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    if media_type == "movie":
        info = {"title": title, "mediatype": "movie"}
    else:
        info = {
            "title": "S%02dE%02d" % (int(season), int(episode)),
            "tvshowtitle": title,
            "season": int(season),
            "episode": int(episode),
            "mediatype": "episode",
        }
    if plot:
        info["plot"] = plot
    li.setInfo("video", info)
    _attach_tmdb_id(li, tmdb_id)

    if resume > 0 and total > 0:
        li.setProperty("ResumeTime", str(resume))
        li.setProperty("TotalTime", str(total))

    ctx = [
        _favorites_context_item(pid, {
            "slug": slug, "media_type": media_type,
            "title": title, "poster": poster,
            "year": rec.get("year", ""), "rating": rec.get("rating", ""),
            "genres": rec.get("genres", ""), "tmdb_id": tmdb_id or "",
        }),
        (
            "Remove from History",
            "RunPlugin(%s)" % build_url("ctx_remove_history", pid=pid,
                                         season=season if season is not None else "",
                                         episode=episode if episode is not None else ""),
        ),
    ]
    if resume > 0:
        ctx.append((
            "Mark as Watched",
            "RunPlugin(%s)" % build_url("ctx_clear_resume", pid=pid,
                                         season=season if season is not None else "",
                                         episode=episode if episode is not None else ""),
        ))
        if media_type == "movie":
            ctx.append((
                "Play from Beginning",
                "RunPlugin(%s)" % build_url("start_movie", pid=pid, slug=slug,
                                             title=title, poster=poster),
            ))
        else:
            ctx.append((
                "Play from Beginning",
                "RunPlugin(%s)" % build_url("start_episode", pid=pid, slug=slug,
                                             season=season, episode=episode,
                                             title=title, poster=poster),
            ))
    # Kodi's generic queue/library/resume actions do not update Flixtor's own
    # history and duplicate several entries above. Replace them with this short,
    # working set instead of appending to the system menu.
    _attach_flixtor_context(li, ctx)
    return url, li


def _build_recent_tv_show_item(rec):
    """Build a show-level Recently Watched card from its latest episode.

    Select opens the show's seasons so the user can continue naturally. Resume
    of the latest partial episode remains available as a clear context action.
    """
    title = canonical_show_title(rec.get("title", ""))
    pid = rec.get("pid", "")
    slug = rec.get("slug", "")
    poster = rec.get("poster", "")
    season = int(rec.get("season") or 0)
    episode = int(rec.get("episode") or 0)
    resume = rec.get("resume_seconds") or 0
    episode_code = "S%02dE%02d" % (season, episode)
    status = "Resume %s" % episode_code if resume > 0 else "Last watched %s" % episode_code
    label = "%s  [COLOR grey](%s)[/COLOR]" % (title, status)

    li = xbmcgui.ListItem(label)
    url = build_url("seasons", pid=pid, slug=slug, title=title, poster=poster)

    tmdb_id = rec.get("tmdb_id")
    plot = ""
    fanart = poster
    tmdb_client = _get_tmdb()
    if tmdb_client:
        tinfo = tmdb_client.lookup_info(title, rec.get("year", ""), "tv")
        tmdb_id = tmdb_id or tinfo["tmdb_id"]
        plot = tinfo["plot"]
        fanart = tinfo["fanart"] or poster
    info = {"title": title, "tvshowtitle": title, "mediatype": "tvshow"}
    if plot:
        info["plot"] = plot
    year = rec.get("year")
    if str(year or "").isdigit():
        info["year"] = int(year)
    li.setInfo("video", info)
    _attach_tmdb_id(li, tmdb_id)
    li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    li.setContentLookup(False)

    ctx = []
    if resume > 0:
        ctx.append((
            "Resume %s" % episode_code,
            "RunPlugin(%s)" % build_url(
                "resume_episode", pid=pid, slug=slug, season=season,
                episode=episode, title=title, poster=poster,
            ),
        ))
    ctx.append(_favorites_context_item(pid, {
        "slug": slug, "media_type": "tv", "title": title, "poster": poster,
        "year": rec.get("year", ""), "rating": rec.get("rating", ""),
        "genres": rec.get("genres", ""), "tmdb_id": tmdb_id or "",
    }))
    if resume > 0:
        ctx.append((
            "Mark %s as Watched" % episode_code,
            "RunPlugin(%s)" % build_url(
                "ctx_clear_resume", pid=pid, season=season, episode=episode,
            ),
        ))
    ctx.append((
        "Remove Show from History",
        "RunPlugin(%s)" % build_url("ctx_remove_show_history", pid=pid),
    ))
    if _has_youtube():
        ctx.append((
            "Watch Trailer",
            "RunPlugin(%s)" % build_url(
                "play_trailer", pid=pid, slug=slug, media_type="tv",
            ),
        ))
    ctx.append((
        "Similar Titles",
        "Container.Update(%s)" % build_url(
            "recommendations", pid=pid, slug=slug, media_type="tv",
        ),
    ))
    _attach_flixtor_context(li, ctx)
    return url, li


def show_recent():
    history = WatchHistory()
    # Movies stay individual. TV episodes collapse to one latest card per show;
    # queued Up Next placeholders remain exclusive to Continue Watching.
    items = collapse_recent_items(history.get_recent(limit=50), limit=20)
    if not items:
        _add_empty_hint("Nothing watched yet — browse Movies to get started")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for rec in items:
        if rec.get("media_type") == "tv":
            url, li = _build_recent_tv_show_item(rec)
            is_folder = True
        else:
            url, li = _build_resume_item(rec)
            is_folder = False
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Helpers ───────────────────────────────────────────────────────────

def add_content_item(item, show_type_label=False, ctx_override=None):
    """Add a movie or TV show item to the directory listing.

    ``ctx_override`` replaces the default favorites-toggle context entry
    (used by show_favorites, where the item is always removable); trailer
    and Similar Titles entries are appended either way.
    """
    title = item["title"]
    pid = item["pid"]
    slug = item["slug"]
    media_type = item["media_type"]
    poster = item.get("poster", "")
    year = item.get("year", "")
    rating = item.get("rating", "")
    genres = item.get("genres", "")

    # Resolve TMDb info (cache hit in steady state; a callsite may also have
    # prefetched via _prefetch_tmdb). The id feeds AH2's rating badges via
    # TMDb Helper / container 99950; plot/backdrop/vote fill in metadata
    # Flixtor's cards don't carry.
    tmdb_id = item.get("tmdb_id")
    if tmdb_id is None and "tmdb_plot" not in item:
        client = _get_tmdb()
        if client:
            tinfo = client.lookup_info(title, year,
                                       "movie" if media_type == "movie" else "tv")
            tmdb_id = tinfo["tmdb_id"]
            item["tmdb_id"] = tmdb_id
            item["tmdb_plot"] = tinfo["plot"]
            item["tmdb_fanart"] = tinfo["fanart"]
            item["tmdb_vote"] = tinfo["vote"]

    # Build label
    label = title
    if year:
        label = f"{title} ({year})"
    if show_type_label:
        tag = "[COLOR dodgerblue]MOVIE[/COLOR]" if media_type == "movie" else "[COLOR orange]TV[/COLOR]"
        label = f"{tag}  {label}"

    if media_type == "movie":
        url = build_url("play_movie", pid=pid, slug=slug, title=title, poster=poster)
        li = xbmcgui.ListItem(label)
        li.setProperty("IsPlayable", "true")
        is_folder = False
        info = {"title": title, "mediatype": "movie"}
    else:
        url = build_url("seasons", pid=pid, slug=slug, title=title, poster=poster)
        li = xbmcgui.ListItem(label)
        is_folder = True
        info = {"title": title, "mediatype": "tvshow"}

    if year:
        info["year"] = int(year)
    if genres:
        info["genre"] = genres
    plot = item.get("tmdb_plot") or ""
    if plot:
        info["plot"] = plot

    # Watched tick / progress bar for movies (episodes get theirs in
    # show_episodes; shows aren't "watched" as a unit).
    if media_type == "movie":
        _apply_watch_state(li, info, pid)

    li.setInfo("video", info)
    # Use setRating for proper display in Arctic Horizon. Flixtor's own
    # rating wins; TMDb's vote fills the gap for items served without one
    # (recommendation cards, some catalog entries).
    if rating:
        li.setRating("imdb", float(rating))
    elif item.get("tmdb_vote"):
        li.setRating("imdb", float(item["tmdb_vote"]))
    _attach_tmdb_id(li, tmdb_id)
    fanart = item.get("tmdb_fanart") or poster
    li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    li.setContentLookup(False)

    # Context menus — favorites toggle (Add or Remove) computed against the
    # current Favorites state, so the same long-press always Does The Right
    # Thing instead of duplicating an entry the user already saved.
    if ctx_override is not None:
        ctx = list(ctx_override)
    else:
        ctx = [
            _favorites_context_item(pid, {
                "slug": slug, "media_type": media_type,
                "title": title, "poster": poster, "year": year,
                "rating": rating, "genres": genres,
                "tmdb_id": tmdb_id or "",
            })
        ]
    if _has_youtube():
        ctx.append(("Watch Trailer",
                    "RunPlugin(%s)" % build_url("play_trailer", pid=pid, slug=slug, media_type=media_type)))
    ctx.append(("Similar Titles",
                "Container.Update(%s)" % build_url("recommendations", pid=pid, slug=slug, media_type=media_type)))
    # Replace Kodi's generic queue/library menu. Those actions operate on the
    # transient plugin ListItem, not Flixtor favorites/history, and create a
    # long list of repeated or ineffective entries on Fire TV.
    _attach_flixtor_context(li, ctx)

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# ── Favorites ────────────────────────────────────────────────────

def show_favorites():
    fav = FavoritesHistory()
    items = fav.get_all()
    if not items:
        _add_empty_hint("No favorites yet — long-press any title to add one")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        _prefetch_tmdb(items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    for item in items:
        # Same builder as every other listing (type tags, plot, fanart,
        # watched state) — only the favorites toggle differs: here the item
        # is always removable.
        item.setdefault("title", "")
        item.setdefault("slug", "")
        item.setdefault("media_type", "movie")
        if not item.get("tmdb_id"):
            item["tmdb_id"] = None
        add_content_item(item, show_type_label=True, ctx_override=[(
            "Remove from Favorites",
            "RunPlugin(%s)" % build_url("ctx_remove_favorite", pid=item.get("pid", "")),
        )])

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Recommendations ──────────────────────────────────────────────

def show_recommendations(pid, slug, media_type):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        items = client.get_recommendations(pid, slug, media_type)
        _prefetch_tmdb(items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No recommendations found.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for item in items:
        add_content_item(item)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


def show_title_context(pid, slug, media_type, title, poster="", year="",
                       rating="", genres=""):
    """Show the exact title selected from AH2's recommendations.

    TMDb Helper normally resolves recommendation playback without changing the
    underlying Kodi container, which makes Stop reveal the original movie.
    This one-item Flixtor directory becomes the post-playback landing page so
    the selected title remains focused and its cast/recommendations are still
    available through the normal view-aware controls.
    """
    item = {
        "pid": str(pid or ""),
        "slug": slug or "",
        "media_type": "movie" if media_type == "movie" else "tv",
        "title": title or "",
        "poster": poster or "",
        "year": year or "",
        "rating": rating or "",
        "genres": genres or "",
    }
    add_content_item(item)
    xbmcplugin.setPluginCategory(HANDLE, title or "Flixtor")
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Trailers ─────────────────────────────────────────────────────

def play_trailer(pid, slug, media_type):
    if not _has_youtube():
        if xbmcgui.Dialog().yesno(
            "Flixtor",
            "Trailers require the YouTube addon. Install it now?",
        ):
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
        return
    client = get_client()
    if not client:
        return
    _log("play_trailer: pid=%s" % pid)
    trailer_url = client.get_trailer(pid, slug, media_type)
    if trailer_url:
        xbmc.Player().play(trailer_url)
    else:
        xbmcgui.Dialog().notification("Flixtor", "No trailer available.", xbmcgui.NOTIFICATION_INFO)


# ── TMDb Helper: search and play ─────────────────────────────────

def search_and_play(title, year="", media_type="movie", season=None, episode=None):
    """Play a TMDb recommendation only when the exact title exists on Flixtor."""
    _log("search_and_play: title=%s year=%s type=%s season=%s episode=%s" %
         (title, year, media_type, season, episode))
    client = get_client()
    if not client:
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except RuntimeError:
            pass
        return
    results = (client.search(title) or {}).get("items") or []
    best = select_flixtor_match(results, title, year, media_type)
    if not best:
        xbmcgui.Dialog().notification(
            "Flixtor", "This title is not available on Flixtor.",
            xbmcgui.NOTIFICATION_INFO,
        )
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except RuntimeError:
            pass
        return
    return_url = build_url(
        "title_context",
        pid=best["pid"],
        slug=best.get("slug", ""),
        media_type=best.get("media_type", media_type),
        title=best.get("title", title),
        poster=best.get("poster", ""),
        year=best.get("year", year),
        rating=best.get("rating", ""),
        genres=best.get("genres", ""),
    )
    if best["media_type"] == "movie":
        play_movie(
            best["pid"], best["title"], best.get("poster", ""), best["slug"],
            return_url=return_url,
        )
    elif season is not None and episode is not None:
        play_episode(
            best["pid"], int(season), int(episode), best["title"],
            best.get("poster", ""), slug=best["slug"],
            return_url=return_url,
        )
    else:
        # A show-level recommendation opens the show. TMDb Helper supplies
        # season/episode when its episode picker asks us to play a specific one.
        xbmc.executebuiltin(
            "Container.Update(%s)" % build_url("seasons", pid=best["pid"], slug=best["slug"],
                                                 title=best["title"], poster=best.get("poster", ""))
        )


def handle_remote_direction(direction):
    """Legacy route for one-press details; the keymap now uses the service."""
    direction = str(direction or "").casefold()
    native_action = {"down": "Down", "left": "Left"}.get(direction)
    if not native_action:
        return
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    db_type = xbmc.getInfoLabel("ListItem.DBType")
    skin_dir = xbmc.getSkinDir()
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    focused_control_id = next(
        (
            control_id
            for control_id in AH2_DETAILS_CONTROL_IDS
            if xbmc.getCondVisibility("Control.HasFocus(%d)" % control_id)
        ),
        0,
    )
    if should_open_one_press_details(
            folder_path, db_type, skin_dir, direction,
            dialog_id, focused_control_id):
        # The AH2 YouTube recommendation row performs an API search as soon as
        # it loads. Hide it on this Fire TV because no YouTube API key is
        # configured; cast, Flixtor playback and recommendations remain intact.
        xbmc.executebuiltin("Skin.SetBool(Info.DisableYoutube)")
        xbmc.executebuiltin("SetFocus(99996)")
        return
    # Action() dispatches the native UI action directly; it does not synthesize
    # another remote key, so the custom keymap does not recurse.
    xbmc.executebuiltin("Action(%s)" % native_action)


def handle_remote_back(long_press=False):
    """Legacy plug-in route; the resident service handles the keymap."""
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    options_menu_open = (
        xbmc.getSkinDir() == "skin.arctic.horizon.2"
        and (
            xbmc.getCondVisibility("ControlGroup(9000).HasFocus()")
            or xbmc.getCondVisibility("Control.HasFocus(89000)")
        )
    )
    if should_guard_flixtor_root_back(
            folder_path, dialog_id, options_menu_open=options_menu_open):
        if long_press:
            exit_flixtor()
        else:
            xbmcgui.Dialog().notification(
                "Flixtor",
                "Home screen — hold Back to exit",
                xbmcgui.NOTIFICATION_INFO,
                1800,
            )
        return
    xbmc.executebuiltin("Action(Back)")


def handle_remote_context():
    """Show only the working, add-on-owned actions for a Flixtor title."""
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    plugin_name = xbmc.getInfoLabel("Container.PluginName")
    route_marker = xbmcgui.Window(10000).getProperty(ROOT_ROUTE_PROPERTY)
    in_flixtor = (
        str(folder_path or "").startswith("plugin://plugin.video.flixtor/")
        or str(plugin_name or "") == "plugin.video.flixtor"
        or route_marker == "root"
    )
    raw_entries = xbmc.getInfoLabel("ListItem.Property(Flixtor.Context)")
    entries = []
    if in_flixtor and raw_entries:
        try:
            entries = json.loads(raw_entries)
            entries = [
                (str(label), str(command))
                for label, command in entries
                if label and command
            ]
        except (TypeError, ValueError) as exc:
            _log("remote_context: invalid item actions: %s" % exc)
            entries = []
    if in_flixtor:
        entries.extend([
            ("Exit Flixtor", "RunPlugin(%s)" % build_url("exit_flixtor")),
            ("Exit Kodi", "RunPlugin(%s)" % build_url("exit_kodi")),
        ])
        choice = xbmcgui.Dialog().contextmenu([label for label, _ in entries])
        if 0 <= choice < len(entries):
            label, command = entries[choice]
            _log("remote_context: selected %s" % label)
            xbmc.executebuiltin(command)
        return

    # Categories and all non-Flixtor video windows retain Kodi's normal menu.
    # Action() dispatches directly and does not synthesize another keypress.
    xbmc.executebuiltin("Action(ContextMenu)")


# ── Router ────────────────────────────────────────────────────────────

def _title_or_slug(params):
    """Return a non-empty display title: the URL title, or a title-cased slug fallback."""
    title = params.get("title") or ""
    if title:
        return title
    slug = params.get("slug", "")
    if slug:
        return slug.replace("-", " ").replace("_", " ").title()
    return "Flixtor"


def router():
    # keep_blank_values=True so empty values (e.g. title=) survive as "" instead of
    # being silently dropped, which otherwise causes KeyError on params["title"].
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?"), keep_blank_values=True))
    action = params.get("action")
    # The resident service cannot rely on Container.FolderPath under every
    # Fire TV skin/launch path. Record the plug-in route explicitly instead.
    route_window = xbmcgui.Window(10000)
    utility_action = action == "show_update_notice"
    if action is None:
        # Kodi has no per-directory flag for its automatic ``..`` item. Toggle
        # the global preference only while building this appliance-style root;
        # every child route and explicit exit restores normal Kodi lists.
        route_window.setProperty(ROOT_ROUTE_PROPERTY, "root")
        set_parent_folder_items(False)
    elif not utility_action:
        set_parent_folder_items(True)
    if (
        action is not None
        and action not in {"exit_flixtor", "exit_kodi", "show_update_notice"}
    ):
        # Exit actions are launched from the add-on-owned long-press menu.
        # Preserve the underlying route while its confirmation dialog is open.
        route_window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    _log("router: action=%s" % action)

    if action is None:
        main_menu()
    elif action == "show_update_notice":
        _show_update_notice(params.get("version", ""))
    elif action == "exit_flixtor":
        exit_flixtor()
    elif action == "exit_kodi":
        exit_kodi()
    elif action == "recent":
        show_recent()
    elif action == "search":
        do_search()
    elif action == "new_search":
        do_new_search()
    elif action == "setup_voice_keyboard":
        do_setup_voice_keyboard()
    elif action == "test_voice_keyboard":
        do_test_voice_keyboard()
    elif action == "search_execute":
        do_search_execute(params["q"], page=int(params.get("page", 1)))
    elif action == "remove_search":
        do_remove_search(params["q"])
    elif action == "home":
        do_home(page=int(params.get("page", 0)))
    elif action == "movies":
        show_catalog_sort_picker("movies")
    elif action == "tvshows":
        show_catalog_sort_picker("tvshows")
    elif action == "genres_movies":
        show_genre_picker("movies")
    elif action == "genres_tvshows":
        show_genre_picker("tvshows")
    elif action in _CATALOG_ROUTES:
        kind, sort, language, _label = _CATALOG_ROUTES[action]
        do_catalog(action, kind, sort, int(params.get("page", 1)),
                   genre=params.get("genre", "all"),
                   language=language)
    elif action == "seasons":
        show_seasons(params["pid"], params.get("slug", ""), _title_or_slug(params),
                     params.get("poster", ""))
    elif action == "title_context":
        show_title_context(
            params["pid"], params.get("slug", ""),
            params.get("media_type", "movie"), _title_or_slug(params),
            params.get("poster", ""), params.get("year", ""),
            params.get("rating", ""), params.get("genres", ""),
        )
    elif action == "episodes":
        show_episodes(
            params["pid"], params.get("slug", ""), params["season"],
            _title_or_slug(params), params.get("poster", ""),
        )
    elif action == "play_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""))
    elif action == "resume_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""), resume_mode="resume")
    elif action == "start_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""), resume_mode="start")
    elif action == "play_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            return_url=params.get("return_url", ""),
        )
    elif action == "resume_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            resume_mode="resume",
            return_url=params.get("return_url", ""),
        )
    elif action == "start_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            resume_mode="start",
            return_url=params.get("return_url", ""),
        )
    elif action == "ctx_remove_history":
        season = params.get("season") or None
        episode = params.get("episode") or None
        WatchHistory().remove_item(params["pid"], season=season, episode=episode)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_remove_show_history":
        WatchHistory().remove_show(params["pid"])
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_clear_resume":
        season = params.get("season") or None
        episode = params.get("episode") or None
        WatchHistory().clear_resume(params["pid"], season=season, episode=episode)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "favorites":
        show_favorites()
    elif action == "ctx_add_favorite":
        FavoritesHistory().add({
            "pid": params["pid"], "slug": params.get("slug", ""),
            "media_type": params.get("media_type", "movie"),
            "title": params.get("title", ""), "poster": params.get("poster", ""),
            "year": params.get("year", ""), "rating": params.get("rating", ""),
            "genres": params.get("genres", ""),
            "tmdb_id": params.get("tmdb_id") or "",
        })
        xbmcgui.Dialog().notification("Flixtor", "Added to Favorites", xbmcgui.NOTIFICATION_INFO, 1500)
        # Refresh so the long-press toggle flips from "Add" to "Remove" without
        # the user navigating away and back.
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_remove_favorite":
        FavoritesHistory().remove(params["pid"])
        xbmc.executebuiltin("Container.Refresh")
    elif action == "recommendations":
        show_recommendations(params["pid"], params.get("slug", ""), params.get("media_type", "movie"))
    elif action == "play_trailer":
        play_trailer(params["pid"], params.get("slug", ""), params.get("media_type", "movie"))
    elif action == "search_and_play":
        search_and_play(params.get("title", ""), params.get("year", ""),
                        params.get("media_type", "movie"),
                        params.get("season"), params.get("episode"))
    elif action == "remote_down":
        handle_remote_direction("down")
    elif action == "remote_left":
        handle_remote_direction("left")
    elif action == "remote_back":
        handle_remote_back(long_press=False)
    elif action == "remote_back_long":
        handle_remote_back(long_press=True)
    elif action == "remote_context":
        handle_remote_context()
    elif action == "sign_out":
        do_sign_out()
    elif action == "clear_watch_history":
        do_clear_watch_history()
    elif action == "clear_favorites":
        do_clear_favorites()
    elif action == "clear_searches":
        do_clear_searches()
    elif action == "clear_tmdb_cache":
        do_clear_tmdb_cache()
    elif action == "clear_image_cache":
        do_clear_image_cache()
    elif action == "cache_usage":
        do_show_cache_usage()
    elif action == "check_updates":
        do_check_updates()
    elif action == "clear_subtitles":
        do_clear_subtitles()
    elif action == "clear_update_zips":
        do_clear_update_zips()


if __name__ == "__main__":
    router()
