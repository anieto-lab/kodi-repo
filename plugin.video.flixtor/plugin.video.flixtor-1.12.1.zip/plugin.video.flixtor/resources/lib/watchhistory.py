"""Watch history, search history, and resume point storage for Flixtor addon."""

import json
import os
import time

try:
    import xbmcvfs
    import xbmcaddon

    def _get_userdata_dir():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        return xbmcvfs.translatePath(addon.getAddonInfo("profile"))
except ImportError:
    # For local testing outside Kodi
    def _get_userdata_dir():
        return os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata")


MAX_HISTORY = 50
MAX_SEARCHES = 10
STALE_MARKER_SECONDS = 60


def _record_key(rec):
    """Unique key for a watch record: pid for movies, (pid, season, episode) for TV."""
    if rec.get("media_type") == "movie" or rec.get("season") is None:
        return rec["pid"]
    return (rec["pid"], rec["season"], rec["episode"])


def _make_key(pid, season=None, episode=None):
    """Build a record key from explicit values."""
    if season is not None:
        return (str(pid), int(season), int(episode))
    return str(pid)


class WatchHistory:
    def __init__(self):
        self._dir = _get_userdata_dir()
        self._history_path = os.path.join(self._dir, "watch_history.json")
        self._nowplaying_path = os.path.join(self._dir, "now_playing.json")

    def _ensure_dir(self):
        if not os.path.isdir(self._dir):
            os.makedirs(self._dir, exist_ok=True)

    def _read_json(self, path):
        try:
            with open(path, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return None

    def _write_json(self, path, data):
        self._ensure_dir()
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, path)

    # ── now_playing marker (plugin → service handoff) ────────────────

    def set_now_playing(self, metadata):
        self._write_json(self._nowplaying_path, metadata)

    def get_now_playing(self):
        data = self._read_json(self._nowplaying_path)
        if not data:
            return None
        # Ignore stale markers
        ts = data.get("timestamp", 0)
        if time.time() - ts > STALE_MARKER_SECONDS:
            self.clear_now_playing()
            return None
        return data

    def clear_now_playing(self):
        try:
            os.remove(self._nowplaying_path)
        except OSError:
            pass

    # ── watch history persistence ────────────────────────────────────

    def _load_history(self):
        data = self._read_json(self._history_path)
        if isinstance(data, list):
            return data
        return []

    def _save_history(self, history):
        self._write_json(self._history_path, history[:MAX_HISTORY])

    def update_position(self, metadata):
        """Upsert a record in the history. Moves it to the top (most recent)."""
        history = self._load_history()
        key = _record_key(metadata)

        # Remove existing entry for this content
        history = [r for r in history if _record_key(r) != key]

        # Update timestamp and insert at top
        metadata["timestamp"] = time.time()
        history.insert(0, metadata)

        self._save_history(history)

    def get_resume_position(self, pid, season=None, episode=None):
        """Return resume seconds for a specific item, or 0 if none/completed."""
        key = _make_key(pid, season, episode)
        for rec in self._load_history():
            if _record_key(rec) == key:
                return rec.get("resume_seconds", 0)
        return 0

    def get_quality(self, pid, season=None, episode=None):
        """Return the saved quality name for a specific item, or '' if none."""
        key = _make_key(pid, season, episode)
        for rec in self._load_history():
            if _record_key(rec) == key:
                return rec.get("quality", "")
        return ""

    def get_recent(self, limit=20):
        """Return the most recent watch history items."""
        return self._load_history()[:limit]

    def remove_item(self, pid, season=None, episode=None):
        """Remove a record from watch history by key."""
        key = _make_key(pid, season, episode)
        history = self._load_history()
        history = [r for r in history if _record_key(r) != key]
        self._save_history(history)

    def clear_resume(self, pid, season=None, episode=None):
        """Clear the resume point for a record (mark as watched)."""
        key = _make_key(pid, season, episode)
        history = self._load_history()
        for rec in history:
            if _record_key(rec) == key:
                rec["resume_seconds"] = 0.0
                break
        self._save_history(history)

    def clear_all(self):
        """Wipe all watch history."""
        self._save_history([])


class SearchHistory:
    """Persists recent search queries to avoid re-typing on Fire TV."""

    def __init__(self):
        self._dir = _get_userdata_dir()
        self._path = os.path.join(self._dir, "search_history.json")

    def _ensure_dir(self):
        if not os.path.isdir(self._dir):
            os.makedirs(self._dir, exist_ok=True)

    def _load(self):
        try:
            with open(self._path, "r") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        return []

    def _save(self, queries):
        self._ensure_dir()
        tmp = self._path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(queries[:MAX_SEARCHES], f)
        os.replace(tmp, self._path)

    def add(self, query):
        """Add a query to the top of the list (deduplicates)."""
        queries = self._load()
        # Remove existing occurrence (case-insensitive dedup)
        queries = [q for q in queries if q.lower() != query.lower()]
        queries.insert(0, query)
        self._save(queries)

    def get_all(self):
        """Return all saved queries, most recent first."""
        return self._load()

    def remove(self, query):
        """Remove a specific query."""
        queries = self._load()
        queries = [q for q in queries if q != query]
        self._save(queries)

    def clear_all(self):
        """Wipe all saved search queries."""
        self._save([])


MAX_FAVORITES = 100


class FavoritesHistory:
    """Persists favorite movies and TV shows."""

    def __init__(self):
        self._dir = _get_userdata_dir()
        self._path = os.path.join(self._dir, "favorites.json")

    def _ensure_dir(self):
        if not os.path.isdir(self._dir):
            os.makedirs(self._dir, exist_ok=True)

    def _load(self):
        try:
            with open(self._path, "r") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        return []

    def _save(self, items):
        self._ensure_dir()
        tmp = self._path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(items[:MAX_FAVORITES], f)
        os.replace(tmp, self._path)

    def add(self, item):
        """Add an item to favorites (deduplicates by pid)."""
        items = self._load()
        pid = item.get("pid", "")
        items = [i for i in items if i.get("pid") != pid]
        item["timestamp"] = time.time()
        items.insert(0, item)
        self._save(items)

    def remove(self, pid):
        """Remove a favorite by pid."""
        items = self._load()
        items = [i for i in items if i.get("pid") != str(pid)]
        self._save(items)

    def get_all(self):
        """Return all favorites, most recently added first."""
        return self._load()

    def is_favorite(self, pid):
        """Check if a pid is in favorites."""
        return any(i.get("pid") == str(pid) for i in self._load())

    def clear_all(self):
        """Wipe all favorites."""
        self._save([])
