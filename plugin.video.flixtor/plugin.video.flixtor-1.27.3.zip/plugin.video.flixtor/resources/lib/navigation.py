"""Pure navigation helpers shared by the Kodi UI and local tests."""

import re
import unicodedata
import urllib.parse


# Arctic Horizon 2 assigns stable control IDs to each view family.  The value
# here is the direction that leaves the content edge for the view's scrollbar
# or details furniture.  Only that direction is eligible for our one-press
# cast/recommendations shortcut; all other directions remain native.
AH2_DETAILS_CONTROLS_BY_DIRECTION = {
    "down": frozenset({
        # Horizontal rows.
        50, 51, 52, 56, 57, 58,
        # The lower content row in AH2's combined views.  The upper child row
        # intentionally is not included because Down moves to this lower row.
        502, 512, 522, 572,
    }),
    "left": frozenset({
        # Vertical lists and infolists.
        501, 507, 508, 511, 517, 521, 527, 551, 557, 558, 581,
        # Vertical walls and info walls.
        54, 500, 510, 520, 540, 550, 560, 570, 580,
        # Media-info combined view: Left is the outer edge; Right retains
        # access to its child pane and then the side menu.
        552,
    }),
}
AH2_DETAILS_CONTROL_IDS = frozenset().union(
    *AH2_DETAILS_CONTROLS_BY_DIRECTION.values()
)
FLIXTOR_ROOT_PATH = "plugin://plugin.video.flixtor"
ROOT_EXIT_ALLOW_PROPERTY = "Flixtor.AllowRootExitUntil"
ROOT_ROUTE_PROPERTY = "Flixtor.Route"
NO_DIALOG_IDS = frozenset({0, 9999})


def _normalized_title(value):
    """Return a conservative title key for matching TMDb items to Flixtor."""
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", "", value.casefold())


def is_dialog_open(dialog_id):
    """Normalize Kodi's platform-specific no-dialog sentinel values."""
    try:
        return int(dialog_id or 0) not in NO_DIALOG_IDS
    except (TypeError, ValueError):
        return True


def is_flixtor_title_context_url(url):
    """Validate the private post-playback landing route exactly."""
    try:
        parsed = urllib.parse.urlsplit(str(url or ""))
        actions = urllib.parse.parse_qs(parsed.query).get("action", [])
    except (TypeError, ValueError):
        return False
    return (
        parsed.scheme == "plugin"
        and parsed.netloc == "plugin.video.flixtor"
        and parsed.path in {"", "/"}
        and actions == ["title_context"]
    )


def select_flixtor_match(results, title, year="", media_type="movie"):
    """Choose an exact Flixtor title/type match, preferring the requested year.

    TMDb recommendations must never fall through to an unrelated first search
    result. If the requested title does not exist on Flixtor, return ``None``.
    """
    wanted_title = _normalized_title(title)
    wanted_type = "movie" if media_type == "movie" else "tv"
    wanted_year = str(year or "").strip()

    matches = [
        item for item in (results or [])
        if item.get("media_type") == wanted_type
        and _normalized_title(item.get("title")) == wanted_title
    ]
    if not matches:
        return None
    if wanted_year:
        for item in matches:
            if str(item.get("year") or "").strip() == wanted_year:
                return item
    return matches[0]


def collapse_recent_items(records, limit=20):
    """Return recent movies plus one latest record per TV show.

    Watch history stores individual TV episodes. Recently Watched is a title
    browser, so only the newest real episode for each show should become a card.
    Continue Watching still consumes the uncollapsed records.
    """
    collapsed = []
    seen_tv = set()
    for record in records or []:
        if record.get("up_next"):
            continue
        if record.get("media_type") == "tv":
            pid = str(record.get("pid") or "")
            if pid in seen_tv:
                continue
            seen_tv.add(pid)
        collapsed.append(record)
        if len(collapsed) >= limit:
            break
    return collapsed


def canonical_show_title(title):
    """Strip one or more trailing episode codes from a stored show title.

    Older watch-history records used the playback label (for example,
    ``House of the Dragon S03E05``) as the show title.  Recently Watched adds
    its own episode status, so retaining that suffix duplicates the episode
    code and also breaks metadata lookup.
    """
    return re.sub(
        r"(?:\s+S\d{1,3}E\d{1,3})+\s*$",
        "",
        str(title or ""),
        flags=re.IGNORECASE,
    ).strip()


def should_open_one_press_details(
        folder_path, db_type, skin_dir, direction,
        dialog_id=0, focused_control_id=0):
    """Whether this view-specific edge action should open AH2 details."""
    direction = str(direction or "").casefold()
    return (
        not is_dialog_open(dialog_id)
        and int(focused_control_id or 0)
        in AH2_DETAILS_CONTROLS_BY_DIRECTION.get(direction, frozenset())
        and str(skin_dir or "") == "skin.arctic.horizon.2"
        and str(folder_path or "").startswith("plugin://plugin.video.flixtor/")
        and str(db_type or "").casefold() in {"movie", "tvshow"}
    )


def is_flixtor_root_path(folder_path):
    """Whether this is the exact Flixtor home route, without an action query."""
    path, _separator, query = str(folder_path or "").partition("?")
    return path.rstrip("/") == FLIXTOR_ROOT_PATH and not query


def should_guard_flixtor_root_back(folder_path, dialog_id=0):
    """Whether a short Back press should remain on the Flixtor home page."""
    return not is_dialog_open(dialog_id) and is_flixtor_root_path(folder_path)


def should_restore_flixtor_root(
        previously_at_root, folder_path, dialog_id=0,
        exit_allowed=False, player_active=False):
    """Whether the resident service should undo an unhandled root exit.

    Fire TV can deliver Android Back outside Kodi's custom keymap.  The service
    therefore watches only the transition from the exact Flixtor root to a
    non-Flixtor screen.  Flixtor child routes, dialogs, playback, and explicit
    exit actions are deliberately excluded.
    """
    return (
        bool(previously_at_root)
        and not str(folder_path or "").startswith(FLIXTOR_ROOT_PATH)
        and not is_dialog_open(dialog_id)
        and not bool(exit_allowed)
        and not bool(player_active)
    )
