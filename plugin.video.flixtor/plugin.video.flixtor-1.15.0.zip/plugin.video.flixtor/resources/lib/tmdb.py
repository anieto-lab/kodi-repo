"""TMDb v3 lookup for Flixtor items.

Resolves `tmdb_id` + `imdb_id` for a Flixtor title/year/media_type so
ListItems can advertise them via `setUniqueIDs`. TMDb Helper (installed
on the Fire TV) then enriches `Container(99950)` with IMDb/RT/TMDb/etc.
ratings that Arctic Horizon 2 renders in the info panel.

Stdlib only (Kodi on Fire TV has no requests/etc.). Reuses the public
API key that ships with TMDb Helper — documented in its source at
jurialmunkey/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/tmdb.py.
"""

import json
import urllib.error
import urllib.parse
import urllib.request

from resources.lib.watchhistory import TmdbIdCache

try:
    import xbmc
    def _log(msg):
        xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)
except ImportError:
    def _log(msg):
        print("FLIXTOR: " + msg)


TMDB_API_KEY = "a07324c669cac4d96789197134ce272b"
TMDB_API = "https://api.themoviedb.org/3"
TIMEOUT = 5
UA = "Mozilla/5.0 plugin.video.flixtor"


def _get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _search(title, year, media_type):
    """Return the best TMDb search hit (or None)."""
    path = "/search/movie" if media_type == "movie" else "/search/tv"
    params = {"api_key": TMDB_API_KEY, "query": title, "include_adult": "false"}
    if year:
        params["year" if media_type == "movie" else "first_air_date_year"] = str(year)
    url = TMDB_API + path + "?" + urllib.parse.urlencode(params)
    data = _get_json(url)
    results = data.get("results") or []
    return results[0] if results else None


def _external_ids(tmdb_id, media_type):
    path = "/movie/" if media_type == "movie" else "/tv/"
    url = TMDB_API + path + str(tmdb_id) + "/external_ids?api_key=" + TMDB_API_KEY
    return _get_json(url)


def lookup_ids(pid, title, year, media_type):
    """Return {'tmdb': str, 'imdb': str or None} for a Flixtor item, or None.

    Cached persistently on disk keyed by Flixtor pid. Network failures and
    zero-result searches produce a negative cache entry (24h TTL).
    """
    if not pid or not title:
        return None
    cache = TmdbIdCache()
    hit = cache.get(pid)
    if hit is not None:
        if hit.get("_notfound"):
            return None
        return hit

    if media_type not in ("movie", "tv"):
        media_type = "movie"

    try:
        match = _search(title, year, media_type)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as e:
        _log("tmdb: search error for %s (%s, %s): %s" % (pid, title, year, e))
        cache.set_notfound(pid)
        return None

    if not match or "id" not in match:
        _log("tmdb: no match for pid=%s title=%r year=%s type=%s" % (pid, title, year, media_type))
        cache.set_notfound(pid)
        return None

    tmdb_id = str(match["id"])
    imdb_id = None
    try:
        ext = _external_ids(tmdb_id, media_type)
        imdb_id = ext.get("imdb_id") or None
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as e:
        _log("tmdb: external_ids error for %s (tmdb=%s): %s" % (pid, tmdb_id, e))
        # Keep the TMDb hit; TMDb Helper can still enrich from tmdb_id alone.

    cache.set(pid, tmdb_id, imdb_id)
    _log("tmdb: match pid=%s (%s, %s) -> tmdb=%s imdb=%s" % (pid, title, year, tmdb_id, imdb_id))
    return {"tmdb": tmdb_id, "imdb": imdb_id}
