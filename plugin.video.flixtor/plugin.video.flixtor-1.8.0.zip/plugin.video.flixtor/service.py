"""Flixtor background service — tracks playback position and installs custom keymaps."""

import os
import xbmc
import xbmcvfs
import xbmcaddon
from resources.lib.watchhistory import WatchHistory

KEYMAP_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<keymap>
  <FullscreenVideo>
    <keyboard>
      <backspace>Stop</backspace>
      <browser_back>Stop</browser_back>
      <escape>Stop</escape>
      <down>OSD</down>
    </keyboard>
    <remote>
      <back>Stop</back>
      <down>OSD</down>
    </remote>
  </FullscreenVideo>
  <FullscreenInfo>
    <keyboard>
      <backspace>Stop</backspace>
      <browser_back>Stop</browser_back>
      <escape>Stop</escape>
    </keyboard>
    <remote>
      <back>Stop</back>
    </remote>
  </FullscreenInfo>
</keymap>
"""


TMDB_PLAYER_JSON = """\
{
    "name": "Flixtor",
    "plugin": "plugin.video.flixtor",
    "priority": 10,
    "play_movie": "plugin://plugin.video.flixtor/?action=search_and_play&media_type=movie&title={title}&year={year}",
    "play_episode": "plugin://plugin.video.flixtor/?action=search_and_play&media_type=tv&title={title}&year={year}"
}
"""


def _install_keymap():
    """Install custom keymap for Fire TV remote during video playback."""
    profile = xbmcvfs.translatePath("special://profile/keymaps/")
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    keymap_path = os.path.join(profile, "flixtor.xml")
    if not os.path.exists(keymap_path):
        with open(keymap_path, "w") as f:
            f.write(KEYMAP_XML)
        xbmc.executebuiltin("Action(reloadkeymaps)")
        xbmc.log("FLIXTOR: installed custom keymap", xbmc.LOGINFO)


def _install_tmdb_player():
    """Install TMDb Helper player file so Similar/Recommended titles route to Flixtor."""
    players_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.themoviedb.helper/players/"
    )
    if not xbmcvfs.exists(players_dir):
        xbmcvfs.mkdirs(players_dir)
    player_path = os.path.join(players_dir, "flixtor.json")
    # Always overwrite to keep in sync with addon version
    with open(player_path, "w") as f:
        f.write(TMDB_PLAYER_JSON)
    xbmc.log("FLIXTOR: installed TMDb Helper player file", xbmc.LOGINFO)


class FlixtorPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._history = WatchHistory()
        self._tracking = False
        self._metadata = None
        self._last_time = 0.0
        self._total_time = 0.0

    def onAVStarted(self):
        meta = self._history.get_now_playing()
        if not meta:
            self._tracking = False
            return
        self._history.clear_now_playing()
        self._tracking = True
        self._metadata = meta
        seek_to = meta.get("seek_on_start", 0.0)
        xbmc.log("FLIXTOR: onAVStarted: pid=%s title=%s seek=%.1f" %
                 (meta.get("pid"), meta.get("title"), seek_to), xbmc.LOGINFO)

        try:
            self._total_time = self.getTotalTime()
        except RuntimeError:
            self._total_time = 0.0

        if seek_to > 0:
            xbmc.sleep(500)
            try:
                self.seekTime(seek_to)
            except RuntimeError:
                xbmc.log("FLIXTOR: onAVStarted: seek failed", xbmc.LOGINFO)

    def onPlayBackStopped(self):
        self._save_position(completed=False)

    def onPlayBackEnded(self):
        self._save_position(completed=True)

    def onPlayBackError(self):
        self._save_position(completed=False)

    def _save_position(self, completed=False):
        if not self._tracking or not self._metadata:
            return
        meta = self._metadata.copy()
        meta.pop("seek_on_start", None)
        if completed:
            meta["resume_seconds"] = 0.0
        else:
            meta["resume_seconds"] = self._last_time
        meta["total_seconds"] = self._total_time
        xbmc.log("FLIXTOR: save_position: pid=%s resume=%.1f total=%.1f completed=%s" %
                 (meta.get("pid"), meta["resume_seconds"], meta["total_seconds"], completed),
                 xbmc.LOGINFO)
        self._history.update_position(meta)
        self._tracking = False
        self._metadata = None

    def poll_position(self):
        if not self._tracking:
            return
        try:
            self._last_time = self.getTime()
            self._total_time = self.getTotalTime()
        except RuntimeError:
            pass


def run():
    monitor = xbmc.Monitor()
    player = FlixtorPlayer()

    _install_keymap()
    _install_tmdb_player()

    # Auto-launch Flixtor on Kodi startup (configurable via settings)
    addon = xbmcaddon.Addon()
    if addon.getSetting("auto_launch") != "false":
        xbmc.sleep(2000)
        xbmc.executebuiltin("ActivateWindow(videos,plugin://plugin.video.flixtor/)")
    else:
        xbmc.log("FLIXTOR: auto-launch disabled in settings", xbmc.LOGINFO)

    xbmc.log("FLIXTOR: service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        player.poll_position()
        if monitor.waitForAbort(5):
            break

    xbmc.log("FLIXTOR: service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    run()
