"""IMDb / Rotten Tomatoes ratings for the highlighted Flixtor title.

Listings already carry cached ratings (main._attach_ratings). This service
helper covers titles that have none yet: once the highlight rests on a title
for one poll, it fetches that title's ratings (one OMDb request, cached for
weeks) and publishes them as Home window properties keyed by the title. The
skin shows them only on the item whose Flixtor.RatingsKey matches, so a
fetch that finishes late can never label another title.

It runs only while Flixtor Horizon is the skin. Other skins keep TMDb
Helper's own ratings and never pay for these requests.
"""

import queue
import threading

SKIN_ID = "skin.flixtor.horizon"
POLL_SECONDS = 0.25
KEY = "Flixtor.Focus.Key"
IMDB = "Flixtor.Focus.IMDbRating"
RT = "Flixtor.Focus.RTScore"


class FocusRatings:
    def __init__(self, can_run, get_label, get_skin, window, fetch):
        self.can_run = can_run
        self.get_label = get_label
        self.get_skin = get_skin
        self.window = window
        self.fetch = fetch
        self.last = ""
        self.settled = False
        self.stopped = threading.Event()
        self.inflight = {}
        self.results = queue.Queue()
        self.thread = threading.Thread(target=self._run, daemon=True, name="FlixtorFocusRatings")

    def start(self):
        self.thread.start()

    def close(self):
        self.stopped.set()

    def _run(self):
        while not self.stopped.wait(POLL_SECONDS):
            try:
                self.step()
            except Exception:
                # Optional enrichment must never take the service down.
                self.stopped.wait(1)

    def _focused(self, name):
        return self.get_label("ListItem.Property(Flixtor.%s)" % name)

    def _fetch(self, key):
        media, _, tmdb_id = key.partition(":")
        try:
            entry = self.fetch(media, tmdb_id)
        except Exception:
            entry = None  # Optional ratings must not leave this key in flight.
        self.results.put((key, entry))

    def _publish_ready(self, focused_key):
        while True:
            try:
                key, entry = self.results.get_nowait()
            except queue.Empty:
                return
            self.inflight.pop(key, None)
            if key != focused_key or not entry or entry.get("miss"):
                continue
            self.window.clearProperty(KEY)
            self.window.setProperty(IMDB, entry.get("imdb") or "")
            rt = entry.get("rt")
            self.window.setProperty(RT, "" if rt is None else str(rt))
            self.window.setProperty(KEY, key)

    def step(self):
        """One poll. Fetches at most once per resting highlight."""
        if self.get_skin() != SKIN_ID or not self.can_run():
            self._publish_ready("")
            self.last, self.settled = "", False
            return
        key = self._focused("RatingsKey")
        self._publish_ready(key)
        if not key or key != self.last:
            self.last, self.settled = key, False
            return
        if self.settled:
            return
        if (key in self.inflight or self.window.getProperty(KEY) == key
                or self._focused("IMDbRating") or self._focused("RTScore")):
            self.settled = True
            return
        # A second worker can serve the new highlight while an old request
        # finishes. When both are busy, only the current highlight is retried.
        if len(self.inflight) < 2:
            worker = threading.Thread(target=self._fetch, args=(key,), daemon=True,
                                      name="FlixtorRatingLookup")
            self.inflight[key] = worker
            worker.start()
            self.settled = True
