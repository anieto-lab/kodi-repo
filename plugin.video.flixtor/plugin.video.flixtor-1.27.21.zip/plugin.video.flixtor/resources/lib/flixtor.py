"""Flixtor API client — handles auth, browsing, search, and stream resolution."""

from contextlib import contextmanager
import base64
import codecs
import hashlib
import html as html_lib
import json
import os
import re
import sqlite3
import time
import urllib.error
import urllib.request
import urllib.parse
import http.cookiejar
import zlib

from resources.lib.catalog import validate_catalog, element_contents, page_identity, has_empty_results
from resources.lib.storage import atomic_json, profile_lock, read_json


def _sanitize_log_message(msg):
    """Return text that is safe to pass through Kodi's C string logger."""
    return str(msg).replace("\x00", "\\0")


try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    def _log(msg):
        xbmc.log("FLIXTOR: " + _sanitize_log_message(msg), xbmc.LOGINFO)
    def _profile_dir():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        d = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return d
except ImportError:
    def _log(msg):
        print("FLIXTOR: " + _sanitize_log_message(msg))
    def _profile_dir():
        d = os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata")
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return d


def _cookie_path():
    return os.path.join(_profile_dir(), "cookies.json")


def _api_cache_path():
    return os.path.join(_profile_dir(), "api_cache.json")


BASE = "https://flixtor.to"
IMG_BASE = "https://img.xcdn.to/t/p"
VIDEO_AJAX = BASE + "/ajax/v4"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36"
)

# Cache TTL in seconds
HOME_CACHE_TTL = 300  # 5 minutes
SAVED_CATALOG_TTL = 86400  # Last successful public catalog metadata, for service outages.
SAVED_CATALOG_PREFIXES = ("catalog:", "recent:", "home_items:")
SHOW_CACHE_TTL = 600  # 10 minutes

# Disk cache (api_cache.json) — shared across Kodi's process-per-navigation
# model so parsed pages survive into the next navigation.
API_CACHE_MAX_ENTRY_BYTES = 65536  # bigger values stay memory-only
API_CACHE_MAX_ENTRIES = 50         # oldest-first eviction on write
SHELL_WARM_TTL = 6 * 3600          # backstop; warm flags are session-scoped
CATALOG_CACHE_GENERATION = "v3"    # validated full pages and finite recent feeds

# Response-size guard: the largest legitimate page (show HTML) is ~500KB,
# so 10MB leaves huge headroom while keeping a hostile/compromised server
# from OOMing the Fire TV with an oversized body or a gzip bomb.
MAX_BODY_BYTES = 10 * 1024 * 1024


def _extract_csrf_token(html):
    """Extract the current login CSRF token from a Flixtor meta tag."""
    if not html:
        return ""
    for tag in re.findall(r"<meta\b[^>]*>", html, re.IGNORECASE):
        name = re.search(r"\bname\s*=\s*([\"'])csrf-token\1", tag, re.IGNORECASE)
        if not name:
            continue
        content = re.search(r"\bcontent\s*=\s*([\"'])(.*?)\1", tag, re.IGNORECASE)
        return content.group(2).strip() if content else ""
    return ""


def _clean_http_error_text(text):
    """Collapse control characters so server error bodies are safe for UI/logs."""
    cleaned = "".join(
        ch if ord(ch) >= 32 or ch in "\t\n\r" else " "
        for ch in (text or "")
    )
    return re.sub(r"\s+", " ", cleaned).strip()


def _safe_log_path(url):
    """Return a request path with user-entered search text redacted."""
    path = urllib.parse.urlsplit(url).path
    if path.startswith("/search/"):
        return "/search/[redacted]"
    # Keep legacy calls private if an older cached/module path invokes one
    # during a staged update.
    if path.startswith("/ajax/show/search/"):
        return "/ajax/show/search/[redacted]"
    return path


_MONTH_MAP = {
    "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04",
    "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
    "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12",
}


def _parse_flixtor_date(raw):
    """Convert Flixtor's 'Thu, Jan 8th, 2026' format to ISO 'YYYY-MM-DD'.

    Kodi's ListItem.setInfo aired field needs ISO — if given a non-ISO string,
    Arctic Horizon 2 falls back to a sentinel year (1996) for the air date.
    Returns '' if the input can't be parsed.
    """
    if not raw:
        return ""
    m = re.search(
        r'(\w{3,}),?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})',
        raw,
    )
    if not m:
        return ""
    month_num = _MONTH_MAP.get(m.group(2))
    if not month_num:
        return ""
    return "%s-%s-%02d" % (m.group(4), month_num, int(m.group(3)))


@contextmanager
def _feed_lock(feed):
    """Coordinate cold instances of a Home feed, independently of library writes."""
    connection = None
    try:
        if feed:
            path = os.path.join(os.path.dirname(_api_cache_path()), "shelf-" + feed + ".sqlite")
            connection = sqlite3.connect(path, timeout=30)
            connection.execute("BEGIN IMMEDIATE")
    except (OSError, sqlite3.Error):
        pass  # The normal request remains available if the optional lock fails.
    try:
        yield
    finally:
        if connection is not None:
            connection.close()


class FlixtorClient:
    def __init__(self, email, password):
        self.email = email
        self.password = password
        self._cj = http.cookiejar.CookieJar()
        self._opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self._cj)
        )
        self._logged_in = False
        self._cache = {}
        self._disk_cache = None  # lazy-loaded api_cache.json contents
        self.last_login_error = ""  # server's own text from a rejected login
        # Try to restore session from persistent cookies
        self._load_cookies()

    def _load_cookies(self):
        """Load saved cookies from disk to avoid re-login on every plugin invocation."""
        try:
            data = read_json(_cookie_path(), {})
            if data.get("email") != self.email:
                return  # Different account, ignore
            if time.time() - data.get("saved_at", 0) > 86400:
                return  # Older than 24 hours, ignore
            # Reconstruct cookies
            for c in data.get("cookies", []):
                cookie = http.cookiejar.Cookie(
                    version=0, name=c["name"], value=c["value"],
                    port=None, port_specified=False,
                    domain=c["domain"], domain_specified=True, domain_initial_dot=c["domain"].startswith("."),
                    path=c.get("path", "/"), path_specified=True,
                    secure=c.get("secure", False), expires=c.get("expires"),
                    discard=c.get("expires") is None,
                    comment=None, comment_url=None, rest={}, rfc2109=False,
                )
                self._cj.set_cookie(cookie)
            if self._has_cookie("vipLogin"):
                self._logged_in = True
                _log("login: restored session from saved cookies")
        except (ValueError, OSError, KeyError):
            pass

    def _save_cookies(self):
        """Persist cookies to disk so subsequent plugin processes skip login."""
        try:
            cookies = []
            for c in self._cj:
                cookies.append({
                    "name": c.name, "value": c.value,
                    "domain": c.domain, "path": c.path,
                    "secure": c.secure, "expires": c.expires,
                })
            data = {"email": self.email, "saved_at": time.time(), "cookies": cookies}
            path = _cookie_path()
            atomic_json(path, data)
        except OSError as e:
            _log("save_cookies: error: %s" % e)

    # ── two-layer response cache ──────────────────────────────────────
    # Layer 1: self._cache, per-process memory. Layer 2: api_cache.json,
    # shared across processes (every Kodi navigation is a new process, so
    # without it every parsed page dies with the process that fetched it).
    # Disk entries carry their own {ts, ttl} for per-entry expiry. Raw-HTML
    # entries opt out via disk=False: they're large, and on a failed
    # re-login they could carry a login page — never persist those.

    def _load_disk_cache(self, for_update=False):
        if self._disk_cache is not None:
            return self._disk_cache
        try:
            data = read_json(_api_cache_path(), {})
            self._disk_cache = data if isinstance(data, dict) else {}
        except ValueError:
            self._disk_cache = {}
        except OSError:
            if for_update:
                raise
            self._disk_cache = {}
        return self._disk_cache

    def _flush_disk_cache(self):
        """Prune expired and excess entries before publishing the snapshot."""
        store = self._disk_cache
        if store is None:
            return
        now = time.time()
        for key, entry in list(store.items()):
            lifetime = SAVED_CATALOG_TTL if key.startswith(SAVED_CATALOG_PREFIXES) else None
            if not isinstance(entry, dict) or now - entry.get("ts", 0) >= (lifetime or entry.get("ttl", 0)):
                del store[key]
        if len(store) > API_CACHE_MAX_ENTRIES:
            oldest = sorted(store.items(), key=lambda kv: kv[1].get("ts", 0))
            for k, _ in oldest[:len(store) - API_CACHE_MAX_ENTRIES]:
                del store[k]
        atomic_json(_api_cache_path(), store)

    def _update_disk_entries(self, entries):
        """Merge a shelf's change with the pages other Kodi instances saved."""
        try:
            with profile_lock(os.path.dirname(_api_cache_path())):
                self._disk_cache = None
                store = self._load_disk_cache(for_update=True)
                for key, entry in entries.items():
                    if entry is None:
                        store.pop(key, None)
                    else:
                        store[key] = entry
                self._flush_disk_cache()
        except (OSError, sqlite3.Error) as e:
            _log("api_cache: write failed: %s" % e)

    def _get_cached(self, key, ttl):
        if key in self._cache:
            ts, data = self._cache[key]
            if time.time() - ts < ttl:
                return data
        entry = self._load_disk_cache().get(key)
        if isinstance(entry, dict):
            ts = entry.get("ts", 0)
            if time.time() - ts < ttl:
                data = entry.get("data")
                self._cache[key] = (ts, data)  # promote, keep original age
                return data
        return None

    def _saved_catalog(self, key, error):
        if error not in ("network", "service_refused") or not key.startswith(SAVED_CATALOG_PREFIXES):
            return None
        saved = self._get_cached(key, SAVED_CATALOG_TTL)
        if not saved:
            return None
        items = saved.get("items", []) if isinstance(saved, dict) else saved
        marked = [dict(item, saved_catalog=True) for item in items]
        return dict(saved, items=marked) if isinstance(saved, dict) else marked

    def _set_cached(self, key, data, ttl, disk=True):
        now = time.time()
        self._cache[key] = (now, data)
        self._cache = {
            k: (t, d) for k, (t, d) in self._cache.items()
            if now - t < max(SHELL_WARM_TTL, HOME_CACHE_TTL, SHOW_CACHE_TTL) * 2
        }
        if not disk:
            return data
        try:
            blob = json.dumps(data)
        except (TypeError, ValueError):
            return data
        if len(blob) > API_CACHE_MAX_ENTRY_BYTES:
            return data
        # json round-trip = snapshot: callers mutate returned items in place
        # (e.g. _prefetch_tmdb adds tmdb_id) and later flushes of the shared
        # store must not pick those mutations up.
        self._update_disk_entries({key: {"ts": now, "ttl": ttl, "data": json.loads(blob)}})
        return data

    def _del_cached(self, key):
        """Remove a key from BOTH layers, persisting the deletion. The 444
        re-warm heal depends on this: a memory-only pop would let the next
        read resurrect the stale flag from disk and defeat the retry."""
        self._cache.pop(key, None)
        self._update_disk_entries({key: None})

    # ── catalog shell warm state (session-scoped) ─────────────────────

    def _session_fingerprint(self):
        """Short fingerprint of the vipLogin cookie. Warm flags store this
        so a new session (cookie rollover after 24h, account switch) never
        inherits the previous session's warm state."""
        for c in self._cj:
            if c.name == "vipLogin":
                return hashlib.sha256((c.value or "").encode("utf-8")).hexdigest()[:16]
        return ""

    def _shell_warmed(self, kind):
        flag = self._get_cached(self._shell_cache_key(kind), SHELL_WARM_TTL)
        fp = self._session_fingerprint()
        return bool(flag) and bool(fp) and flag == fp

    def _mark_shell_warmed(self, kind):
        fp = self._session_fingerprint()
        if fp:
            self._set_cached(self._shell_cache_key(kind), fp, SHELL_WARM_TTL)

    @staticmethod
    def _shell_cache_key(kind):
        return "catalog_shell:%s:%s" % (CATALOG_CACHE_GENERATION, kind)

    # ── HTTP helpers ──────────────────────────────────────────────────

    @staticmethod
    def _read_body(resp):
        """Read a response body, transparently gunzipping when the server
        honored Accept-Encoding. Returns (bytes, wire_bytes).

        Two failure containments: (1) truncated/corrupt gzip falls back to
        the raw bytes instead of raising — flaky Wi-Fi must not turn a
        readable error page into a crash; (2) both the wire read and the
        decoded output are capped at MAX_BODY_BYTES so an oversized body
        or decompression bomb degrades to unparseable garbage (parsers
        return empty) rather than OOMing the device."""
        raw = resp.read(MAX_BODY_BYTES)
        if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
            try:
                d = zlib.decompressobj(16 + zlib.MAX_WBITS)
                body = d.decompress(raw, MAX_BODY_BYTES)
                # unconsumed_tail = output hit the cap (bomb); not eof =
                # stream never reached its end marker (truncated). Unlike
                # one-shot zlib.decompress, decompressobj won't raise on
                # truncation by itself — check explicitly.
                if d.unconsumed_tail or not d.eof:
                    raise zlib.error("truncated stream or size cap exceeded")
                return body, len(raw)
            except zlib.error:
                pass
        return raw, len(raw)

    def _get(self, url, headers=None, params=None, accept_gzip=True):
        """GET request with cookie persistence, gzip, and a timing log line
        (visible via `adb logcat -s Kodi:*` for latency measurements).
        Only gzip is advertised: deflate is ambiguous (raw vs zlib-wrapped)
        and brotli has no stdlib decoder."""
        if params:
            url = url + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url)
        req.add_header("User-Agent", UA)
        if accept_gzip:
            req.add_header("Accept-Encoding", "gzip")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        t0 = time.monotonic()
        resp = self._opener.open(req, timeout=getattr(self, "request_timeout", 30))
        body, wire = self._read_body(resp)
        _log("GET %s -> %s %dms %dB->%dB" % (
            _safe_log_path(url), getattr(resp, "status", "?"),
            int((time.monotonic() - t0) * 1000), wire, len(body)))
        return body.decode("utf-8", errors="replace")

    def _post_json(self, url, data, headers=None):
        """POST JSON with cookie persistence."""
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("User-Agent", UA)
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept-Encoding", "gzip")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        resp = self._opener.open(req, timeout=getattr(self, "request_timeout", 30))
        return self._read_body(resp)[0].decode("utf-8", errors="replace")

    def _has_cookie(self, name):
        for cookie in self._cj:
            if cookie.name == name:
                return True
        return False

    # ── auth ──────────────────────────────────────────────────────────

    def login(self):
        """Returns True on success, False on credential failure, or "network_error" on network failure."""
        if self._logged_in:
            return True
        _log("login: attempting")
        self.last_login_http_status = None
        try:
            login_page = self._get(BASE + "/viplogin")
        except Exception as e:
            self.last_login_http_status = getattr(e, "code", None)
            _log("login: network error loading login page: %s" % e)
            return "network_error"
        csrf_token = _extract_csrf_token(login_page)
        login_headers = {
            "Referer": BASE + "/viplogin",
            "X-Requested-With": "XMLHttpRequest",
        }
        if csrf_token:
            login_headers["X-CSRF-Token"] = csrf_token
        else:
            _log("login: CSRF token missing from login page")
        try:
            self._post_json(
                BASE + "/ajax/viplogin",
                {"uname": self.email, "passw": self.password},
                headers=login_headers,
            )
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                # Known body for bad creds: "Incorrect Email Address or
                # Password." — keep whatever the server said so the UI can
                # surface a different reason (e.g. VIP expiry) verbatim.
                try:
                    raw, _wire = self._read_body(e)
                    decoded = raw.decode("utf-8", "replace")
                    self.last_login_error = _clean_http_error_text(decoded)[:200]
                except Exception:
                    self.last_login_error = ""
                _log("login: credentials rejected (HTTP %d): %s"
                     % (e.code, self.last_login_error))
                return False
            _log("login: network error on login POST: %s" % e)
            return "network_error"
        except Exception as e:
            _log("login: network error on login POST: %s" % e)
            return "network_error"
        self._logged_in = self._has_cookie("vipLogin")
        _log("login: %s" % ("success" if self._logged_in else "FAILED"))
        if self._logged_in:
            self._save_cookies()
        return self._logged_in

    def _ensure_login(self):
        if not self._logged_in:
            return self.login()
        return True

    def _relogin(self):
        """Force a fresh login (clears cookies, logged-in flag, and shell
        warm flags — both cache layers — since the new session has not
        visited any shell page)."""
        _log("relogin: clearing session and re-authenticating")
        self._logged_in = False
        self._cj.clear()
        for kind in ("movies", "tvshows", "episodes"):
            # Purge both generations. The legacy flag represented a visit to
            # /show/{kind}/all, which no longer warms the query-based route.
            self._del_cached("catalog_shell:" + kind)
            self._del_cached(self._shell_cache_key(kind))
        return self.login()

    def _looks_like_auth_failure(self, html):
        """Detect if a response indicates the session expired."""
        if not html:
            return False
        if "viplogin" in html and len(html) < 1000:
            return True
        if "<title>Login" in html or "<title>VIP Login" in html:
            return True
        # Since the August 2026 frontend update, expired VIP routes can return
        # the complete public landing page with HTTP 200. Its generic title is
        # shared with navigation, so require the absence of every authenticated
        # content marker before treating it as a login response.
        if (
            "Watch the Latest Movies and TV Shows for Free on Flixtor.to" in html
            and "/watch/" not in html
            and "showPageType" not in html
            and "searchPageMode" not in html
        ):
            return True
        return False

    def _looks_like_ajax_auth_failure(self, html):
        """Detect a login/public document returned to an AJAX fragment call.

        Current Flixtor routes answer an expired VIP session with the complete
        public landing document and HTTP 200. A valid catalog/search AJAX
        response is a fragment, so accepting a full HTML document would parse
        unrelated cards or cache an empty result as if it were authoritative.
        """
        if self._looks_like_auth_failure(html):
            return True
        prefix = (html or "")[:2000]
        return bool(re.search(r"<(?:!doctype|html)\b", prefix, re.IGNORECASE))

    # ── decoding ──────────────────────────────────────────────────────

    @staticmethod
    def _decode_video_response(encoded):
        """ROT13 -> base64 -> char-shift decode, matching flixtor's main.min.js."""
        rot13 = codecs.encode(encoded, "rot_13")
        raw = base64.b64decode(rot13).decode("utf-8")
        out = []
        for ch in raw:
            code = ord(ch)
            if 33 <= code <= 126:
                out.append(chr(33 + (code + 14) % 94))
            else:
                out.append(ch)
        return "".join(out)

    # ── search ────────────────────────────────────────────────────────

    @staticmethod
    def _listing_error(page, code):
        return {"items": [], "page": page, "total_pages": 0,
                "error": {"code": code}}

    def _listing_login_error(self, login_status):
        if login_status == "network_error":
            return "service_refused" if getattr(self, "last_login_http_status", None) == 403 else "network"
        return "auth"

    def _fetch_listing(self, url, params=None, ajax=False, referer=None):
        """One authentication recovery; never turn transport errors into empties."""
        headers = {"Referer": referer or url}
        if ajax:
            headers.update({"Accept": "text/html, */*; q=0.01",
                            "X-Requested-With": "XMLHttpRequest"})
        try:
            login_status = self._ensure_login()
            if not self._logged_in:
                return None, self._listing_login_error(login_status)
            for attempt in range(2):
                try:
                    document = self._get(url, headers=headers, params=params)
                    auth = (self._looks_like_ajax_auth_failure(document) if ajax
                            else self._looks_like_auth_failure(document))
                    if not auth:
                        return document, None
                except urllib.error.HTTPError as exc:
                    if exc.code not in (401, 403):
                        return None, "network"
                if attempt:
                    return None, "auth"
                login_status = self._relogin()
                if login_status is not True:
                    return None, self._listing_login_error(login_status)
        except Exception:
            # Do not log exception URLs: search terms and session data are private.
            return None, "network"
        return None, "auth"

    def search(self, query, sort="relevance", page=1):
        encoded = urllib.parse.quote(query.strip(), safe="")
        key = "search:%s:%s:%s:%d" % (CATALOG_CACHE_GENERATION, encoded, sort, page)
        cached = self._get_cached(key, HOME_CACHE_TTL)
        if cached is not None:
            return cached
        params = {"ajax": 1, "tab": "movies,tvshows"}
        if sort and sort != "relevance":
            params["sort"] = sort
        if page > 1:
            params["page"] = page
        document, error = self._fetch_listing("%s/search/%s" % (BASE, encoded), params, ajax=True)
        if error:
            return self._listing_error(page, error)
        items = self._parse_home_html(document, None)
        active, total = page_identity(document, self._html_attr)
        if (active is not None and active != page) or (not items and not has_empty_results(document)):
            return self._listing_error(page, "invalid_response")
        result = {"items": items, "page": page, "total_pages": max(page, total)}
        return self._set_cached(key, result, HOME_CACHE_TTL)

    # ── browse (home page, cached) ────────────────────────────────────

    def _fetch_home_html(self):
        cached = self._get_cached("home_html", HOME_CACHE_TTL)
        if cached:
            _log("browse: home cache hit")
            return cached, None
        _log("browse: fetching home page")
        html, error = self._fetch_listing(BASE + "/home", referer=BASE)
        if error:
            return None, error
        # Raw HTML stays memory-only: large, and poisonable on auth failure.
        return self._set_cached("home_html", html, HOME_CACHE_TTL, disk=False), None

    def browse_home(self, filter_type=None):
        key = "home_items:%s" % (filter_type or "all")
        cached = self._get_cached(key, HOME_CACHE_TTL)
        if cached is not None:
            _log("browse: home items cache hit (%s)" % key)
            return cached
        with _feed_lock("home" if not filter_type else None):
            self._disk_cache = None
            cached = self._get_cached(key, HOME_CACHE_TTL)
            if cached is not None:
                return cached
            return self._load_home_items(key, filter_type)

    def _load_home_items(self, key, filter_type):
        html, error = self._fetch_home_html()
        if error:
            return self._saved_catalog(key, error) or []
        items = self._parse_home_html(html, filter_type)
        if items:
            self._set_cached(key, items, HOME_CACHE_TTL)
        return items

    def get_genres(self, kind):
        """Return alphabetized genre names for kind ('movies' | 'tvshows').

        Flixtor's current shell uses generic search-filter controls with
        data-filter="genre" and data-val attributes. Legacy data-gn values are
        still accepted so the parser remains compatible during site rollouts.
        """
        cache_key = "genres:%s:%s" % (CATALOG_CACHE_GENERATION, kind)
        cached = self._get_cached(cache_key, SHOW_CACHE_TTL)
        if cached is not None:
            return cached
        self._ensure_login()
        shell_url = "%s/show/%s" % (BASE, kind)
        try:
            html = self._get(shell_url, headers={"Referer": BASE + "/"})
        except Exception as e:
            _log("genres: fetch failed for %s: %s" % (kind, e))
            return []
        if self._looks_like_auth_failure(html) or "showPageType" not in html:
            _log("genres: shell requires re-login for %s" % kind)
            if not self._relogin():
                return []
            try:
                html = self._get(shell_url, headers={"Referer": BASE + "/"})
            except Exception as e:
                _log("genres: fetch failed after relogin for %s: %s" % (kind, e))
                return []
            if self._looks_like_auth_failure(html) or "showPageType" not in html:
                return []
        self._mark_shell_warmed(kind)
        names = self._parse_genres_html(html)
        if not names:
            _log("genres: filter controls not found for %s" % kind)
            return []
        return self._set_cached(cache_key, names, SHOW_CACHE_TTL)

    @staticmethod
    def _html_attr(tag, name):
        match = re.search(
            r"\b%s\s*=\s*(['\"])(.*?)\1" % re.escape(name),
            tag or "",
            re.IGNORECASE | re.DOTALL,
        )
        return html_lib.unescape(match.group(2)).strip() if match else ""

    @staticmethod
    def _parse_genres_html(html):
        names = set()
        for tag in re.findall(r"<[^>]+>", html or "", re.DOTALL):
            if FlixtorClient._html_attr(tag, "data-filter").lower() != "genre":
                continue
            value = FlixtorClient._html_attr(tag, "data-val")
            if value and value.lower() != "all":
                names.add(value)
        # Compatibility fallback for the retired genre-specific control.
        for value in re.findall(
                r"\bdata-gn\s*=\s*(['\"])(.*?)\1", html or "",
                re.IGNORECASE | re.DOTALL):
            name = html_lib.unescape(value[1]).strip()
            if name and name.lower() != "all":
                names.add(name)
        return sorted(names, key=lambda value: value.casefold())

    # ── browse (full catalog, paginated, cached) ──────────────────────

    def browse_catalog(self, kind, sort="latest", page=1, genre="all", language="all"):
        """Fetch and validate a full catalog document; AJAX pagination is broken."""
        if kind not in ("movies", "tvshows", "episodes") or page < 1:
            return self._listing_error(page, "invalid_response")
        if sort == "new":
            return self.browse_recent(kind, page)
        if sort not in ("latest", "best", "name"):
            return self._listing_error(page, "invalid_response")
        key = "catalog:%s:%s:%s:%s:%s:%d" % (
            CATALOG_CACHE_GENERATION, kind, sort, language, genre, page)
        cached = self._get_cached(key, HOME_CACHE_TTL)
        if cached is not None:
            return cached
        shared = page == 1 and language == "all" and genre == "all" and sort in ("latest", "best")
        if shared:
            with _feed_lock(kind + "-" + sort):
                self._disk_cache = None
                cached = self._get_cached(key, HOME_CACHE_TTL)
                if cached is not None:
                    return cached
                return self._load_catalog(key, kind, sort, page, genre, language)
        return self._load_catalog(key, kind, sort, page, genre, language)

    def _load_catalog(self, key, kind, sort, page, genre, language):
        params = {"sort": sort, "page": page}
        if language and language != "all":
            params["lang"] = language
        if genre and genre != "all":
            params["genre"] = genre
        document, error = self._fetch_listing("%s/show/%s" % (BASE, kind), params)
        if error:
            return self._saved_catalog(key, error) or self._listing_error(page, error)
        validated = validate_catalog(document, kind, sort, page, self._html_attr)
        if validated is None:
            return self._listing_error(page, "invalid_response")
        content, total = validated
        expected_type = "movie" if kind == "movies" else "tv"
        items = self._parse_home_html(content, expected_type)
        if not items and not has_empty_results(content):
            return self._listing_error(page, "invalid_response")
        result = {"items": items, "page": page, "total_pages": total}
        return self._set_cached(key, result, HOME_CACHE_TTL)

    def browse_recent(self, kind, page=1):
        if kind not in ("movies", "tvshows") or page < 1:
            return self._listing_error(page, "invalid_response")
        key = "recent:%s:%s" % (CATALOG_CACHE_GENERATION, kind)
        items = self._get_cached(key, HOME_CACHE_TTL)
        if items is None:
            media, feed, container = (("movie", "m", "contentListM") if kind == "movies"
                                      else ("tv", "t", "contentListT"))
            document, error = self._fetch_listing(BASE + "/ajax/listhome/" + feed + "/new", ajax=True)
            if error:
                items = self._saved_catalog(key, error)
                if items is None:
                    return self._listing_error(page, error)
            else:
                content = element_contents(document, container, attribute="class")
                if content is None:
                    return self._listing_error(page, "invalid_response")
                items = self._parse_home_html(content, media)
                if not items and not has_empty_results(content):
                    return self._listing_error(page, "invalid_response")
                self._set_cached(key, items, HOME_CACHE_TTL)
        total = max(1, (len(items) + 23) // 24)
        if page > total:
            return self._listing_error(page, "invalid_response")
        return {"items": items[(page - 1) * 24:page * 24], "page": page, "total_pages": total}

    @staticmethod
    def _parse_home_html(html, filter_type):
        results = []
        seen = set()
        card_starts = []
        for match in re.finditer(r"<div\b[^>]*>", html or "", re.IGNORECASE):
            classes = FlixtorClient._html_attr(match.group(0), "class").split()
            if "cflip" in classes:
                card_starts.append(match)

        for index, match in enumerate(card_starts):
            end = (
                card_starts[index + 1].start()
                if index + 1 < len(card_starts) else len(html)
            )
            card_html = html[match.start():end]
            href = FlixtorClient._html_attr(match.group(0), "data-href")
            if not href:
                href_match = re.search(
                    r"\bdata-href\s*=\s*(['\"])(/watch/.*?)\1",
                    card_html,
                    re.IGNORECASE | re.DOTALL,
                )
                href = href_match.group(2) if href_match else ""
            watch = re.match(
                r"^/watch/(movie|tv)/(\d+)/([^/?#\"']+)", href
            )
            if not watch:
                continue
            media_type, pid, slug = watch.groups()
            if filter_type and media_type != filter_type:
                continue
            identity = (media_type, pid)
            if identity in seen:
                continue
            seen.add(identity)
            title = slug.replace("-", " ").title()
            tm = re.search(r'card-footer[^>]*>([^<]+)<', card_html)
            if tm:
                title = html_lib.unescape(tm.group(1)).strip()
            else:
                tm2 = re.search(r'class="[^"]*title[^"]*"[^>]*>([^<]+)<', card_html)
                if tm2:
                    title = html_lib.unescape(tm2.group(1)).strip()
            img_m = re.search(
                r'(?:src|data-src)\s*=\s*(["\'])'
                r'(https://img\.xcdn\.to/t/p/w342.*?)\1',
                card_html,
                re.IGNORECASE | re.DOTALL,
            )
            poster = img_m.group(2).replace("/w342/", "/w500/") if img_m else ""
            year_m = re.search(r'badge[^>]*>(\d{4})<', card_html)
            year = year_m.group(1) if year_m else ""
            rating_m = re.search(r'fa-star[^>]*></span>([\d.]+)', card_html)
            rating = rating_m.group(1) if rating_m else ""
            genre_m = re.search(r'genres[^>]*>([^<]+)<', card_html)
            genres = genre_m.group(1).strip() if genre_m else ""
            results.append({
                "title": title, "pid": pid, "slug": slug,
                "media_type": media_type, "poster": poster,
                "year": year, "rating": rating, "rating_provider": "flixtor", "genres": genres,
            })
        return results

    # ── TV show seasons & episodes (cached) ───────────────────────────

    def _fetch_show_html(self, pid, slug):
        key = "show_%s" % pid
        cached = self._get_cached(key, SHOW_CACHE_TTL)
        if cached:
            return cached
        _log("fetch show: pid=%s" % pid)
        self._ensure_login()
        try:
            html = self._get(
                "%s/watch/tv/%s/%s" % (BASE, pid, slug),
                headers={"Referer": BASE + "/home"},
            )
        except Exception as e:
            _log("fetch show: network error: %s" % e)
            return ""
        if self._looks_like_auth_failure(html):
            _log("fetch show: auth failure detected, re-logging in")
            if not self._relogin():
                return ""  # never cache the login page
            try:
                html = self._get(
                    "%s/watch/tv/%s/%s" % (BASE, pid, slug),
                    headers={"Referer": BASE + "/home"},
                )
            except Exception as e:
                _log("fetch show: network error after relogin: %s" % e)
                return ""
        # Raw HTML stays memory-only: large, and poisonable on auth failure.
        return self._set_cached(key, html, SHOW_CACHE_TTL, disk=False)

    def get_seasons(self, pid, slug):
        # Parsed result is disk-cached so the show→seasons→episodes→play
        # navigation chain (each step a new process) fetches the show page
        # once per TTL instead of every step. The resolve-time watch-page
        # GET in _resolve() is unaffected — the CDN requires that visit.
        cache_key = "seasons:%s" % pid
        cached = self._get_cached(cache_key, SHOW_CACHE_TTL)
        if cached is not None:
            # JSON round-trips dict keys as strings; season math needs ints
            # (str keys would empty the episode fallback and TypeError-crash
            # the next-episode comparison).
            return {int(s): eps for s, eps in cached.items()}
        html = self._fetch_show_html(pid, slug)
        seasons = {}
        show_pid = str(pid)
        # The show page mixes two kinds of episode cards with identical data-pes/
        # data-pep markup: (1) this show's own episodes, and (2) "similar shows"
        # episode cards pointing to unrelated titles. The distinguishing signal is
        # that similar-show cards contain a /watch/tv/OTHERPID/ link to a different
        # show. Legit episode cards have no such link (you're already on the show
        # page) — so a match whose trailing context contains a /watch/tv/ link to
        # a pid != show_pid is filtered out.
        matches = list(re.finditer(
            r'data-pes="(\d+)"[^>]*data-pep="(\d+)"', html
        ))
        for i, match in enumerate(matches):
            next_start = matches[i + 1].start() if i + 1 < len(matches) else len(html)
            suffix = html[match.end():min(next_start, match.end() + 600)]
            link_m = re.search(r'/watch/tv/(\d+)/', suffix)
            if link_m and link_m.group(1) != show_pid:
                continue
            s, e = int(match.group(1)), int(match.group(2))
            seasons.setdefault(s, set()).add(e)
        result = {s: sorted(eps) for s, eps in sorted(seasons.items())}
        if result:  # empty could be a bad parse — don't persist it
            rows = self._parse_episode_rows(html)
            now = time.time()
            entries = {cache_key: {"data": result, "ts": now, "ttl": SHOW_CACHE_TTL}}
            # Group adjacent seasons so a long series doesn't evict one Home
            # feed per season from the shared 50-entry cache. Oversized groups
            # retain the existing per-season fetch/cache fallback.
            groups = {}
            for number, episodes in rows.items():
                groups.setdefault(number // 8, {})[str(number)] = episodes
            for group, seasons_in_group in groups.items():
                entries["episode_rows:%s:%s" % (pid, group)] = {
                    "data": seasons_in_group, "ts": now, "ttl": SHOW_CACHE_TTL}
            for key, entry in entries.items():
                self._cache[key] = (now, entry["data"])
            self._update_disk_entries({key: entry for key, entry in entries.items()
                                       if len(json.dumps(entry["data"])) <= API_CACHE_MAX_ENTRY_BYTES})
        return result

    def get_episodes(self, pid, slug, season):
        cache_key = "episodes:%s:%s" % (pid, season)
        group = self._get_cached("episode_rows:%s:%s" % (pid, int(season) // 8), SHOW_CACHE_TTL)
        if group and str(season) in group:
            return group[str(season)]
        cached = self._get_cached(cache_key, SHOW_CACHE_TTL)
        if cached is not None:
            return cached
        html = self._fetch_show_html(pid, slug)
        episodes = self._parse_episode_rows(html).get(int(season), [])
        if episodes:
            self._set_cached(cache_key, episodes, SHOW_CACHE_TTL)
        return episodes

    @staticmethod
    def _parse_episode_rows(html):
        seasons = {}
        for row_match in re.finditer(
            r'<tr[^>]*data-pes="(\d+)"[^>]*data-pep="(\d+)"[^>]*>(.*?)</tr>',
            html, re.DOTALL,
        ):
            season, episode, row_html = row_match.groups()
            episodes = seasons.setdefault(int(season), {})
            ep_num = int(episode)
            if ep_num in episodes:
                continue
            title_m = re.search(r'class="epTitle"[^>]*>([^<]+)<', row_html)
            ep_title = title_m.group(1).strip() if title_m else ""
            date_m = re.search(r'content="([^"]+)"[^>]*class="middle nowrap"', row_html)
            if not date_m:
                date_m = re.search(r'class="middle nowrap".*?content="([^"]+)"', row_html, re.DOTALL)
            air_date = date_m.group(1).strip() if date_m else ""
            if not air_date:
                date_m2 = re.search(r'hidden-lg-down">([^<]+)<', row_html)
                air_date = date_m2.group(1).strip() if date_m2 else ""
            thumb_m = re.search(r'data-img="([^"]+)"', row_html)
            thumb = IMG_BASE + "/w300" + thumb_m.group(1) if thumb_m else ""
            episodes[ep_num] = {
                "episode": ep_num, "title": ep_title,
                "air_date": _parse_flixtor_date(air_date), "thumb": thumb,
            }
        return {season: [rows[n] for n in sorted(rows)] for season, rows in seasons.items()}

    @staticmethod
    def _extract_trailer(html):
        """Extract first YouTube trailer ID from detail page HTML."""
        m = re.search(r'data-ytlink="([^"]+)"', html)
        if m:
            return "plugin://plugin.video.youtube/play/?video_id=%s" % m.group(1)
        return ""

    @staticmethod
    def _extract_recommendations(html):
        """Extract recommendation cards from detail page HTML."""
        results = []
        rec_start = html.find("section-watch-recommendations")
        if rec_start < 0:
            return results
        # Section may not have </section> — use a generous slice
        rec_end = html.find("</section>", rec_start)
        if rec_end < 0:
            rec_end = min(rec_start + 50000, len(html))
        rec_html = html[rec_start:rec_end]
        seen = set()
        for match in re.finditer(
            r'data-href="(/watch/(movie|tv)/(\d+)/([^"]+))"', rec_html
        ):
            path, media_type, pid, slug = match.groups()
            if pid in seen:
                continue
            seen.add(pid)
            title = slug.replace("-", " ").title()
            # Try to get alt text or title from nearby img
            img_m = re.search(
                r'data-href="' + re.escape(path) + r'".*?alt="([^"]*)"',
                rec_html, re.DOTALL,
            )
            if img_m and img_m.group(1):
                title = img_m.group(1)
            poster_m = re.search(
                r'data-href="' + re.escape(path) + r'".*?src="([^"]+)"',
                rec_html, re.DOTALL,
            )
            poster = poster_m.group(1).replace("/w342/", "/w500/") if poster_m else ""
            results.append({
                "title": title, "pid": pid, "slug": slug,
                "media_type": media_type, "poster": poster,
                "year": "", "rating": "", "genres": "",
            })
        return results

    def get_show_info(self, pid, slug):
        cache_key = "show_info:%s" % pid
        cached = self._get_cached(cache_key, SHOW_CACHE_TTL)
        if cached is not None:
            return cached
        html = self._fetch_show_html(pid, slug)
        info = {"title": slug.replace("-", " ").title(), "poster": "", "plot": "", "genres": "", "year": "", "rating": "", "trailer": ""}
        tm = re.search(r"<title>Watch (?:all Episodes of )?(.+?) \((\d{4})\)", html)
        if tm:
            info["title"] = tm.group(1)
            info["year"] = tm.group(2)
        img_m = re.search(r'src="(https://img\.xcdn\.to/t/p/w342[^"]+)"', html)
        if img_m:
            info["poster"] = img_m.group(1).replace("/w342/", "/w500/")
        rating_m = re.search(r'Rated:.*?([\d.]+)\s*out of 10', html)
        if rating_m:
            info["rating"] = rating_m.group(1)
        plot_m = re.search(r'watch-moreless-less"[^>]*>([^<]+)<', html)
        if plot_m:
            info["plot"] = plot_m.group(1).strip()
        genre_m = re.search(r'genres[^>]*>([^<]+)<', html)
        if genre_m:
            info["genres"] = genre_m.group(1).strip()
        info["trailer"] = self._extract_trailer(html)
        # An all-defaults dict means the page didn't parse (empty/login
        # HTML) — that's a poisoning signature, not a cacheable answer.
        if tm or info["poster"]:
            self._set_cached(cache_key, info, SHOW_CACHE_TTL)
        return info

    # ── movie detail ──────────────────────────────────────────────────

    def get_movie_info(self, pid, slug):
        key = "movie_%s" % pid
        cached = self._get_cached(key, SHOW_CACHE_TTL)
        if cached:
            return cached
        empty = {"plot": "", "genres": "", "year": "", "rating": "", "mpaa": "", "trailer": "", "recommendations": []}
        self._ensure_login()
        url = "%s/watch/movie/%s/%s" % (BASE, pid, slug)
        try:
            html = self._get(url, headers={"Referer": BASE + "/home"})
        except Exception as e:
            _log("get_movie_info: network error: %s" % e)
            return dict(empty)
        if self._looks_like_auth_failure(html):
            _log("get_movie_info: auth failure detected, re-logging in")
            if not self._relogin():
                return dict(empty)  # never cache the login page
            try:
                html = self._get(url, headers={"Referer": BASE + "/home"})
            except Exception as e:
                _log("get_movie_info: network error after relogin: %s" % e)
                return dict(empty)
        info = dict(empty)
        tm = re.search(r"<title>Watch .+? \((\d{4})\)", html)
        if tm:
            info["year"] = tm.group(1)
        rating_m = re.search(r'Rated:.*?([\d.]+)\s*out of 10', html)
        if rating_m:
            info["rating"] = rating_m.group(1)
        plot_m = re.search(r'watch-moreless-less"[^>]*>([^<]+)<', html)
        if plot_m:
            info["plot"] = plot_m.group(1).strip()
        genre_m = re.search(r'genres[^>]*>([^<]+)<', html)
        if genre_m:
            info["genres"] = genre_m.group(1).strip()
        mpaa_m = re.search(r'fa-certificate[^>]*></span>\s*([A-Z][A-Z0-9-]*)', html)
        if mpaa_m:
            info["mpaa"] = mpaa_m.group(1).strip()
        info["trailer"] = self._extract_trailer(html)
        info["recommendations"] = self._extract_recommendations(html)
        # All-defaults dict = page didn't parse — don't cache the failure.
        if info["year"] or info["plot"] or info["trailer"] or info["recommendations"]:
            return self._set_cached(key, info, SHOW_CACHE_TTL)
        return info

    def get_recommendations(self, pid, slug, media_type="movie"):
        """Get recommended titles from a movie/TV detail page."""
        if media_type == "movie":
            info = self.get_movie_info(pid, slug)
        else:
            cache_key = "recs_tv:%s" % pid
            cached = self._get_cached(cache_key, SHOW_CACHE_TTL)
            if cached is not None:
                return cached
            html = self._fetch_show_html(pid, slug)
            recs = self._extract_recommendations(html)
            if recs:
                self._set_cached(cache_key, recs, SHOW_CACHE_TTL)
            return recs
        return info.get("recommendations", [])

    def get_trailer(self, pid, slug, media_type="movie"):
        """Get YouTube trailer URL from a movie/TV detail page."""
        if media_type == "movie":
            info = self.get_movie_info(pid, slug)
        else:
            info = self.get_show_info(pid, slug)
        return info.get("trailer", "")

    # ── resolve stream ────────────────────────────────────────────────

    def resolve_movie(self, pid, slug=""):
        return self._resolve("m", pid, slug=slug)

    def resolve_episode(self, pid, season, episode, slug=""):
        return self._resolve("e", pid, season, episode, slug=slug)

    def _resolve(self, kind, pid, season=None, episode=None, slug=""):
        _log("resolve: kind=%s pid=%s season=%s episode=%s" % (kind, pid, season, episode))
        self._ensure_login()
        # Visit the watch page first — CDN validates the token only after this.
        # The slug is required in the URL; without it the CDN rejects the stream.
        watch_type = "movie" if kind == "m" else "tv"
        watch_url = "%s/watch/%s/%s/%s" % (BASE, watch_type, pid, slug)
        try:
            page_html = self._get(watch_url, headers={"Referer": BASE + "/home"})
        except (urllib.error.URLError, OSError) as e:
            _log("resolve: watch page network error: %s" % e)
            return {"error": "network", "detail": str(e)}

        if self._looks_like_auth_failure(page_html):
            _log("resolve: auth failure on watch page, re-logging in")
            if not self._relogin():
                return {"error": "network", "detail": "Re-authentication failed"}
            try:
                page_html = self._get(watch_url, headers={"Referer": BASE + "/home"})
            except (urllib.error.URLError, OSError) as e:
                _log("resolve: watch page network error after relogin: %s" % e)
                return {"error": "network", "detail": str(e)}

        if kind == "e" and season is not None:
            url = "%s/%s/%s/%s/%s" % (VIDEO_AJAX, kind, pid, season, episode)
        else:
            url = "%s/%s/%s" % (VIDEO_AJAX, kind, pid)

        # Fetch stream data — retry once on auth failure
        for attempt in range(2):
            try:
                html = self._get(
                    url,
                    params={"_": int(time.time() * 1000)},
                    headers={
                        "Referer": watch_url,
                        "X-Requested-With": "XMLHttpRequest",
                    },
                )
            except (urllib.error.URLError, OSError) as e:
                _log("resolve: AJAX network error: %s" % e)
                return {"error": "network", "detail": str(e)}
            if not html:
                _log("resolve: empty response from AJAX")
                return {"error": "empty", "detail": "Server returned empty response"}
            try:
                decoded = self._decode_video_response(html)
                result = json.loads(decoded)
                if not isinstance(result, dict) or not isinstance(result.get("file"), str):
                    # Could be auth failure disguised as bad data — retry once
                    if attempt == 0:
                        _log("resolve: invalid stream data, retrying after relogin")
                        if self._relogin():
                            page_html = ""
                            try:
                                page_html = self._get(watch_url, headers={"Referer": BASE + "/home"})
                            except (urllib.error.URLError, OSError):
                                pass
                            continue
                    _log("resolve: invalid stream data structure")
                    return {"error": "decode", "detail": "Invalid stream data"}
                if not isinstance(result.get("tracks"), list):
                    result["tracks"] = []
                if kind == "e" and 'data-pes="' in page_html and not self._looks_like_auth_failure(page_html):
                    self._set_cached("show_%s" % pid, page_html, SHOW_CACHE_TTL, disk=False)
                _log("resolve: success, got m3u8 URL")
                return result
            except Exception as e:
                if attempt == 0:
                    _log("resolve: decode error on attempt 1, retrying: %s" % e)
                    if self._relogin():
                        page_html = ""
                        try:
                            page_html = self._get(watch_url, headers={"Referer": BASE + "/home"})
                        except (urllib.error.URLError, OSError):
                            pass
                        continue
                _log("resolve: decode error: %s" % e)
                return {"error": "decode", "detail": str(e)}
        return {"error": "decode", "detail": "Failed after retry"}
