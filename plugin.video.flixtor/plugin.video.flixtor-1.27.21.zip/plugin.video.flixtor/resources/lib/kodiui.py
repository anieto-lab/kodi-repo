"""Small Kodi UI-setting helpers shared by the plug-in and resident service."""

import json


PARENT_ITEMS_SETTING = "filelists.showparentdiritems"

# Kodi 20+ writes these directly to the video's information tag.
_VIDEO_SETTERS = {
    "title": "setTitle", "tvshowtitle": "setTvShowTitle", "plot": "setPlot",
    "mediatype": "setMediaType", "year": "setYear", "season": "setSeason",
    "episode": "setEpisode", "aired": "setFirstAired", "playcount": "setPlaycount",
}


def set_video_info(item, info):
    tag = item.getVideoInfoTag() if hasattr(item, "getVideoInfoTag") else None
    if not hasattr(tag, "setTitle"):
        item.setInfo("video", info)
        return
    for name, value in info.items():
        if name == "genre":
            tag.setGenres(value.split(" / ") if isinstance(value, str) else value)
        else:
            getattr(tag, _VIDEO_SETTERS[name])(value)


def set_rating(item, provider, score, votes, default):
    tag = item.getVideoInfoTag() if hasattr(item, "getVideoInfoTag") else None
    if hasattr(tag, "setRating"):
        tag.setRating(score, votes, provider, default)
    else:
        item.setRating(provider, score, votes, default)


def set_resume_point(item, position, total):
    tag = item.getVideoInfoTag() if hasattr(item, "getVideoInfoTag") else None
    if hasattr(tag, "setResumePoint"):
        tag.setResumePoint(position, total)
    else:
        item.setProperty("ResumeTime", str(position))
        item.setProperty("TotalTime", str(total))


def set_parent_folder_items(visible):
    """Set Kodi's parent-folder preference only when its value must change."""
    import xbmc

    visible = bool(visible)
    try:
        get_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.GetSettingValue",
            "params": {"setting": PARENT_ITEMS_SETTING},
        })
        current = json.loads(xbmc.executeJSONRPC(get_request))
        if current.get("result", {}).get("value") is visible:
            return False

        set_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": PARENT_ITEMS_SETTING,
                "value": visible,
            },
        })
        result = json.loads(xbmc.executeJSONRPC(set_request))
        if result.get("result") != "OK":
            raise RuntimeError("unexpected JSON-RPC response: %r" % result)
        xbmc.log(
            "FLIXTOR: Kodi parent-folder cards %s"
            % ("restored" if visible else "hidden at Flixtor root"),
            xbmc.LOGINFO,
        )
        return True
    except Exception as exc:
        xbmc.log(
            "FLIXTOR: could not update parent-folder cards: %s" % exc,
            xbmc.LOGINFO,
        )
        return False
