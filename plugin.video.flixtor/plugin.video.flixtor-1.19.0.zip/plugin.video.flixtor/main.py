"""Flixtor Kodi addon — browse, search, and stream movies/TV from Flixtor VIP."""

import base64
import hashlib
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import uuid
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import xbmc
from resources.lib.flixtor import FlixtorClient, _cookie_path
from resources.lib.tmdb import TmdbClient
from resources.lib.watchhistory import WatchHistory, SearchHistory, FavoritesHistory

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
PAGE_SIZE = 24
NEXT_PAGE_ICON = "special://home/addons/plugin.video.flixtor/resources/media/next.png"
_OBF_PREFIX = "__obf1__"

_client = None
_tmdb = None
_has_youtube_cached = None
_device_key_cached = None


def _rating_enrichment_enabled():
    """True unless the user disabled the rating-strip TMDb lookup in Settings."""
    return ADDON.getSetting("rating_enrichment") != "false"


def _get_tmdb():
    """Lazy TmdbClient singleton. Returns None when enrichment is disabled so
    callers can skip lookups without additional conditionals."""
    global _tmdb
    if not _rating_enrichment_enabled():
        return None
    if _tmdb is None:
        _tmdb = TmdbClient()
    return _tmdb


def _attach_tmdb_id(li, tmdb_id):
    """Set uniqueid.tmdb on a ListItem so TMDb Helper's service monitor can
    enrich container 99950 (powers AH2's rating strip). No-op on falsy ids."""
    if not tmdb_id:
        return
    try:
        li.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
    except Exception as exc:
        _log("tmdb: setUniqueIDs failed: %s" % exc)


_favorites_pid_cache = None


def _favorites_pid_set():
    """Lazily load the favorited pid set for this plugin process. Avoids
    re-reading favorites.json for every item in a directory listing."""
    global _favorites_pid_cache
    if _favorites_pid_cache is None:
        _favorites_pid_cache = {
            str(i.get("pid", "")) for i in FavoritesHistory().get_all()
        }
    return _favorites_pid_cache


def _favorites_context_item(pid, item_payload=None):
    """Return a (label, RunPlugin(...)) context menu tuple that toggles
    between adding and removing from the addon's Favorites depending on
    current state. ``item_payload`` is the dict of fields to persist on add
    (title, slug, poster, etc.); only the pid is needed for remove."""
    pid_str = str(pid)
    if pid_str in _favorites_pid_set():
        return (
            "Remove from Favorites",
            "RunPlugin(%s)" % build_url("ctx_remove_favorite", pid=pid_str),
        )
    payload = dict(item_payload or {})
    payload["pid"] = pid_str
    return (
        "Add to Favorites",
        "RunPlugin(%s)" % build_url("ctx_add_favorite", **payload),
    )


def _prefetch_tmdb(items):
    """Batch-resolve TMDb IDs for a list of item dicts. Mutates each item with
    an ``item['tmdb_id']`` key. No-op when enrichment is disabled."""
    client = _get_tmdb()
    if client and items:
        client.lookup_many(items)


def _log(msg):
    xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)


def _has_youtube():
    """Cached check for the YouTube plugin. Re-evaluated per plugin process."""
    global _has_youtube_cached
    if _has_youtube_cached is None:
        _has_youtube_cached = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.youtube)"
        ) == 1
    return _has_youtube_cached


def _device_key():
    """Stable per-device key derived from MAC address. Used for password obfuscation."""
    global _device_key_cached
    if _device_key_cached is None:
        _device_key_cached = hashlib.sha256(str(uuid.getnode()).encode()).digest()
    return _device_key_cached


def _legacy_deobfuscate(b64):
    """Best-effort reverse of the legacy v1.10-v1.13.x obfuscation. Returns '' on
    any decoding error. Kept only for one-shot migration away from the obfuscated
    form — the new code stores passwords as plaintext (masked in the UI via
    option='hidden'). The obfuscation used `uuid.getnode()` as its key, which on
    Fire TV falls back to a RANDOM value per plugin process when the Android
    sandbox blocks MAC discovery, silently corrupting the stored password."""
    if not b64:
        return ""
    try:
        xored = base64.b64decode(b64.encode("ascii"))
    except Exception:
        return ""
    key = _device_key()
    raw = bytes(b ^ key[i % len(key)] for i, b in enumerate(xored))
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return ""


def _read_password():
    """Read the VIP password from settings.

    Legacy obfuscated values (prefixed with `__obf1__`, written by v1.10-v1.13.x)
    are best-effort recovered and rewritten as plaintext. If recovery fails —
    likely because `uuid.getnode()` returned a different value than when the
    password was encoded — the setting is cleared to force a single re-auth.
    """
    raw = ADDON.getSetting("password") or ""
    if raw.startswith(_OBF_PREFIX):
        decoded = _legacy_deobfuscate(raw[len(_OBF_PREFIX):])
        # Sanity check: a real password is non-empty printable ASCII. Deobfuscation
        # with a mismatched key yields non-printable byte garbage that may still
        # pass the UTF-8 decode in _legacy_deobfuscate.
        if decoded and all(32 <= ord(c) < 127 for c in decoded):
            _log("password: migrated legacy obfuscated value to plaintext")
            ADDON.setSetting("password", decoded)
            return decoded
        _log("password: legacy obfuscated value unrecoverable; clearing (re-auth required)")
        ADDON.setSetting("password", "")
        return ""
    return raw


def _show_qr_dialog():
    """Show a fullscreen dialog with the QR code for flixtor.to/donate."""
    qr_path = os.path.join(ADDON.getAddonInfo("path"), "resources", "qr_donate.png")
    # Create a custom window with the QR code centered and instructions
    window = xbmcgui.WindowDialog()
    # Semi-transparent dark background
    window.addControl(xbmcgui.ControlImage(0, 0, 1920, 1080, "", colorDiffuse="CC000000"))
    # QR code centered (400x400 in the middle of 1280x720)
    qr_size = 400
    qr_x = (1280 - qr_size) // 2
    qr_y = 180
    window.addControl(xbmcgui.ControlImage(qr_x, qr_y, qr_size, qr_size, qr_path))
    # Instructions above
    label1 = xbmcgui.ControlLabel(0, 80, 1280, 60, "Scan with your phone to sign up for Flixtor VIP",
                                   alignment=0x00000002, textColor="FFFFFFFF", font="font14")
    window.addControl(label1)
    # URL below QR
    label2 = xbmcgui.ControlLabel(0, qr_y + qr_size + 30, 1280, 40, "flixtor.to/donate",
                                   alignment=0x00000002, textColor="FF00BFFF", font="font14")
    window.addControl(label2)
    # Dismiss instruction
    label3 = xbmcgui.ControlLabel(0, qr_y + qr_size + 90, 1280, 40, "Press any button to close",
                                   alignment=0x00000002, textColor="FF888888", font="font12")
    window.addControl(label3)
    window.doModal()
    del window


def _show_signup_prompt():
    """Show VIP signup info with pricing tiers, then offer to open settings or show QR code."""
    while True:
        choice = xbmcgui.Dialog().select(
            "Flixtor — VIP Account Required",
            [
                "Enter VIP Credentials (already have an account)",
                "Show QR Code to Sign Up (flixtor.to/donate)",
                "[COLOR grey]VIP Plans:  30 Days $14.95  |  90 Days $29.95  |  180 Days $49.95  |  2 Years $89.95[/COLOR]",
            ],
        )
        if choice == 0:
            ADDON.openSettings()
            break
        elif choice == 1:
            _show_qr_dialog()
            # After QR, loop back to let them enter credentials
        else:
            break


def _clear_stored_credentials():
    """Wipe email, password, and persisted cookies. Caller handles _client reset."""
    ADDON.setSetting("email", "")
    ADDON.setSetting("password", "")
    try:
        os.remove(_cookie_path())
    except OSError:
        pass


def do_sign_out():
    """Clear stored credentials, persisted cookies, and the in-memory client."""
    if not xbmcgui.Dialog().yesno("Flixtor", "Sign out of Flixtor on this device?"):
        return
    global _client
    _clear_stored_credentials()
    _client = None
    _log("sign_out: credentials cleared")
    xbmcgui.Dialog().notification("Flixtor", "Signed out.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _handle_auth_failure():
    """Prompt the user to fix their sign-in after a failed login."""
    choice = xbmcgui.Dialog().select(
        "Sign-in failed",
        [
            "Update email or password",
            "Sign in with a different account",
        ],
    )
    if choice == 0:
        ADDON.openSettings()
    elif choice == 1:
        _clear_stored_credentials()
        ADDON.openSettings()


def do_clear_watch_history():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your watch history? This can't be undone."):
        return
    WatchHistory().clear_all()
    _log("clear_watch_history: done")
    xbmcgui.Dialog().notification("Flixtor", "Watch history cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_favorites():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your favorites? This can't be undone."):
        return
    FavoritesHistory().clear_all()
    _log("clear_favorites: done")
    xbmcgui.Dialog().notification("Flixtor", "Favorites cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_searches():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your search history? This can't be undone."):
        return
    SearchHistory().clear_all()
    _log("clear_searches: done")
    xbmcgui.Dialog().notification("Flixtor", "Search history cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_tmdb_cache():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear cached TMDb lookups? Rating badges will refresh on next browse."):
        return
    TmdbClient().clear_cache()
    _log("clear_tmdb_cache: done")
    xbmcgui.Dialog().notification("Flixtor", "TMDb cache cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def get_client():
    global _client
    if _client is None:
        email = ADDON.getSetting("email")
        password = _read_password()
        if not email or not password:
            _show_signup_prompt()
            email = ADDON.getSetting("email")
            password = _read_password()
        if not email or not password:
            return None
        _client = FlixtorClient(email, password)
        login_result = _client.login()
        if login_result == "network_error":
            _log("get_client: login network error")
            xbmcgui.Dialog().ok("Flixtor", "Could not connect to Flixtor. Check your internet or try again later.")
            _client = None
        elif not login_result:
            _log("get_client: login failed (bad credentials)")
            _client = None
            _handle_auth_failure()
    return _client


def build_url(action, **kwargs):
    kwargs["action"] = action
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


# ── Main menu ────────────────────────────────────────────────────────

def main_menu():
    items = [
        ("Recently Watched", build_url("recent"), "DefaultRecentlyAddedMovies.png"),
        ("Favorites", build_url("favorites"), "DefaultFavourites.png"),
        ("Search", build_url("search"), "DefaultAddonsSearch.png"),
        ("Movies", build_url("movies"), "DefaultMovies.png"),
        ("TV Shows", build_url("tvshows"), "DefaultTVShows.png"),
        ("Browse All", build_url("home"), "DefaultVideo.png"),
    ]
    for label, url, icon in items:
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Search ────────────────────────────────────────────────────────────

def do_search():
    """Show search history menu: 'New Search...' + recent queries."""
    history = SearchHistory()
    recent = history.get_all()

    # "New Search..." always at top
    li = xbmcgui.ListItem("New Search...")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_url("new_search"), li, isFolder=True)

    for query in recent:
        url = build_url("search_execute", q=query)
        li = xbmcgui.ListItem(query)
        li.setArt({"icon": "DefaultAddonsSearch.png"})
        li.addContextMenuItems([
            ("Remove from Search History",
             "RunPlugin(%s)" % build_url("remove_search", q=query)),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def do_new_search():
    """Open keyboard, execute search, save to history."""
    kb = xbmc.Keyboard("", "Search Flixtor")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    _do_search_execute(query, save=True, page=1)


def do_search_execute(query, page=1):
    """Re-execute a saved search query (or paginate through it)."""
    _do_search_execute(query, save=(page == 1), page=page)


def _do_search_execute(query, save=False, page=1):
    """Run a search query and display one page of results."""
    _log("search: query=%s page=%d" % (query, page))
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        result = client.search(query, page=page)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    items = result.get("items") or []
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No results found.", xbmcgui.NOTIFICATION_INFO)
        return
    if save:
        SearchHistory().add(query)

    total_pages = result.get("total_pages") or page
    if page > 1 or total_pages > 1:
        xbmcplugin.setPluginCategory(HANDLE, "Search: %s (page %d/%d)" % (query, page, total_pages))

    _prefetch_tmdb(items)
    for item in items:
        add_content_item(item, show_type_label=True)

    if page < total_pages:
        url = build_url("search_execute", q=query, page=page + 1)
        li = xbmcgui.ListItem("Next Page (%d/%d) >>" % (page + 1, total_pages))
        li.setArt({"icon": NEXT_PAGE_ICON, "thumb": NEXT_PAGE_ICON, "poster": NEXT_PAGE_ICON})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.endOfDirectory(HANDLE)


def do_remove_search(query):
    """Remove a query from search history and refresh the listing."""
    SearchHistory().remove(query)
    xbmc.executebuiltin("Container.Refresh")


# ── Browse home (paginated) ──────────────────────────────────────────

def do_home(filter_type=None, action="home", page=0):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        all_items = client.browse_home(filter_type=filter_type)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not all_items:
        xbmcgui.Dialog().notification("Flixtor", "Could not load content. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # Paginate
    start = page * PAGE_SIZE
    end = start + PAGE_SIZE
    page_items = all_items[start:end]

    _prefetch_tmdb(page_items)

    # Show type labels only when content is mixed (Trending All)
    show_labels = filter_type is None
    for item in page_items:
        add_content_item(item, show_type_label=show_labels)

    # "Next Page" uses the same action so the filter stays implicit
    if end < len(all_items):
        url = build_url(action, page=page + 1)
        li = xbmcgui.ListItem(f"Next Page ({end}/{len(all_items)}) >>")
        li.setArt({"icon": NEXT_PAGE_ICON, "thumb": NEXT_PAGE_ICON, "poster": NEXT_PAGE_ICON})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    content = "movies" if filter_type == "movie" else "tvshows" if filter_type == "tv" else "videos"
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Catalog (full Flixtor library, paginated server-side) ────────────

# Each row maps to a dedicated action (action=<route>) rather than a sort=<key>
# query param, because Kodi silently strips some param names (e.g. `filter`,
# `resume_mode`) from plugin URLs. Dedicated routes are the safe pattern.
_CATALOG_ROUTES = {
    "movies_latest":    ("movies",   "latest", "Latest Additions"),
    "movies_best":      ("movies",   "best",   "Best Rated"),
    "movies_name":      ("movies",   "name",   "A\u2013Z"),
    "tvshows_latest":   ("tvshows",  "latest", "Latest Additions"),
    "tvshows_best":     ("tvshows",  "best",   "Best Rated"),
    "tvshows_name":     ("tvshows",  "name",   "A\u2013Z"),
}


_CATALOG_HEADINGS = {"movies": "Movies", "tvshows": "TV Shows"}

# Mapping from kind to the dedicated genre-picker action. Dedicated routes
# (rather than action=genres&kind=...) keep us safe from Kodi's URL param
# stripping, same reasoning as _CATALOG_ROUTES above.
_GENRE_PICKER_ROUTES = {
    "movies":  "genres_movies",
    "tvshows": "genres_tvshows",
}


def show_catalog_sort_picker(kind):
    """First level of Movies/TV Shows: pick a sort mode (or Browse by Genre)."""
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    for action, (k, _, label) in _CATALOG_ROUTES.items():
        if k != kind:
            continue
        url = build_url(action, page=1)
        li = xbmcgui.ListItem("%s \u2014 %s" % (heading, label))
        li.setArt({"icon": "DefaultFolder.png"})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    genre_action = _GENRE_PICKER_ROUTES.get(kind)
    if genre_action:
        url = build_url(genre_action)
        li = xbmcgui.ListItem("%s \u2014 Browse by Genre" % heading)
        li.setArt({"icon": "DefaultFolder.png"})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_genre_picker(kind):
    """Pick a genre, then jump straight to the Latest Additions catalog
    filtered to that genre."""
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        genres = client.get_genres(kind)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not genres:
        xbmcgui.Dialog().notification("Flixtor", "Could not load genres. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    xbmcplugin.setPluginCategory(HANDLE, "%s \u2014 Browse by Genre" % heading)
    latest_action = "%s_latest" % kind
    for genre in genres:
        url = build_url(latest_action, genre=genre, page=1)
        # Genre slugs use hyphens (e.g. "Science-Fiction") \u2014 show a friendlier label.
        label = genre.replace("-", " ")
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": "DefaultFolder.png"})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def do_catalog(action, kind, sort, page, genre="all"):
    """Second level: one page of the paginated catalog, optionally
    constrained to a single genre."""
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        result = client.browse_catalog(kind, sort=sort, page=page, genre=genre)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    items = result.get("items") or []
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "Could not load content. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if genre and genre != "all":
        heading = _CATALOG_HEADINGS.get(kind, kind.title())
        xbmcplugin.setPluginCategory(HANDLE, "%s \u2014 %s" % (heading, genre.replace("-", " ")))

    _prefetch_tmdb(items)

    for item in items:
        add_content_item(item, show_type_label=False)

    total_pages = result.get("total_pages") or page
    if page < total_pages:
        url = build_url(action, sort=sort, page=page + 1, genre=genre)
        li = xbmcgui.ListItem("Next Page (%d/%d) >>" % (page + 1, total_pages))
        li.setArt({"icon": NEXT_PAGE_ICON, "thumb": NEXT_PAGE_ICON, "poster": NEXT_PAGE_ICON})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    content = "movies" if kind == "movies" else "tvshows"
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(HANDLE)


# ── TV show: seasons ──────────────────────────────────────────────────

def show_seasons(pid, slug, title, poster):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        seasons = client.get_seasons(pid, slug)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not seasons:
        xbmcgui.Dialog().notification("Flixtor", "No episodes found.", xbmcgui.NOTIFICATION_INFO)
        return

    # Get show info for plot — but keep the poster from the listing (Flixtor's
    # detail page sometimes returns wrong poster art, e.g. ER for The Pitt)
    info = client.get_show_info(pid, slug)
    show_poster = poster or info.get("poster", "")
    plot = info.get("plot", "")
    trailer = info.get("trailer", "")
    year = info.get("year", "")

    tmdb_client = _get_tmdb()
    show_tmdb_id = tmdb_client.lookup(title, year, "tv") if tmdb_client else None

    for s_num in sorted(seasons.keys()):
        ep_count = len(seasons[s_num])
        label = f"Season {s_num} ({ep_count} episodes)"
        url = build_url("episodes", pid=pid, slug=slug, season=s_num, title=title, poster=show_poster)
        li = xbmcgui.ListItem(label)
        li.setArt({"poster": show_poster, "thumb": show_poster, "fanart": show_poster})
        # Deliberately avoid mediatype="season" and tvshowtitle — those signals
        # make Arctic Horizon 2 render the TV-show-info panel (which pulls a
        # Similar TV Shows widget from TMDb Helper) and show seasons as small
        # buttons at the bottom. We want a plain poster grid.
        li.setInfo("video", {
            "title": label,
            "plot": plot,
        })
        if info.get("rating"):
            li.setRating("imdb", float(info["rating"]))
        _attach_tmdb_id(li, show_tmdb_id)
        if trailer:
            li.setProperty("trailer", trailer)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


# ── TV show: episodes (rich) ─────────────────────────────────────────

def show_episodes(pid, slug, season, title, poster):
    client = get_client()
    if not client:
        return

    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        # Get show info for plot
        show_info = client.get_show_info(pid, slug)
        show_plot = show_info.get("plot", "")
        episodes = client.get_episodes(pid, slug, int(season))
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not episodes:
        # Fallback to basic listing
        seasons = client.get_seasons(pid, slug)
        ep_nums = seasons.get(int(season), [])
        episodes = [{"episode": e, "title": "", "air_date": "", "thumb": ""} for e in ep_nums]

    tmdb_client = _get_tmdb()
    show_tmdb_id = (
        tmdb_client.lookup(title, show_info.get("year", ""), "tv")
        if tmdb_client else None
    )

    for ep in episodes:
        ep_num = ep["episode"]
        ep_title = ep.get("title", "")
        air_date = ep.get("air_date", "")
        thumb = ep.get("thumb", "") or poster

        if ep_title:
            label = f"{ep_num}. {ep_title}"
        else:
            label = f"Episode {ep_num}"

        url = build_url(
            "play_episode", pid=pid, slug=slug,
            season=season, episode=ep_num, title=title, poster=poster,
        )
        li = xbmcgui.ListItem(label)
        li.setArt({"poster": poster, "thumb": thumb, "fanart": poster, "icon": thumb})
        info = {
            "title": ep_title or label,
            "tvshowtitle": title,
            "season": int(season),
            "episode": ep_num,
            "plot": show_plot,
            "mediatype": "episode",
        }
        if air_date:
            info["aired"] = air_date
        li.setInfo("video", info)
        _attach_tmdb_id(li, show_tmdb_id)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


# ── Play ──────────────────────────────────────────────────────────────

def _format_time(seconds):
    h, m, s = int(seconds // 3600), int((seconds % 3600) // 60), int(seconds % 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _ask_resume(resume_seconds):
    """Show resume dialog. Returns seek position (0 = from start, >0 = resume, -1 = cancelled)."""
    label = _format_time(resume_seconds)
    choice = xbmcgui.Dialog().contextmenu([
        f"Resume from {label}",
        "Play from beginning",
    ])
    if choice < 0:
        return -1
    return resume_seconds if choice == 0 else 0


def _error_message(error_type):
    """Return a user-friendly error message for a given error type."""
    if error_type == "network":
        return "Network error. Check your connection."
    if error_type == "empty":
        return "Server returned an empty response."
    return "Could not load stream. Try again later."


def _resolve_with_retry(resolve_func):
    """Call resolve_func with progress dialog and one retry on failure."""
    progress = xbmcgui.DialogProgress()
    progress.create("Flixtor", "Loading stream...")
    try:
        stream = resolve_func()
    finally:
        progress.close()

    for attempt in range(2):
        if stream and "error" not in stream:
            return stream
        if stream and "error" in stream:
            msg = _error_message(stream["error"])
            _log("resolve error (attempt %d): %s — %s" % (attempt + 1, stream["error"], stream.get("detail", "")))
            if attempt == 0:
                if not xbmcgui.Dialog().yesno("Flixtor", msg, yeslabel="Retry", nolabel="Cancel"):
                    return None
                progress = xbmcgui.DialogProgress()
                progress.create("Flixtor", "Retrying...")
                try:
                    stream = resolve_func()
                finally:
                    progress.close()
            else:
                xbmcgui.Dialog().ok("Flixtor", msg)
                return None
        else:
            xbmcgui.Dialog().notification("Flixtor", "Could not resolve stream.", xbmcgui.NOTIFICATION_ERROR)
            return None
    return stream


def play_movie(pid, title, poster, slug="", resume_mode=""):
    """resume_mode: '' = check history and ask, 'resume' = auto-resume, 'start' = play from beginning."""
    history = WatchHistory()
    seek_on_start = 0.0
    quality = ""

    if resume_mode == "resume":
        seek_on_start = history.get_resume_position(pid)
        quality = history.get_quality(pid)
    elif resume_mode == "start":
        pass  # seek_on_start = 0, quality = "" (ask)
    else:
        resume = history.get_resume_position(pid)
        if resume > 0:
            pref = ADDON.getSetting("resume_mode_default") or "0"
            if pref == "1":
                seek_on_start = resume
                quality = history.get_quality(pid)
            elif pref == "2":
                pass  # always start from beginning
            else:
                result = _ask_resume(resume)
                if result < 0:
                    return
                if result > 0:
                    seek_on_start = result
                    quality = history.get_quality(pid)

    client = get_client()
    if not client:
        return
    _log("play_movie: pid=%s slug=%s" % (pid, slug))
    stream = _resolve_with_retry(lambda: client.resolve_movie(pid, slug=slug))
    if not stream:
        return
    _play_stream(stream, title, poster, pid=pid, slug=slug,
                 media_type="movie", seek_on_start=seek_on_start, quality=quality)


def play_episode(pid, season, episode, title, poster, slug="", resume_mode=""):
    """resume_mode: '' = check history and ask, 'resume' = auto-resume, 'start' = play from beginning."""
    history = WatchHistory()
    seek_on_start = 0.0
    quality = ""
    try:
        s, e = int(season), int(episode)
    except (ValueError, TypeError):
        xbmcgui.Dialog().notification("Flixtor", "Invalid episode.", xbmcgui.NOTIFICATION_ERROR)
        return

    if resume_mode == "resume":
        seek_on_start = history.get_resume_position(pid, season=s, episode=e)
        quality = history.get_quality(pid, season=s, episode=e)
    elif resume_mode == "start":
        pass
    else:
        resume = history.get_resume_position(pid, season=s, episode=e)
        if resume > 0:
            pref = ADDON.getSetting("resume_mode_default") or "0"
            if pref == "1":
                seek_on_start = resume
                quality = history.get_quality(pid, season=s, episode=e)
            elif pref == "2":
                pass  # always start from beginning
            else:
                result = _ask_resume(resume)
                if result < 0:
                    return
                if result > 0:
                    seek_on_start = result
                    quality = history.get_quality(pid, season=s, episode=e)

    client = get_client()
    if not client:
        return
    _log("play_episode: pid=%s s=%d e=%d" % (pid, s, e))
    stream = _resolve_with_retry(lambda: client.resolve_episode(pid, s, e, slug=slug))
    if not stream:
        return
    label = f"{title} S{s:02d}E{e:02d}"
    next_ep = _compute_next_episode(client, pid, slug, s, e, title, poster)
    _play_stream(stream, label, poster, pid=pid, slug=slug,
                 media_type="tv", season=s, episode=e,
                 seek_on_start=seek_on_start, quality=quality,
                 next_episode=next_ep)


def _compute_next_episode(client, pid, slug, season, episode, show_title, poster):
    """Find the next episode after (season, episode). Returns a dict or None."""
    try:
        seasons = client.get_seasons(pid, slug)
    except Exception as exc:
        _log("next_episode: get_seasons failed: %s" % exc)
        return None
    if not seasons:
        return None
    current_eps = seasons.get(season, [])
    if episode + 1 in current_eps:
        next_s, next_e = season, episode + 1
    else:
        higher = [s for s in seasons if s > season and seasons[s]]
        if not higher:
            return None
        next_s = min(higher)
        next_e = min(seasons[next_s])
    return {
        "pid": str(pid),
        "slug": slug,
        "season": next_s,
        "episode": next_e,
        "title": show_title,
        "poster": poster,
    }


def _play_stream(stream, title, poster, pid="", slug="", media_type="movie",
                 season=None, episode=None, seek_on_start=0.0, quality="",
                 next_episode=None):
    if not stream or "error" in stream or "file" not in stream:
        xbmcgui.Dialog().notification("Flixtor", "Could not resolve stream.", xbmcgui.NOTIFICATION_ERROR)
        return

    master_url = stream["file"]
    headers = "Referer=https://flixtor.to/&Origin=https://flixtor.to"

    # On resume, auto-select the same quality; otherwise show picker
    stream_url, selected_quality = _pick_quality(master_url, headers, preferred=quality)
    if not stream_url:
        return
    _log("play_stream: quality=%s" % selected_quality)

    li = xbmcgui.ListItem(title, path=stream_url)
    li.setArt({"poster": poster, "thumb": poster})
    li.setInfo("video", {"title": title, "mediatype": "video"})
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)

    # Use inputstream.adaptive for HLS if available
    try:
        import inputstreamhelper
        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            li.setProperty("inputstream", is_helper.inputstream_addon)
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            li.setProperty(
                "inputstream.adaptive.stream_headers",
                "Referer=https://flixtor.to/&Origin=https://flixtor.to",
            )
    except ImportError:
        pass

    # Localize subtitles to clean filenames (preferred-language first) so Kodi
    # displays readable labels and the service can deterministically pick the
    # right stream by ISO code.
    pref_label, pref_iso, _ = _preferred_subtitle_pref()
    subs = _localize_subtitles(stream.get("tracks", []), pref_label)
    if subs:
        li.setSubtitles(subs)

    # Write now_playing marker for the background service to pick up
    history = WatchHistory()
    auto_play_next = ADDON.getSetting("auto_play_next") != "false"
    subtitles_default = ADDON.getSetting("subtitles_default") == "true"
    history.set_now_playing({
        "pid": str(pid),
        "slug": slug,
        "media_type": media_type,
        "title": title,
        "poster": poster,
        "season": season,
        "episode": episode,
        "resume_seconds": 0.0,
        "total_seconds": 0.0,
        "quality": selected_quality,
        "timestamp": time.time(),
        "seek_on_start": seek_on_start,
        "next_episode": next_episode,
        "auto_play_next": auto_play_next,
        "subtitles_default": subtitles_default,
        "preferred_subtitle_iso": pref_iso,
        "preferred_subtitle_label": pref_label,
    })

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _pick_quality(master_url, headers, preferred=""):
    """Fetch the master m3u8 and let the user choose a quality.
    Returns (stream_url, quality_name) or (None, "") if cancelled."""
    try:
        req = urllib.request.Request(master_url)
        req.add_header("User-Agent", "Mozilla/5.0")
        req.add_header("Referer", "https://flixtor.to/")
        req.add_header("Origin", "https://flixtor.to")
        resp = urllib.request.urlopen(req, timeout=15)
        manifest = resp.read().decode("utf-8")
    except Exception:
        return f"{master_url}|{headers}", preferred or ""

    parsed = urllib.parse.urlparse(master_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    variants = []
    for m in re.finditer(
        r'#EXT-X-STREAM-INF:.*?RESOLUTION=(\d+x\d+).*?NAME=(\w+)\s*\n(.+)',
        manifest,
    ):
        res, name, path = m.group(1), m.group(2), m.group(3).strip()
        full_url = base + path if path.startswith("/") else path
        variants.append((name, res, full_url))

    if not variants:
        return f"{master_url}|{headers}", ""

    if len(variants) == 1:
        return f"{variants[0][2]}|{headers}", variants[0][0]

    # Sort by resolution height descending (1080p first)
    variants.sort(key=lambda v: int(v[1].split("x")[1]), reverse=True)

    # Auto-select preferred quality on resume
    if preferred:
        for name, res, full_url in variants:
            if name == preferred:
                return f"{full_url}|{headers}", name

    default_pref, default_height = _default_quality_pref()
    if default_pref:
        for name, res, full_url in variants:
            if name == default_pref:
                return f"{full_url}|{headers}", name
        # Exact match not in manifest — pick the closest resolution.
        closest = min(variants, key=lambda v: abs(int(v[1].split("x")[1]) - default_height))
        _log("quality: default %s unavailable, picked %s (%s)" % (default_pref, closest[0], closest[1]))
        return f"{closest[2]}|{headers}", closest[0]

    labels = [f"{name} ({res})" for name, res, _ in variants]
    choice = xbmcgui.Dialog().select("Select Quality", labels)
    if choice < 0:
        return None, ""

    return f"{variants[choice][2]}|{headers}", variants[choice][0]


_QUALITY_INDEX_MAP = {
    "1": ("1080p", 1080),
    "2": ("720p", 720),
    "3": ("480p", 480),
    "4": ("360p", 360),
}


def _default_quality_pref():
    """Resolve the default_quality enum setting to (name, height) or ('', 0) if 'Ask'."""
    idx = ADDON.getSetting("default_quality") or "0"
    return _QUALITY_INDEX_MAP.get(idx, ("", 0))


# (label, iso-639-2/B 3-letter, iso-639-1 2-letter). Order matches the
# subtitles_language enum in settings.xml — index = setting value.
_SUBTITLE_LANGUAGES = [
    ("English",    "eng", "en"),
    ("Spanish",    "spa", "es"),
    ("French",     "fre", "fr"),
    ("German",     "ger", "de"),
    ("Portuguese", "por", "pt"),
    ("Italian",    "ita", "it"),
    ("Arabic",     "ara", "ar"),
    ("Russian",    "rus", "ru"),
    ("Japanese",   "jpn", "ja"),
    ("Korean",     "kor", "ko"),
    ("Chinese",    "chi", "zh"),
]

# Wider Flixtor → ISO 639-2/B map. Only used to put ISO codes in downloaded
# filenames so Kodi displays clean labels in its subtitle picker.
_LABEL_TO_ISO = [
    ("english",    "eng"), ("spanish",    "spa"), ("french",     "fre"),
    ("german",     "ger"), ("portuguese", "por"), ("italian",    "ita"),
    ("arabic",     "ara"), ("russian",    "rus"), ("japanese",   "jpn"),
    ("korean",     "kor"), ("chinese",    "chi"), ("dutch",      "dut"),
    ("polish",     "pol"), ("greek",      "gre"), ("turkish",    "tur"),
    ("czech",      "cze"), ("danish",     "dan"), ("finnish",    "fin"),
    ("swedish",    "swe"), ("norwegian",  "nor"), ("hebrew",     "heb"),
    ("vietnamese", "vie"), ("thai",       "tha"), ("hungarian",  "hun"),
    ("romanian",   "rum"), ("bulgarian",  "bul"), ("croatian",   "hrv"),
    ("serbian",    "srp"), ("slovenian",  "slv"), ("slovak",     "slo"),
    ("ukrainian",  "ukr"), ("estonian",   "est"), ("latvian",    "lav"),
    ("lithuanian", "lit"), ("indonesian", "ind"), ("malay",      "may"),
    ("persian",    "per"), ("hindi",      "hin"), ("bengali",    "ben"),
    ("urdu",       "urd"), ("tamil",      "tam"), ("telugu",     "tel"),
]


def _preferred_subtitle_pref():
    """Return (label, iso-639-2, iso-639-1) for the user's preferred language."""
    idx = ADDON.getSetting("subtitles_language") or "0"
    try:
        return _SUBTITLE_LANGUAGES[int(idx)]
    except (ValueError, IndexError):
        return _SUBTITLE_LANGUAGES[0]


def _label_to_iso(label):
    """Map a Flixtor subtitle label (e.g. 'Chinese (traditional)') to an
    ISO 639-2/B 3-letter code. Falls back to 'und' for unknown languages."""
    if not label:
        return "und"
    label_low = label.lower()
    for name, iso in _LABEL_TO_ISO:
        if name in label_low:
            return iso
    return "und"


def _safe_subtitle_url(url):
    """URL-encode a Flixtor subtitle URL so spaces in labels don't make
    urllib reject it. Flixtor labels like 'Portuguese (BR)' end up in the
    path component and break a naked Request() otherwise."""
    parts = urllib.parse.urlsplit(url)
    encoded_path = urllib.parse.quote(parts.path, safe="/.")
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, encoded_path, parts.query, parts.fragment)
    )


def _localize_subtitles(tracks, preferred_label):
    """Return subtitle paths/URLs to feed into ListItem.setSubtitles().

    The preferred-language track is downloaded to a local file with a clean,
    language-coded name (e.g. ``English_8e45dea82d.eng.vtt``). Everything
    else is passed through as a URL-encoded URL so Kodi can lazily fetch on
    demand if the user switches.

    Two reasons we localize at all:
      1. Flixtor URLs bury the language name behind a long hash
         (``…01e54e2ad0937b7a.bc37a136ff…English.vtt``), which Kodi shows
         in its subtitle picker — surfacing as garbage like
         ``ENG 01e54e2ad0937b7a.bc37…``.
      2. Without a recognizable ISO code in the filename, Kodi can't
         match the user's preferred language and may pick the wrong track.

    Eagerly downloading every track adds ~3-6s to playback start (which is
    a noticeable regression for users who don't use subtitles) so we only
    fetch the one Kodi will auto-select. Returns the preferred path first
    (so it's stream index 0) followed by the rest — preserves switchability.
    """
    captions = [t for t in (tracks or []) if t.get("kind") == "captions" and t.get("file")]
    if not captions:
        return []

    pref_low = (preferred_label or "").lower()

    # Find the preferred track (substring match handles "Chinese (traditional)" etc.)
    preferred_track = None
    if pref_low:
        for t in captions:
            if pref_low in (t.get("label") or "").lower():
                preferred_track = t
                break

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    subs_dir = os.path.join(profile, "subtitles")
    local_path = None
    if preferred_track:
        try:
            os.makedirs(subs_dir, exist_ok=True)
            # Prune old cached subs (>7 days) to keep the dir small.
            cutoff = time.time() - 7 * 86400
            for f in os.listdir(subs_dir):
                p = os.path.join(subs_dir, f)
                try:
                    if os.path.getmtime(p) < cutoff:
                        os.remove(p)
                except OSError:
                    pass
            local_path = _download_subtitle(preferred_track, subs_dir)
        except OSError as e:
            _log("subs: profile dir error: %s" % e)

    out = []
    if local_path:
        out.append(local_path)
    for t in captions:
        if t is preferred_track and local_path:
            continue
        out.append(_safe_subtitle_url(t["file"]))
    return out


def _download_subtitle(track, subs_dir):
    """Download one subtitle track to subs_dir. Returns the local path on
    success, or None if anything fails."""
    url = track["file"]
    label = track.get("label", "") or "Subtitle"
    iso = _label_to_iso(label)
    url_tag = hashlib.md5(url.encode("utf-8")).hexdigest()[:10]
    safe_label = re.sub(r'[^A-Za-z0-9 -]', "_", label).strip()[:40] or "Subtitle"
    filename = "%s_%s.%s.vtt" % (safe_label, url_tag, iso)
    local_path = os.path.join(subs_dir, filename)
    if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
        return local_path
    safe_url = _safe_subtitle_url(url)
    try:
        req = urllib.request.Request(safe_url, headers={
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://flixtor.to/",
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = resp.read()
        tmp = local_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, local_path)
        return local_path
    except Exception as e:
        _log("subs: download failed (%s): %s" % (label, e))
        return None


# ── Recently Watched ──────────────────────────────────────────────────

def _build_resume_item(rec):
    """Build a (url, ListItem) pair for a watch-history record. Used by both
    show_recent() and the Continue Watching band on the main menu."""
    title = rec.get("title", "")
    pid = rec.get("pid", "")
    slug = rec.get("slug", "")
    poster = rec.get("poster", "")
    media_type = rec.get("media_type", "movie")
    resume = rec.get("resume_seconds", 0)
    total = rec.get("total_seconds", 0)
    season = rec.get("season")
    episode = rec.get("episode")

    if media_type == "tv" and season is not None:
        label = f"{title} S{season:02d}E{episode:02d}"
    else:
        label = title

    if resume > 0 and total > 0:
        remaining = total - resume
        label += f"  [COLOR grey]({_format_time(remaining)} left)[/COLOR]"

    if media_type == "movie":
        action = "resume_movie" if resume > 0 else "play_movie"
        url = build_url(action, pid=pid, slug=slug, title=title, poster=poster)
    else:
        action = "resume_episode" if resume > 0 else "play_episode"
        url = build_url(action, pid=pid, slug=slug, season=season,
                        episode=episode, title=title, poster=poster)

    li = xbmcgui.ListItem(label)
    li.setArt({"poster": poster, "thumb": poster, "fanart": poster})
    li.setInfo("video", {"title": title, "mediatype": "video"})
    li.setProperty("IsPlayable", "true")

    tmdb_id = rec.get("tmdb_id")
    if tmdb_id is None:
        tmdb_client = _get_tmdb()
        if tmdb_client:
            mtype = "movie" if media_type == "movie" else "tv"
            tmdb_id = tmdb_client.lookup(title, rec.get("year", ""), mtype)
    _attach_tmdb_id(li, tmdb_id)

    if resume > 0 and total > 0:
        li.setProperty("ResumeTime", str(resume))
        li.setProperty("TotalTime", str(total))

    ctx = [
        _favorites_context_item(pid, {
            "slug": slug, "media_type": media_type,
            "title": title, "poster": poster,
            "year": rec.get("year", ""), "rating": rec.get("rating", ""),
            "genres": rec.get("genres", ""), "tmdb_id": tmdb_id or "",
        }),
        (
            "Remove from History",
            "RunPlugin(%s)" % build_url("ctx_remove_history", pid=pid,
                                         season=season if season is not None else "",
                                         episode=episode if episode is not None else ""),
        ),
    ]
    if resume > 0:
        ctx.append((
            "Mark as Unwatched",
            "RunPlugin(%s)" % build_url("ctx_clear_resume", pid=pid,
                                         season=season if season is not None else "",
                                         episode=episode if episode is not None else ""),
        ))
        if media_type == "movie":
            ctx.append((
                "Play from Beginning",
                "RunPlugin(%s)" % build_url("start_movie", pid=pid, slug=slug,
                                             title=title, poster=poster),
            ))
        else:
            ctx.append((
                "Play from Beginning",
                "RunPlugin(%s)" % build_url("start_episode", pid=pid, slug=slug,
                                             season=season, episode=episode,
                                             title=title, poster=poster),
            ))
    li.addContextMenuItems(ctx)
    return url, li


def show_recent():
    history = WatchHistory()
    items = history.get_recent(limit=20)
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No watch history yet.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for rec in items:
        url, li = _build_resume_item(rec)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Helpers ───────────────────────────────────────────────────────────

def add_content_item(item, show_type_label=False):
    """Add a movie or TV show item to the directory listing."""
    title = item["title"]
    pid = item["pid"]
    slug = item["slug"]
    media_type = item["media_type"]
    poster = item.get("poster", "")
    year = item.get("year", "")
    rating = item.get("rating", "")
    genres = item.get("genres", "")

    # Resolve TMDb id (cache hit in steady state; a callsite may also have
    # prefetched it via _prefetch_tmdb). TMDb Helper uses this to populate AH2's
    # Metacritic / RT / IMDb / Letterboxd rating badges via container 99950.
    tmdb_id = item.get("tmdb_id")
    if tmdb_id is None:
        client = _get_tmdb()
        if client:
            tmdb_id = client.lookup(title, year,
                                    "movie" if media_type == "movie" else "tv")
            item["tmdb_id"] = tmdb_id

    # Build label
    label = title
    if year:
        label = f"{title} ({year})"
    if show_type_label:
        tag = "[COLOR dodgerblue]MOVIE[/COLOR]" if media_type == "movie" else "[COLOR orange]TV[/COLOR]"
        label = f"{tag}  {label}"

    if media_type == "movie":
        url = build_url("play_movie", pid=pid, slug=slug, title=title, poster=poster)
        li = xbmcgui.ListItem(label)
        li.setProperty("IsPlayable", "true")
        is_folder = False
        info = {"title": title, "mediatype": "movie"}
    else:
        url = build_url("seasons", pid=pid, slug=slug, title=title, poster=poster)
        li = xbmcgui.ListItem(label)
        is_folder = True
        info = {"title": title, "mediatype": "tvshow"}

    if year:
        info["year"] = int(year)
    if genres:
        info["genre"] = genres

    li.setInfo("video", info)
    # Use setRating for proper display in Arctic Horizon
    if rating:
        li.setRating("imdb", float(rating))
    _attach_tmdb_id(li, tmdb_id)
    li.setArt({"poster": poster, "thumb": poster, "fanart": poster})
    li.setContentLookup(False)

    # Context menus — favorites toggle (Add or Remove) computed against the
    # current Favorites state, so the same long-press always Does The Right
    # Thing instead of duplicating an entry the user already saved.
    ctx = [
        _favorites_context_item(pid, {
            "slug": slug, "media_type": media_type,
            "title": title, "poster": poster, "year": year,
            "rating": rating, "genres": genres,
            "tmdb_id": tmdb_id or "",
        })
    ]
    if media_type == "movie" and _has_youtube():
        ctx.append(("Watch Trailer",
                    "RunPlugin(%s)" % build_url("play_trailer", pid=pid, slug=slug, media_type=media_type)))
    ctx.append(("Similar Titles",
                "Container.Update(%s)" % build_url("recommendations", pid=pid, slug=slug, media_type=media_type)))
    li.addContextMenuItems(ctx)

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# ── Favorites ────────────────────────────────────────────────────

def show_favorites():
    fav = FavoritesHistory()
    items = fav.get_all()
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No favorites yet.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _prefetch_tmdb(items)
    for item in items:
        title = item.get("title", "")
        pid = item.get("pid", "")
        slug = item.get("slug", "")
        poster = item.get("poster", "")
        media_type = item.get("media_type", "movie")
        year = item.get("year", "")
        rating = item.get("rating", "")
        genres = item.get("genres", "")
        tmdb_id = item.get("tmdb_id")

        label = f"{title} ({year})" if year else title

        if media_type == "movie":
            url = build_url("play_movie", pid=pid, slug=slug, title=title, poster=poster)
            li = xbmcgui.ListItem(label)
            li.setProperty("IsPlayable", "true")
            is_folder = False
            info = {"title": title, "mediatype": "movie"}
        else:
            url = build_url("seasons", pid=pid, slug=slug, title=title, poster=poster)
            li = xbmcgui.ListItem(label)
            is_folder = True
            info = {"title": title, "mediatype": "tvshow"}

        if year:
            info["year"] = int(year)
        if genres:
            info["genre"] = genres
        li.setInfo("video", info)
        if rating:
            li.setRating("imdb", float(rating))
        _attach_tmdb_id(li, tmdb_id)
        li.setArt({"poster": poster, "thumb": poster, "fanart": poster})
        li.setContentLookup(False)

        ctx = [(
            "Remove from Favorites",
            "RunPlugin(%s)" % build_url("ctx_remove_favorite", pid=pid),
        )]
        if media_type == "movie" and _has_youtube():
            ctx.append(("Watch Trailer",
                        "RunPlugin(%s)" % build_url("play_trailer", pid=pid, slug=slug, media_type=media_type)))
        ctx.append(("Similar Titles",
                    "Container.Update(%s)" % build_url("recommendations", pid=pid, slug=slug, media_type=media_type)))
        li.addContextMenuItems(ctx)

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Recommendations ──────────────────────────────────────────────

def show_recommendations(pid, slug, media_type):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        items = client.get_recommendations(pid, slug, media_type)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No recommendations found.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _prefetch_tmdb(items)
    for item in items:
        add_content_item(item)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Trailers ─────────────────────────────────────────────────────

def play_trailer(pid, slug, media_type):
    if not _has_youtube():
        if xbmcgui.Dialog().yesno(
            "Flixtor",
            "Trailers require the YouTube addon. Install it now?",
        ):
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
        return
    client = get_client()
    if not client:
        return
    _log("play_trailer: pid=%s" % pid)
    trailer_url = client.get_trailer(pid, slug, media_type)
    if trailer_url:
        xbmc.Player().play(trailer_url)
    else:
        xbmcgui.Dialog().notification("Flixtor", "No trailer available.", xbmcgui.NOTIFICATION_INFO)


# ── TMDb Helper: search and play ─────────────────────────────────

def search_and_play(title, year="", media_type="movie"):
    """Search Flixtor for a title and auto-play the first match. Used by TMDb Helper player integration."""
    _log("search_and_play: title=%s year=%s type=%s" % (title, year, media_type))
    client = get_client()
    if not client:
        return
    results = (client.search(title) or {}).get("items") or []
    if not results:
        xbmcgui.Dialog().notification("Flixtor", "Title not found on Flixtor.", xbmcgui.NOTIFICATION_INFO)
        return
    # Find best match by title and optionally year
    best = None
    for r in results:
        if r["media_type"] != media_type:
            continue
        if year and r.get("year") == year:
            best = r
            break
        if not best:
            best = r
    if not best:
        best = results[0]
    if best["media_type"] == "movie":
        play_movie(best["pid"], best["title"], best.get("poster", ""), best["slug"])
    else:
        # For TV, navigate to seasons
        xbmc.executebuiltin(
            "Container.Update(%s)" % build_url("seasons", pid=best["pid"], slug=best["slug"],
                                                 title=best["title"], poster=best.get("poster", ""))
        )


# ── Router ────────────────────────────────────────────────────────────

def _title_or_slug(params):
    """Return a non-empty display title: the URL title, or a title-cased slug fallback."""
    title = params.get("title") or ""
    if title:
        return title
    slug = params.get("slug", "")
    if slug:
        return slug.replace("-", " ").replace("_", " ").title()
    return "Flixtor"


def router():
    # keep_blank_values=True so empty values (e.g. title=) survive as "" instead of
    # being silently dropped, which otherwise causes KeyError on params["title"].
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?"), keep_blank_values=True))
    action = params.get("action")
    _log("router: action=%s" % action)

    if action is None:
        main_menu()
    elif action == "recent":
        show_recent()
    elif action == "search":
        do_search()
    elif action == "new_search":
        do_new_search()
    elif action == "search_execute":
        do_search_execute(params["q"], page=int(params.get("page", 1)))
    elif action == "remove_search":
        do_remove_search(params["q"])
    elif action == "home":
        do_home(page=int(params.get("page", 0)))
    elif action == "movies":
        show_catalog_sort_picker("movies")
    elif action == "tvshows":
        show_catalog_sort_picker("tvshows")
    elif action == "genres_movies":
        show_genre_picker("movies")
    elif action == "genres_tvshows":
        show_genre_picker("tvshows")
    elif action in _CATALOG_ROUTES:
        kind, sort, _ = _CATALOG_ROUTES[action]
        do_catalog(action, kind, sort, int(params.get("page", 1)),
                   genre=params.get("genre", "all"))
    elif action == "seasons":
        show_seasons(params["pid"], params.get("slug", ""), _title_or_slug(params),
                     params.get("poster", ""))
    elif action == "episodes":
        show_episodes(
            params["pid"], params.get("slug", ""), params["season"],
            _title_or_slug(params), params.get("poster", ""),
        )
    elif action == "play_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""))
    elif action == "resume_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""), resume_mode="resume")
    elif action == "start_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""), resume_mode="start")
    elif action == "play_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
        )
    elif action == "resume_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            resume_mode="resume",
        )
    elif action == "start_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            resume_mode="start",
        )
    elif action == "ctx_remove_history":
        season = params.get("season") or None
        episode = params.get("episode") or None
        WatchHistory().remove_item(params["pid"], season=season, episode=episode)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_clear_resume":
        season = params.get("season") or None
        episode = params.get("episode") or None
        WatchHistory().clear_resume(params["pid"], season=season, episode=episode)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "favorites":
        show_favorites()
    elif action == "ctx_add_favorite":
        FavoritesHistory().add({
            "pid": params["pid"], "slug": params.get("slug", ""),
            "media_type": params.get("media_type", "movie"),
            "title": params.get("title", ""), "poster": params.get("poster", ""),
            "year": params.get("year", ""), "rating": params.get("rating", ""),
            "genres": params.get("genres", ""),
            "tmdb_id": params.get("tmdb_id") or "",
        })
        xbmcgui.Dialog().notification("Flixtor", "Added to Favorites", xbmcgui.NOTIFICATION_INFO, 1500)
        # Refresh so the long-press toggle flips from "Add" to "Remove" without
        # the user navigating away and back.
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_remove_favorite":
        FavoritesHistory().remove(params["pid"])
        xbmc.executebuiltin("Container.Refresh")
    elif action == "recommendations":
        show_recommendations(params["pid"], params.get("slug", ""), params.get("media_type", "movie"))
    elif action == "play_trailer":
        play_trailer(params["pid"], params.get("slug", ""), params.get("media_type", "movie"))
    elif action == "search_and_play":
        search_and_play(params.get("title", ""), params.get("year", ""),
                        params.get("media_type", "movie"))
    elif action == "sign_out":
        do_sign_out()
    elif action == "clear_watch_history":
        do_clear_watch_history()
    elif action == "clear_favorites":
        do_clear_favorites()
    elif action == "clear_searches":
        do_clear_searches()
    elif action == "clear_tmdb_cache":
        do_clear_tmdb_cache()


if __name__ == "__main__":
    router()
