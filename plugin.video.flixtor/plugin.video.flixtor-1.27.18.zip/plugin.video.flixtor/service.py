"""Flixtor background service — tracks playback position and installs custom keymaps."""

import os
import time
import urllib.parse
import uuid
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from resources.lib import cachemaint
from resources.lib.metadataqueue import MetadataWorkers
from resources.lib.kodiui import set_parent_folder_items
from resources.lib.navigation import (
    AH2_DETAILS_CONTROL_IDS,
    FLIXTOR_ROOT_PATH,
    ROOT_EXIT_ALLOW_PROPERTY,
    ROOT_ROUTE_PROPERTY,
    is_dialog_open,
    is_flixtor_root_path,
    is_flixtor_title_context_url,
    is_supported_skin,
    should_auto_launch,
    should_guard_flixtor_root_back,
    should_open_one_press_details,
    should_redirect_flixtor_legacy_path_to_home,
    should_restore_flixtor_root,
    skin_owns_home,
)
from resources.lib.subtitles import choose_subtitle_stream_index
from resources.lib.watchhistory import WatchHistory

# Fire "Up next" within this many seconds of the end, after the normal
# completion threshold has been reached. The percentage guard matters for
# short episodes, where a fixed 45-second trigger alone can skip too early.
# Polling cadence is 5s in run(); the countdown is capped by remaining time.
NEXT_EPISODE_TRIGGER_OFFSET_SECONDS = 45
NEXT_EPISODE_COUNTDOWN_SECONDS = 15

# Treat playback as finished (clear the resume point, drop it from Continue
# Watching, and queue the next episode) once this fraction of the runtime has
# been watched. A percentage adapts to length and reliably catches the auto-play
# hand-off, which stops ~30s from the end (>=95% for any episode >= 5 min).
COMPLETION_THRESHOLD = 0.90

# Cache-maintenance scheduling (loop ticks are 5s). The daily pass is heavy on
# a Fire TV stick — a multi-MB Textures.GetTextures parse plus one sqlite
# delete + file unlink per stale poster — enough CPU/flash contention inside
# the Kodi process to drain the player's video cache ("paused for caching").
# So it must never overlap playback: eligibility requires MAINT_IDLE_TICKS
# with no media loaded (isPlaying() covers paused too, and the idle window
# outlasts the ~15s auto-play-next gap so it can't fire between episodes).
MAINT_FIRST_CHECK_TICK = 24   # first eligibility ~2 min after start (off the boot path)
MAINT_RECHECK_TICKS = 720     # re-arm hourly for always-on devices
MAINT_IDLE_TICKS = 24         # require ~2 min since playback was last active

# Android Back on Fire TV can bypass Kodi's keymap layer.  A lightweight
# service poll catches only a confirmed transition away from the exact Flixtor
# root.  Two samples avoid reacting to transient container changes.
ROOT_GUARD_POLL_SECONDS = 0.25
ROOT_GUARD_OUTSIDE_SAMPLES = 2
SERVICE_TICK_SECONDS = 5

# The OMDb key was created for public distribution with Flixtor. Seed only
# empty TMDb Helper slots and preserve personal overrides. MDBList is opt-in.
BUNDLED_OMDB_APIKEY = "7ed05ff7"
BUNDLED_MDBLIST_APIKEY = ""

KEYMAP_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<keymap>
  <FullscreenVideo>
    <keyboard>
      <backspace>Stop</backspace>
      <browser_back>Stop</browser_back>
      <escape>Stop</escape>
      <down>OSD</down>
    </keyboard>
    <remote>
      <back>Stop</back>
      <down>OSD</down>
    </remote>
  </FullscreenVideo>
  <VideoOSD>
    <keyboard>
      <backspace>Back</backspace>
      <browser_back>Back</browser_back>
      <escape>Back</escape>
    </keyboard>
    <remote>
      <back>Back</back>
    </remote>
  </VideoOSD>
  <FullscreenInfo>
    <keyboard>
      <backspace>Back</backspace>
      <browser_back>Back</browser_back>
      <escape>Back</escape>
    </keyboard>
    <remote>
      <back>Back</back>
    </remote>
  </FullscreenInfo>
  <Home>
    <keyboard>
      <c>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</c>
      <menu>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</menu>
      <return mod="longpress">RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</return>
      <enter mod="longpress">RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</enter>
    </keyboard>
    <remote>
      <menu>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</menu>
      <title>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</title>
    </remote>
    <mouse>
      <rightclick>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</rightclick>
    </mouse>
  </Home>
  <Videos>
    <keyboard>
      <down>NotifyAll(plugin.video.flixtor,remote_down)</down>
      <left>NotifyAll(plugin.video.flixtor,remote_left)</left>
      <backspace>NotifyAll(plugin.video.flixtor,remote_back)</backspace>
      <browser_back>NotifyAll(plugin.video.flixtor,remote_back)</browser_back>
      <escape>NotifyAll(plugin.video.flixtor,remote_back)</escape>
      <backspace mod="longpress">NotifyAll(plugin.video.flixtor,remote_back_long)</backspace>
      <browser_back mod="longpress">NotifyAll(plugin.video.flixtor,remote_back_long)</browser_back>
      <escape mod="longpress">NotifyAll(plugin.video.flixtor,remote_back_long)</escape>
      <c>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</c>
      <menu>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</menu>
      <return mod="longpress">RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</return>
      <enter mod="longpress">RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</enter>
    </keyboard>
    <remote>
      <down>NotifyAll(plugin.video.flixtor,remote_down)</down>
      <left>NotifyAll(plugin.video.flixtor,remote_left)</left>
      <back>NotifyAll(plugin.video.flixtor,remote_back)</back>
      <menu>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</menu>
      <title>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</title>
    </remote>
    <mouse>
      <rightclick>RunPlugin(plugin://plugin.video.flixtor/?action=remote_context)</rightclick>
    </mouse>
  </Videos>
</keymap>
"""


TMDB_PLAYER_JSON = """\
{
    "name": "Flixtor",
    "plugin": "plugin.video.flixtor",
    "priority": 10,
    "is_resolvable": "true",
    "assert": {
        "play_movie": ["title", "year"],
        "play_episode": ["showname", "season", "episode"]
    },
    "play_movie": "plugin://plugin.video.flixtor/?action=search_and_play&media_type=movie&title={title_url}&year={year}",
    "play_episode": "plugin://plugin.video.flixtor/?action=search_and_play&media_type=tv&title={showname_url}&year={showyear}&season={season}&episode={episode}"
}
"""

TMDB_DEFAULT_SETTINGS = {
    "default_player_movies": "flixtor.json play_movie",
    "default_player_episodes": "flixtor.json play_episode",
    # A provider or Kodi-library item otherwise takes precedence over the
    # configured default in TMDb Helper 5.4.x and can reopen the player picker.
    "default_player_provider": "false",
    "default_player_kodi": "0",
}


def _install_keymap():
    """Install Fire TV browsing and playback controls, then reload them."""
    profile = xbmcvfs.translatePath("special://profile/keymaps/")
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    keymap_path = os.path.join(profile, "flixtor.xml")
    existing = ""
    try:
        with open(keymap_path, "r") as f:
            existing = f.read()
    except OSError:
        pass
    if existing != KEYMAP_XML:
        with open(keymap_path, "w") as f:
            f.write(KEYMAP_XML)
        xbmc.executebuiltin("Action(reloadkeymaps)")
        xbmc.log("FLIXTOR: installed/updated custom keymap", xbmc.LOGINFO)


def _install_tmdb_player():
    """Install and select Flixtor as TMDb Helper's automatic player."""
    players_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.themoviedb.helper/players/"
    )
    if not xbmcvfs.exists(players_dir):
        xbmcvfs.mkdirs(players_dir)
    player_path = os.path.join(players_dir, "flixtor.json")
    # Always overwrite to keep in sync with addon version
    with open(player_path, "w") as f:
        f.write(TMDB_PLAYER_JSON)
    xbmc.log("FLIXTOR: installed TMDb Helper player file", xbmc.LOGINFO)
    try:
        tmdb_addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        for setting_id, value in TMDB_DEFAULT_SETTINGS.items():
            if tmdb_addon.getSetting(setting_id) != value:
                tmdb_addon.setSetting(setting_id, value)
        xbmc.log(
            "FLIXTOR: configured Flixtor as automatic TMDb Helper player",
            xbmc.LOGINFO,
        )
    except RuntimeError:
        xbmc.log(
            "FLIXTOR: TMDb Helper not installed — skipping automatic player default",
            xbmc.LOGINFO,
        )


def _seed_tmdb_helper_keys():
    """Populate TMDb Helper's OMDb and MDBList key slots with bundled values,
    but only for slots the user has left empty. This lights up the full AH2
    rating strip out-of-the-box without making every user register accounts."""
    try:
        tmdb_addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
    except RuntimeError:
        xbmc.log("FLIXTOR: TMDb Helper not installed — skipping rating-key seed",
                 xbmc.LOGINFO)
        return

    for setting_id, bundled in (
        ("omdb_apikey", BUNDLED_OMDB_APIKEY),
        ("mdblist_apikey", BUNDLED_MDBLIST_APIKEY),
    ):
        if not bundled:
            continue
        existing = (tmdb_addon.getSetting(setting_id) or "").strip()
        if existing:
            continue
        try:
            tmdb_addon.setSetting(setting_id, bundled)
            xbmc.log("FLIXTOR: seeded TMDb Helper %s" % setting_id, xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("FLIXTOR: failed to seed %s: %s" % (setting_id, exc),
                     xbmc.LOGINFO)


def _handle_remote_direction(direction):
    """Route a Fire TV direction without starting a new plug-in process."""
    direction = str(direction or "").casefold()
    native_action = {"down": "Down", "left": "Left"}.get(direction)
    if not native_action:
        return
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    db_type = xbmc.getInfoLabel("ListItem.DBType")
    skin_dir = xbmc.getSkinDir()
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    focused_control_id = next(
        (
            control_id
            for control_id in AH2_DETAILS_CONTROL_IDS
            if xbmc.getCondVisibility("Control.HasFocus(%d)" % control_id)
        ),
        0,
    )
    if should_open_one_press_details(
            folder_path, db_type, skin_dir, direction,
            dialog_id, focused_control_id):
        # Avoid loading AH2's YouTube row when no YouTube API key is present.
        xbmc.executebuiltin("Skin.SetBool(Info.DisableYoutube)")
        xbmc.executebuiltin("SetFocus(99996)")
        xbmc.log(
            "FLIXTOR: remote %s opened one-press details" % native_action,
            xbmc.LOGDEBUG,
        )
        return
    # Action() dispatches the native UI action directly, so it does not loop
    # back through the physical-key mapping above.
    xbmc.executebuiltin("Action(%s)" % native_action)


def _allow_root_exit(seconds=5):
    """Temporarily allow a deliberate transition away from Flixtor's root."""
    set_parent_folder_items(True)
    window = xbmcgui.Window(10000)
    window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    window.setProperty(
        ROOT_EXIT_ALLOW_PROPERTY,
        str(time.time() + max(1, int(seconds))),
    )


def _ah2_options_menu_open():
    """Whether Arctic Horizon 2's in-window Options group has focus.

    AH2 renders this panel inside MyVideoNav rather than as a Kodi dialog, so
    getCurrentWindowDialogId() continues to report the no-dialog sentinel
    (9999). Its official skin definition uses control group 9000 for the menu
    and 89000 for its mouse-focus overlay across every video view.
    """
    if not is_supported_skin(xbmc.getSkinDir()):
        return False
    return bool(
        xbmc.getCondVisibility("ControlGroup(9000).HasFocus()")
        or xbmc.getCondVisibility("Control.HasFocus(89000)")
    )


def _handle_remote_back(long_press=False):
    """Keep short Back inside Flixtor only when already at its root."""
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    options_menu_open = _ah2_options_menu_open()
    skin_dir = xbmc.getSkinDir()
    if should_redirect_flixtor_legacy_path_to_home(
            folder_path, skin_dir, xbmcgui.getCurrentWindowId(), dialog_id,
            options_menu_open=options_menu_open,
            player_active=xbmc.Player().isPlaying()):
        _allow_root_exit()
        xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.log("FLIXTOR: legacy-navigation Back returned to skin Home", xbmc.LOGDEBUG)
        return
    guard_root = should_guard_flixtor_root_back(
        folder_path, dialog_id, options_menu_open=options_menu_open,
        skin_dir=skin_dir,
    )
    xbmc.log(
        "FLIXTOR: remote Back root=%s flixtor=%s dialog=%s options=%s long=%s guard=%s"
        % (
            is_flixtor_root_path(folder_path),
            str(folder_path or "").partition("?")[0].rstrip("/") == FLIXTOR_ROOT_PATH,
            dialog_id,
            options_menu_open,
            bool(long_press),
            guard_root,
        ),
        xbmc.LOGINFO,
    )
    if guard_root:
        if long_press:
            _allow_root_exit()
            xbmc.executebuiltin("ActivateWindow(Home)")
            xbmc.log("FLIXTOR: long Back exited add-on", xbmc.LOGDEBUG)
        else:
            xbmcgui.Dialog().notification(
                "Flixtor",
                "Home screen - long-press for exit controls",
                xbmcgui.NOTIFICATION_INFO,
                1800,
            )
        return
    # Dialogs and every level below the root retain ordinary Back navigation.
    xbmc.executebuiltin("Action(Back)")


class FlixtorMonitor(xbmc.Monitor):
    """Receive lightweight navigation messages in the resident service."""

    def onNotification(self, sender, method, data):
        if str(sender or "") != "plugin.video.flixtor":
            return
        method = str(method or "")
        direction_by_method = {
            "remote_down": "down",
            "Other.remote_down": "down",
            "remote_left": "left",
            "Other.remote_left": "left",
        }
        direction = direction_by_method.get(method)
        if direction:
            _handle_remote_direction(direction)
            return
        if method in {"remote_back", "Other.remote_back"}:
            _handle_remote_back(long_press=False)
        elif method in {"remote_back_long", "Other.remote_back_long"}:
            _handle_remote_back(long_press=True)


class FlixtorRootGuard:
    """Keep cached legacy returns consistent with the active skin's home."""

    def __init__(self, player):
        self._player = player
        self._outside_samples = 0
        self._cooldown_until = 0.0
        self._parent_items_visible = None

    def _set_parent_items_visible(self, visible):
        visible = bool(visible)
        if self._parent_items_visible is visible:
            return
        set_parent_folder_items(visible)
        self._parent_items_visible = visible

    @staticmethod
    def _exit_allowed():
        window = xbmcgui.Window(10000)
        raw_until = window.getProperty(ROOT_EXIT_ALLOW_PROPERTY)
        try:
            allowed = float(raw_until or 0) > time.time()
        except (TypeError, ValueError):
            allowed = False
        if raw_until and not allowed:
            window.clearProperty(ROOT_EXIT_ALLOW_PROPERTY)
        return allowed

    def poll(self):
        window = xbmcgui.Window(10000)
        route_is_root = window.getProperty(ROOT_ROUTE_PROPERTY) == "root"
        folder_path = xbmc.getInfoLabel("Container.FolderPath")
        dialog_id = xbmcgui.getCurrentWindowDialogId()
        in_flixtor = str(folder_path or "").startswith(FLIXTOR_ROOT_PATH)
        skin_dir = xbmc.getSkinDir()

        if skin_owns_home(skin_dir):
            # A cached root/search directory can bypass main.py's Home
            # redirect. Require two real video-browser legacy-path samples; stale
            # folder labels in Home/Settings, dialogs, and playback are ignored.
            self._set_parent_items_visible(True)
            if time.monotonic() < self._cooldown_until or not should_redirect_flixtor_legacy_path_to_home(
                    folder_path, skin_dir, xbmcgui.getCurrentWindowId(), dialog_id,
                    options_menu_open=_ah2_options_menu_open(),
                    player_active=self._player.isPlaying()):
                self._outside_samples = 0
                return
            self._outside_samples += 1
            if self._outside_samples < ROOT_GUARD_OUTSIDE_SAMPLES:
                return
            self._outside_samples = 0
            self._cooldown_until = time.monotonic() + 2.0
            _allow_root_exit()
            xbmc.executebuiltin("ActivateWindow(Home)")
            xbmc.log("FLIXTOR: cached legacy navigation returned to skin Home", xbmc.LOGINFO)
            return

        # Do not restore the global preference during the brief async load of
        # the root: main.py has already hidden it before endOfDirectory.
        if route_is_root and in_flixtor:
            self._set_parent_items_visible(False)
        elif not route_is_root:
            self._set_parent_items_visible(True)

        if time.monotonic() < self._cooldown_until:
            return

        if not route_is_root:
            self._outside_samples = 0
            return

        if in_flixtor:
            self._outside_samples = 0
            return

        exit_allowed = self._exit_allowed()
        player_active = self._player.isPlaying()
        if not should_restore_flixtor_root(
                route_is_root,
                folder_path,
                dialog_id,
                exit_allowed,
                player_active,
                skin_dir=skin_dir):
            self._outside_samples = 0
            return

        self._outside_samples += 1
        if self._outside_samples < ROOT_GUARD_OUTSIDE_SAMPLES:
            return

        self._outside_samples = 0
        self._cooldown_until = time.monotonic() + 2.0
        self._set_parent_items_visible(True)
        xbmc.executebuiltin(
            "ActivateWindow(videos,plugin://plugin.video.flixtor/)"
        )
        xbmcgui.Dialog().notification(
            "Flixtor",
            "Home screen - long-press for exit controls",
            xbmcgui.NOTIFICATION_INFO,
            1800,
        )
        xbmc.log("FLIXTOR: restored root after unhandled Back", xbmc.LOGINFO)


class FlixtorPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._history = WatchHistory()
        self._tracking = False
        self._metadata = None
        self._last_time = 0.0
        self._position_sampled = False
        self._total_time = 0.0
        self._next_episode = None
        self._auto_play_next_enabled = False
        self._countdown_shown = False
        self._subtitle_stream_index = -1
        self._preferred_subtitle_iso = ""
        self._paused_subtitles_visible = False
        self._paused_subtitle_name = ""
        self._pending_return_url = ""
        self._pending_return_after = 0.0
        self._playback_generation = 0
        self._resume_seek_pending = False
        self._resume_seek_target = 0.0
        self._next_episode_session = ""
        self._clear_next_episode_control()

    def _clear_next_episode_control(self):
        self._next_episode_session = ""
        window = xbmcgui.Window(10000)
        window.clearProperty("Flixtor.PlaybackActive")
        for suffix in ("Available", "Action", "Label", "Session", "Request"):
            window.clearProperty("Flixtor.NextEpisode" + suffix)

    def _publish_next_episode_control(self):
        meta, successor = self._metadata or {}, self._next_episode or {}
        if self._tracking and meta:
            xbmcgui.Window(10000).setProperty("Flixtor.PlaybackActive", "true")
        try:
            current = (int(meta["season"]), int(meta["episode"]))
            following = (int(successor["season"]), int(successor["episode"]))
        except (KeyError, TypeError, ValueError):
            return
        if (not self._tracking or meta.get("media_type") != "tv"
                or not meta.get("pid") or str(meta["pid"]) != str(successor.get("pid", ""))
                or current[0] < 0 or current[1] < 1
                or following[0] < 0 or following[1] < 1 or following <= current):
            return
        session = uuid.uuid4().hex
        self._next_episode_session = session
        window = xbmcgui.Window(10000)
        url = "plugin://plugin.video.flixtor/?" + urllib.parse.urlencode({
            "action": "play_next_episode", "session": session})
        window.setProperty("Flixtor.NextEpisodeSession", session)
        window.setProperty("Flixtor.NextEpisodeAction", "RunPlugin(%s)" % url)
        window.setProperty("Flixtor.NextEpisodeLabel", "S%02dE%02d — %s" % (
            following[0], following[1], successor.get("title", meta.get("title", ""))))
        window.setProperty("Flixtor.NextEpisodeAvailable", "true")

    def poll_next_episode_request(self):
        window = xbmcgui.Window(10000)
        requested = window.getProperty("Flixtor.NextEpisodeRequest")
        if not requested:
            return
        window.clearProperty("Flixtor.NextEpisodeRequest")
        if (requested != self._next_episode_session or not self._tracking
                or not self.isPlaying() or not self._next_episode
                or not self._metadata or self._metadata.get("media_type") != "tv"):
            return
        self._start_next_episode(self._playback_generation)

    def _start_next_episode(self, generation, require_completed=False):
        """Save measured progress, then advance only the same active playback."""
        if (generation != self._playback_generation or not self._tracking
                or not self.isPlaying() or not self._next_episode
                or not self._metadata or self._metadata.get("media_type") != "tv"):
            return
        meta = self._metadata
        successor = dict(self._next_episode)
        sampled = self.poll_position(allow_countdown=False)
        if (generation != self._playback_generation or not self._tracking
                or self._metadata is not meta or not self.isPlaying()):
            return
        if require_completed and (not sampled or self._total_time <= 0
                or self._last_time < self._total_time * COMPLETION_THRESHOLD):
            # Automatic playback must still qualify after a backward seek or
            # duration change during its countdown. A failed clock read must
            # not reuse the old eligible sample. A later valid poll may offer
            # the prompt again; manual Next remains an explicit skip.
            self._countdown_shown = False
            return
        # This is a skip, not an EOF signal. Only the normal measured 90%
        # threshold may mark the current episode completed.
        self._save_position(completed=False)
        if self._playback_generation != generation + 1 or self._tracking:
            return  # Stop or a newer playback won the transition.
        self._pending_return_url = ""
        self._pending_return_after = 0.0
        params = {"action": "start_episode", "pid": successor.get("pid", ""),
                  "slug": successor.get("slug", ""), "season": successor.get("season"),
                  "episode": successor.get("episode"), "title": successor.get("title", ""),
                  "poster": successor.get("poster", ""),
                  "return_url": successor.get("return_url", "")}
        url = "plugin://plugin.video.flixtor/?" + urllib.parse.urlencode(
            {key: ("" if value is None else value) for key, value in params.items()})
        xbmc.executebuiltin("PlayMedia(%s)" % url)

    def onAVStarted(self):
        self._playback_generation += 1
        generation = self._playback_generation
        self._tracking = False
        self._clear_next_episode_control()
        self._resume_seek_pending = False
        self._resume_seek_target = 0.0
        self._last_time = 0.0
        self._total_time = 0.0
        self._position_sampled = False
        self._subtitle_stream_index = -1
        self._preferred_subtitle_iso = ""
        self._paused_subtitles_visible = False
        self._paused_subtitle_name = ""
        meta = self._history.get_now_playing()
        if generation != self._playback_generation:
            return
        if not meta:
            self._tracking = False
            self._pending_return_url = ""
            self._pending_return_after = 0.0
            return
        self._history.clear_now_playing()
        if generation != self._playback_generation:
            return
        # A newly started item owns the post-playback destination. This also
        # prevents a stale recommendation target from redirecting a later,
        # unrelated catalog playback. Auto-played episodes carry the same URL.
        if meta.get("return_url") or not self._tracking:
            self._pending_return_url = ""
            self._pending_return_after = 0.0
        seek_to = float(meta.get("seek_on_start") or 0.0)
        self._resume_seek_pending = seek_to > 0
        self._resume_seek_target = seek_to
        self._metadata = meta
        self._tracking = True
        self._next_episode = meta.get("next_episode")
        self._auto_play_next_enabled = bool(meta.get("auto_play_next"))
        self._countdown_shown = False
        self._publish_next_episode_control()
        xbmc.log("FLIXTOR: onAVStarted: pid=%s title=%s seek=%.1f next=%s" %
                 (meta.get("pid"), meta.get("title"), seek_to,
                  bool(self._next_episode)), xbmc.LOGINFO)

        try:
            self._total_time = self.getTotalTime()
        except RuntimeError:
            self._total_time = 0.0

        if seek_to > 0:
            xbmc.sleep(500)
            # Stop or another playback may occur during the startup wait. A
            # stale callback must never seek the next item or save a pre-seek
            # sample over the durable resume point.
            if generation != self._playback_generation or not self._tracking:
                return
            try:
                self.seekTime(seek_to)
            except RuntimeError:
                xbmc.log("FLIXTOR: onAVStarted: seek failed", xbmc.LOGINFO)
            if generation != self._playback_generation or not self._tracking:
                return
            self._resume_seek_pending = False
        if generation == self._playback_generation and self._tracking:
            self._apply_subtitle_preferences(meta)

    def _apply_subtitle_preferences(self, meta):
        """Honor the user's subtitles_default and subtitles_language settings.

        Kodi's own global subtitle preference can otherwise auto-show subtitles
        (always-on bug) and pick whichever language Kodi's locale matches first
        (wrong-language bug). We explicitly select the preferred ISO stream and
        force visibility on/off to override Kodi's defaults. External subs load
        asynchronously, so we wait briefly for getAvailableSubtitleStreams() to
        populate before selecting.
        """
        preferred_iso = (meta.get("preferred_subtitle_iso") or "").lower()
        subtitles_on = bool(meta.get("subtitles_default"))
        self._preferred_subtitle_iso = preferred_iso

        # Wait up to ~2s for Kodi to load external subtitle streams.
        streams = []
        for _ in range(10):
            try:
                streams = self.getAvailableSubtitleStreams() or []
            except Exception:
                streams = []
            if streams:
                break
            xbmc.sleep(200)

        if preferred_iso and streams:
            chosen = choose_subtitle_stream_index(
                streams, preferred=preferred_iso
            )
            if chosen >= 0:
                try:
                    self.setSubtitleStream(chosen)
                    self._subtitle_stream_index = chosen
                    xbmc.log("FLIXTOR: subtitle stream set to %d (%s)" %
                             (chosen, streams[chosen]), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("FLIXTOR: setSubtitleStream failed: %s" % e, xbmc.LOGINFO)
            else:
                xbmc.log("FLIXTOR: preferred subtitle %s not found in %s" %
                         (preferred_iso, streams), xbmc.LOGINFO)

        # Always set visibility explicitly — Kodi's global subtitle preference
        # otherwise overrides our setting.
        try:
            self.showSubtitles(subtitles_on)
            xbmc.log("FLIXTOR: subtitles %s by user setting" %
                     ("enabled" if subtitles_on else "disabled"), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log("FLIXTOR: showSubtitles failed: %s" % e, xbmc.LOGINFO)

    def _subtitles_are_visible(self):
        try:
            return bool(xbmc.getCondVisibility("VideoPlayer.SubtitlesEnabled"))
        except Exception:
            return False

    def _current_subtitle_name(self):
        try:
            return self.getSubtitles() or ""
        except Exception:
            return ""

    def _current_time(self):
        try:
            return self.getTime()
        except Exception:
            return 0.0

    def _resync_active_subtitle(self, reason, current_name=""):
        """Reload the active external track after the player clock changes.

        Reselecting the same stream makes Kodi rebuild its subtitle timing
        state against the resumed/seeked playback clock. Visibility is checked
        again after the short settle delay so a user's manual "off" action is
        never undone.
        """
        if not self._tracking or not self._metadata:
            return
        xbmc.sleep(250)
        if not self._subtitles_are_visible():
            xbmc.log("FLIXTOR: subtitle resync skipped after %s (disabled)" %
                     reason, xbmc.LOGINFO)
            return
        try:
            streams = self.getAvailableSubtitleStreams() or []
        except Exception:
            streams = []
        chosen = choose_subtitle_stream_index(
            streams,
            preferred=self._preferred_subtitle_iso,
            current=current_name or self._current_subtitle_name(),
            fallback=self._subtitle_stream_index,
        )
        if chosen < 0:
            xbmc.log("FLIXTOR: subtitle resync skipped after %s (no stream)" %
                     reason, xbmc.LOGINFO)
            return
        try:
            self.setSubtitleStream(chosen)
            self.showSubtitles(True)
            self._subtitle_stream_index = chosen
            xbmc.log("FLIXTOR: subtitle stream %d resynced after %s at %.1f" %
                     (chosen, reason, self._current_time()), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log("FLIXTOR: subtitle resync failed after %s: %s" %
                     (reason, e), xbmc.LOGINFO)

    def onPlayBackPaused(self):
        self._paused_subtitles_visible = self._subtitles_are_visible()
        self._paused_subtitle_name = self._current_subtitle_name()
        xbmc.log("FLIXTOR: playback paused at %.1f subtitles=%s" %
                 (self._current_time(), self._paused_subtitles_visible),
                 xbmc.LOGINFO)

    def onPlayBackResumed(self):
        xbmc.log("FLIXTOR: playback resumed at %.1f" % self._current_time(),
                 xbmc.LOGINFO)
        # A user can disable subtitles while paused. Recheck the live state
        # before reselecting so that choice is preserved.
        if self._paused_subtitles_visible and self._subtitles_are_visible():
            self._resync_active_subtitle(
                "resume", current_name=self._paused_subtitle_name
            )
        self._paused_subtitles_visible = False
        self._paused_subtitle_name = ""

    def onPlayBackSeek(self, time, seekOffset):
        xbmc.log("FLIXTOR: playback seek target_ms=%s offset_ms=%s" %
                 (time, seekOffset), xbmc.LOGINFO)
        if self._subtitles_are_visible():
            self._resync_active_subtitle(
                "seek", current_name=self._current_subtitle_name()
            )

    def onPlayBackStopped(self):
        self._save_position(completed=False)

    def onPlayBackEnded(self):
        self._save_position(completed=True)

    def onPlayBackError(self):
        self._save_position(completed=False, failed=True)

    def _save_position(self, completed=False, failed=False):
        self._playback_generation += 1
        generation = self._playback_generation
        self._clear_next_episode_control()
        if not self._tracking or not self._metadata:
            return
        self._tracking = False
        position_sampled = self._position_sampled
        meta = self._metadata.copy()
        next_episode = self._next_episode
        return_url = meta.pop("return_url", "")
        seek_on_start = float(meta.pop("seek_on_start", 0.0) or 0.0)
        meta.pop("next_episode", None)
        meta.pop("auto_play_next", None)
        last = self._last_time or 0.0
        total = self._total_time or 0.0
        # Finished if we hit natural EOF, OR watched past the completion
        # threshold (a small amount left / the auto-play hand-off). Otherwise
        # keep the resume point so mid-watch stops still resume.
        finished = completed or (total > 0 and last >= total * COMPLETION_THRESHOLD)
        meta["completed"] = bool(finished)
        meta["resume_seconds"] = 0.0 if finished else last
        meta["total_seconds"] = total
        xbmc.log("FLIXTOR: save_position: pid=%s resume=%.1f total=%.1f finished=%s" %
                 (meta.get("pid"), meta["resume_seconds"], meta["total_seconds"], finished),
                 xbmc.LOGINFO)
        # Until a position sample arrives, a resumed item still owns its
        # previous durable resume point. A quick normal Stop must not turn a
        # successful seek into a zero-position write. Explicit Start From
        # Beginning has seek_on_start=0 and retains its intentional reset.
        unmeasured_resume_stop = not position_sampled and not completed and seek_on_start > 0
        if not (failed and not position_sampled) and not unmeasured_resume_stop:
            self._history.update_position(meta)
        # When a TV episode is finished, surface its successor as "Up Next" in
        # Continue Watching so the user can keep going.
        if finished and not failed and next_episode and meta.get("media_type") == "tv":
            ne = dict(next_episode)
            ne["media_type"] = "tv"
            self._history.queue_next(ne)
        if generation != self._playback_generation:
            return  # A newer playback owns these fields now.
        self._tracking = False
        self._resume_seek_pending = False
        self._resume_seek_target = 0.0
        self._metadata = None
        self._next_episode = None
        self._auto_play_next_enabled = False
        self._countdown_shown = False
        self._subtitle_stream_index = -1
        self._preferred_subtitle_iso = ""
        self._paused_subtitles_visible = False
        self._paused_subtitle_name = ""
        if is_flixtor_title_context_url(return_url):
            # Kodi's Stop transition completes after this callback. Defer the
            # container change so it cannot be overwritten by the fullscreen
            # window closing, and so playback itself is never interrupted.
            self._pending_return_url = return_url
            self._pending_return_after = time.monotonic() + 0.5

    def poll_return_navigation(self):
        """Open a recommendation's exact Flixtor title after playback stops."""
        if (
            not self._pending_return_url
            or self.isPlaying()
            or time.monotonic() < self._pending_return_after
        ):
            return
        if is_dialog_open(xbmcgui.getCurrentWindowDialogId()):
            return
        # FullscreenVideo may linger briefly after Player.isPlaying() changes.
        # Wait for Kodi to finish its own Stop navigation before updating.
        if xbmcgui.getCurrentWindowId() == 12005:
            return

        return_url = self._pending_return_url
        self._pending_return_url = ""
        self._pending_return_after = 0.0
        set_parent_folder_items(True)
        xbmcgui.Window(10000).setProperty(ROOT_ROUTE_PROPERTY, "child")
        if xbmcgui.getCurrentWindowId() == 10025:
            # No ``replace``: Back from the selected title can still reach the
            # original Flixtor listing beneath it.
            xbmc.executebuiltin("Container.Update(%s)" % return_url)
        else:
            xbmc.executebuiltin("ActivateWindow(videos,%s)" % return_url)
        xbmc.log(
            "FLIXTOR: returned to selected recommendation: %s" % return_url,
            xbmc.LOGINFO,
        )

    def poll_position(self, allow_countdown=True):
        if not self._tracking or self._resume_seek_pending:
            return False
        generation = self._playback_generation
        try:
            last_time = max(0.0, self.getTime())
            total_time = max(0.0, self.getTotalTime())
        except RuntimeError:
            return False
        if generation != self._playback_generation or not self._tracking or self._resume_seek_pending:
            return False
        if self._resume_seek_target > 0:
            # seekTime() returning (or raising) does not establish the player
            # clock. Preserve durable progress until a real sample reaches the
            # requested position, allowing a small keyframe tolerance.
            tolerance = min(2.0, self._resume_seek_target * 0.05)
            if last_time < self._resume_seek_target - tolerance:
                return False
            self._resume_seek_target = 0.0
        self._last_time, self._total_time = last_time, total_time
        self._position_sampled = last_time > 0
        if (
            allow_countdown
            and self._auto_play_next_enabled
            and self._next_episode
            and not self._countdown_shown
            and self._total_time > 0
            and self._last_time >= self._total_time * COMPLETION_THRESHOLD
            and (self._total_time - self._last_time) <= NEXT_EPISODE_TRIGGER_OFFSET_SECONDS
        ):
            self._countdown_shown = True
            self._show_next_episode_countdown()
        return True

    def _show_next_episode_countdown(self):
        """Block for up to NEXT_EPISODE_COUNTDOWN_SECONDS with a cancelable dialog;
        on completion chain-play the next episode."""
        generation = self._playback_generation
        # Finish before EOF when there is time to display a prompt. Very short
        # remaining playback advances without a sleep once it meets 90%.
        countdown_seconds = min(NEXT_EPISODE_COUNTDOWN_SECONDS,
                                max(0, int(self._total_time - self._last_time) - 1))
        if countdown_seconds == 0:
            self._start_next_episode(generation, require_completed=True)
            return
        ne = self._next_episode or {}
        season = ne.get("season")
        episode = ne.get("episode")
        heading = "Up next"
        subtitle = "S%02dE%02d — %s" % (
            int(season) if season is not None else 0,
            int(episode) if episode is not None else 0,
            ne.get("title", ""),
        )
        dialog = xbmcgui.DialogProgress()
        dialog.create(heading, subtitle)
        cancelled = False
        for remaining in range(countdown_seconds, 0, -1):
            if generation != self._playback_generation or not self._tracking or not self.isPlaying():
                cancelled = True
                break
            if dialog.iscanceled():
                cancelled = True
                break
            pct = int((countdown_seconds - remaining) * 100 / countdown_seconds)
            dialog.update(pct, "%s\nStarting in %ds..." % (subtitle, remaining))
            xbmc.sleep(1000)
        dialog.close()
        if cancelled:
            xbmc.log("FLIXTOR: next-episode countdown cancelled by user", xbmc.LOGINFO)
            return
        self._start_next_episode(generation, require_completed=True)


def run():
    monitor = FlixtorMonitor()
    player = FlixtorPlayer()
    root_guard = FlixtorRootGuard(player)

    # Recover the normal Kodi preference first in case Kodi was force-stopped
    # while an earlier Flixtor root had it temporarily hidden.
    set_parent_folder_items(True)
    _install_keymap()
    _install_tmdb_player()
    _seed_tmdb_helper_keys()

    addon = xbmcaddon.Addon()

    # Refresh bundled card-art textures if the addon was updated. Kodi caches
    # textures by path and our card filenames are stable across releases, so a
    # release that swapped the images would otherwise keep serving stale
    # thumbnails. Fires at most once per version change (no-op otherwise) and
    # runs before auto-launch so the first menu render caches the new art.
    try:
        cachemaint.purge_card_art_on_upgrade(addon.getAddonInfo("version"))
    except Exception as exc:
        xbmc.log("FLIXTOR: card-art refresh error: %s" % exc, xbmc.LOGINFO)

    # Auto-launch Flixtor on Kodi startup (configurable via settings). Under
    # Flixtor Horizon the skin's Home is the Flixtor home, so stay there.
    if should_auto_launch(addon.getSetting("auto_launch"), xbmc.getSkinDir()):
        xbmc.sleep(2000)
        xbmc.executebuiltin("ActivateWindow(videos,plugin://plugin.video.flixtor/)")
    else:
        xbmc.log("FLIXTOR: auto-launch skipped (setting or skin Home)", xbmc.LOGINFO)

    xbmc.log(
        "FLIXTOR: service started v%s" % addon.getAddonInfo("version"),
        xbmc.LOGINFO,
    )

    metadata_workers = MetadataWorkers(
        xbmcvfs.translatePath(addon.getAddonInfo("profile")),
        lambda: not player.isPlaying() and not monitor.abortRequested()
        and addon.getSetting("rating_enrichment") != "false")
    metadata_workers.start()
    ticks = 0
    last_active_tick = 0   # most recent tick with media loaded (incl. paused)
    maint_pending = False
    aborting = False
    guard_error_reported = False
    return_navigation_error_reported = False
    while not monitor.abortRequested():
        player.poll_position()
        ticks += 1
        if player.isPlaying():
            last_active_tick = ticks
        # Arm a maintenance check shortly after startup, then hourly.
        # cachemaint itself limits real passes to one per 24h and honors the
        # auto_cache_cleanup setting.
        if ticks == MAINT_FIRST_CHECK_TICK or ticks % MAINT_RECHECK_TICKS == 0:
            maint_pending = True
        # Run only once playback has been idle for MAINT_IDLE_TICKS — a pass
        # during playback starves the video cache on Fire TV sticks. A pass
        # that is due but deferred by playback runs minutes after the user
        # stops watching; abort_check bails mid-pass if playback starts again
        # or Kodi begins shutting down.
        if maint_pending and ticks - last_active_tick >= MAINT_IDLE_TICKS:
            maint_pending = False
            try:
                cachemaint.maybe_run_auto(
                    abort_check=lambda: player.isPlaying() or monitor.abortRequested())
            except Exception as exc:
                xbmc.log("FLIXTOR: cache maintenance error: %s" % exc, xbmc.LOGINFO)
        for _guard_poll in range(
                int(SERVICE_TICK_SECONDS / ROOT_GUARD_POLL_SECONDS)):
            try:
                player.poll_next_episode_request()
            except Exception as exc:
                xbmc.log("FLIXTOR: next-episode request error: %s" % exc, xbmc.LOGERROR)
            try:
                player.poll_return_navigation()
            except Exception as exc:
                xbmc.log(
                    "FLIXTOR: recommendation return error: %s" % exc,
                    xbmc.LOGERROR,
                )
                if not return_navigation_error_reported:
                    return_navigation_error_reported = True
                    xbmcgui.Dialog().notification(
                        "Flixtor",
                        "Could not restore the selected title — check Kodi log",
                        xbmcgui.NOTIFICATION_ERROR,
                        4000,
                    )
            try:
                root_guard.poll()
            except Exception as exc:
                xbmc.log(
                    "FLIXTOR: root guard error: %s" % exc,
                    xbmc.LOGERROR,
                )
                if not guard_error_reported:
                    guard_error_reported = True
                    xbmcgui.Dialog().notification(
                        "Flixtor",
                        "Home protection error — check Kodi log",
                        xbmcgui.NOTIFICATION_ERROR,
                        4000,
                    )
            if monitor.waitForAbort(ROOT_GUARD_POLL_SECONDS):
                aborting = True
                break
        if aborting:
            break

    player._clear_next_episode_control()
    metadata_workers.close()
    set_parent_folder_items(True)
    xbmc.log("FLIXTOR: service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    run()
