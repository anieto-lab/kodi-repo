"""Cache maintenance — keeps the addon's on-device disk footprint bounded.

Four growth surfaces, in descending size order:

1. Kodi's texture cache (Textures13.db + Thumbnails/). Kodi caches every
   poster/episode-still it renders and never expires them, so browsing the
   ~49K-title catalog accumulates hundreds of MB on an 8GB Fire TV stick.
   We prune cached textures from Flixtor's image CDN (img.xcdn.to) once
   they go unused for TEXTURE_MAX_AGE_DAYS — via Kodi's own Textures
   JSON-RPC API (RemoveTexture deletes the DB row *and* the thumbnail
   file). Never touch Textures13.db with sqlite while Kodi is running.
2. tmdb_cache.json — one entry per unique title ever browsed, indefinite
   by design. TTL'd here (hits 90d, misses 30d so late TMDb additions get
   re-resolved) plus a hard entry cap as a backstop.
3. subtitles/ — already pruned >7d at playback time, but only when a
   preferred track is found; swept here too so files can't linger after
   subtitles fall out of use.
4. addons/packages/ — Kodi keeps downloaded addon-update zips (~6MB per
   Flixtor release) up to its own 200MB cap; we delete stale versions of
   our zips, keeping the newest of each.

Auto-run: service.py calls maybe_run_auto() shortly after startup and then
hourly; a real pass executes at most once per AUTO_INTERVAL_HOURS (stamped
in cache_maint.json) and only while the auto_cache_cleanup setting is on.
Manual: purge_all_images() backs the "Clear cached poster images" button
in Settings > Maintenance (all ages, not just stale).

Zero external dependencies; degrades to safe no-ops outside Kodi.
"""

import json
import os
import re
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs

    def _log(msg):
        xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)

    def _profile_dir():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        d = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return d

    def _thumbnails_dir():
        return xbmcvfs.translatePath("special://thumbnails/")

    def _packages_dir():
        return xbmcvfs.translatePath("special://home/addons/packages/")

    def _jsonrpc(method, params):
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if "error" in resp:
            raise RuntimeError("%s: %s" % (method, resp["error"]))
        return resp.get("result") or {}

    def _auto_cleanup_enabled():
        try:
            addon = xbmcaddon.Addon("plugin.video.flixtor")
            return addon.getSetting("auto_cache_cleanup") != "false"
        except Exception:
            return True
except ImportError:
    # Local testing outside Kodi — same fallback layout as tmdb/watchhistory.
    def _log(msg):
        print("FLIXTOR: " + msg)

    def _test_root(sub):
        d = os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata", sub)
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return d

    def _profile_dir():
        return _test_root("")

    def _thumbnails_dir():
        return _test_root("thumbnails")

    def _packages_dir():
        return _test_root("packages")

    def _jsonrpc(method, params):
        raise RuntimeError("Kodi JSON-RPC unavailable outside Kodi")

    def _auto_cleanup_enabled():
        return True


IMAGE_CDN_MARKER = "img.xcdn.to"
TEXTURE_MAX_AGE_DAYS = 30
TMDB_HIT_MAX_AGE_DAYS = 90
TMDB_MISS_MAX_AGE_DAYS = 30
TMDB_MAX_ENTRIES = 4000
SUBTITLE_MAX_AGE_DAYS = 7
AUTO_INTERVAL_HOURS = 24
STAMP_FILE = "cache_maint.json"

_PACKAGE_RE = re.compile(
    r"^(plugin\.video\.flixtor|repository\.flixtor)-(\d+(?:\.\d+)*)\.zip$")


def format_size(num_bytes):
    """Human-readable size for dialogs/toasts."""
    if num_bytes >= 1024 ** 3:
        return "%.1f GB" % (num_bytes / (1024.0 ** 3))
    if num_bytes >= 1024 ** 2:
        return "%.1f MB" % (num_bytes / (1024.0 ** 2))
    if num_bytes >= 1024:
        return "%.0f KB" % (num_bytes / 1024.0)
    return "%d B" % num_bytes


def _file_size(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _dir_usage(d):
    """(file_count, total_bytes) for the files directly inside d."""
    count = 0
    total = 0
    try:
        names = os.listdir(d)
    except OSError:
        return 0, 0
    for name in names:
        p = os.path.join(d, name)
        if os.path.isfile(p):
            count += 1
            total += _file_size(p)
    return count, total


# ── Kodi texture cache (posters / episode stills) ─────────────────────

def _parse_lastused(texture):
    """Newest 'lastused' across a texture's size records, as epoch seconds.

    A texture with no usage records isn't being displayed at all — return 0
    so it falls on the stale side of any cutoff.
    """
    newest = 0
    for s in texture.get("sizes") or []:
        raw = s.get("lastused") or ""
        try:
            newest = max(newest, time.mktime(time.strptime(raw, "%Y-%m-%d %H:%M:%S")))
        except (ValueError, OverflowError):
            pass
    return newest


def _query_textures(rpc=None):
    """Our CDN's texture rows, or None when the Textures API is unavailable
    (callers distinguish "none cached" from "couldn't ask")."""
    rpc = rpc or _jsonrpc
    try:
        result = rpc("Textures.GetTextures", {
            "properties": ["url", "cachedurl", "sizes"],
            "filter": {"field": "url", "operator": "contains",
                       "value": IMAGE_CDN_MARKER},
        })
    except Exception as exc:
        _log("cachemaint: texture query failed: %s" % exc)
        return None
    return result.get("textures") or []


def prune_textures(max_age_days=TEXTURE_MAX_AGE_DAYS, rpc=None, progress=None):
    """Remove cached Flixtor CDN textures unused for max_age_days.

    max_age_days=0 removes all of them (manual purge). Scoped to
    IMAGE_CDN_MARKER so other addons' art and our bundled card images are
    untouched; removed posters simply re-download on next browse.
    Returns (removed_count, freed_bytes).
    """
    rpc = rpc or _jsonrpc
    textures = _query_textures(rpc)
    if textures is None:
        return 0, 0

    cutoff = time.time() - max_age_days * 86400
    stale = [t for t in textures if _parse_lastused(t) < cutoff]
    thumbs = _thumbnails_dir()
    removed = 0
    freed = 0
    for i, tex in enumerate(stale):
        tid = tex.get("textureid")
        if tid is None:
            continue
        size = 0
        cached = tex.get("cachedurl") or ""
        if cached:
            try:
                size = os.path.getsize(os.path.join(thumbs, cached))
            except OSError:
                size = 0
        try:
            rpc("Textures.RemoveTexture", {"textureid": tid})
        except Exception as exc:
            _log("cachemaint: remove texture %s failed: %s" % (tid, exc))
            continue
        removed += 1
        freed += size
        if progress:
            progress(i + 1, len(stale))
    if removed:
        _log("cachemaint: pruned %d cached images, %.1f MB (unused > %dd)"
             % (removed, freed / 1048576.0, max_age_days))
    return removed, freed


def purge_all_images(progress=None):
    """Manual 'Clear cached poster images' — all our textures, any age."""
    return prune_textures(max_age_days=0, progress=progress)


# ── tmdb_cache.json ────────────────────────────────────────────────────

def prune_tmdb_cache(now=None):
    """TTL + size-cap the TMDb id cache. Returns entries dropped.

    Entries carry a 'ts' epoch stamp (written by tmdb.py since v1.23.0);
    legacy entries without one get stamped now and age out from today.
    A concurrent plugin process may rewrite the file between our read and
    replace — both sides write atomically, so worst case a few entries are
    lost or linger until the next pass. Harmless for a cache.
    """
    path = os.path.join(_profile_dir(), "tmdb_cache.json")
    try:
        with open(path, "r") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return 0
    if not isinstance(data, dict) or not data:
        return 0

    now = now or time.time()
    hit_cutoff = now - TMDB_HIT_MAX_AGE_DAYS * 86400
    miss_cutoff = now - TMDB_MISS_MAX_AGE_DAYS * 86400
    kept = {}
    stamped_legacy = False
    for key, entry in data.items():
        if not isinstance(entry, dict):
            continue
        ts = entry.get("ts")
        if not isinstance(ts, (int, float)):
            kept[key] = dict(entry, ts=int(now))
            stamped_legacy = True
            continue
        cutoff = miss_cutoff if entry.get("miss") else hit_cutoff
        if ts >= cutoff:
            kept[key] = entry
    if len(kept) > TMDB_MAX_ENTRIES:
        oldest_first = sorted(kept.items(), key=lambda kv: kv[1].get("ts", 0))
        kept = dict(oldest_first[len(oldest_first) - TMDB_MAX_ENTRIES:])

    dropped = len(data) - len(kept)
    if dropped or stamped_legacy:
        tmp = path + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(kept, f)
            os.replace(tmp, path)
        except OSError as exc:
            _log("cachemaint: tmdb cache write failed: %s" % exc)
            return 0
    if dropped:
        _log("cachemaint: pruned %d tmdb cache entries (%d kept)"
             % (dropped, len(kept)))
    return dropped


# ── Localized subtitle files ───────────────────────────────────────────

def prune_subtitles(max_age_days=SUBTITLE_MAX_AGE_DAYS):
    """Sweep the localized-subtitle cache. Returns (removed, freed_bytes)."""
    subs_dir = os.path.join(_profile_dir(), "subtitles")
    try:
        names = os.listdir(subs_dir)
    except OSError:
        return 0, 0
    cutoff = time.time() - max_age_days * 86400
    removed = 0
    freed = 0
    for name in names:
        path = os.path.join(subs_dir, name)
        try:
            if os.path.getmtime(path) < cutoff:
                size = os.path.getsize(path)
                os.remove(path)
                removed += 1
                freed += size
        except OSError:
            pass
    if removed:
        _log("cachemaint: pruned %d subtitle files" % removed)
    return removed, freed


def purge_all_subtitles():
    """Manual 'Clear subtitle files' — every cached track, any age."""
    return prune_subtitles(max_age_days=0)


# ── Flixtor API response cache (api_cache.json) ───────────────────────

def prune_api_cache():
    """Drop expired entries from the flixtor client's disk cache. The
    client prunes on every write; this catches files left idle between
    writes. Entry shape: {key: {ts, ttl, data}}. Returns entries dropped."""
    path = os.path.join(_profile_dir(), "api_cache.json")
    try:
        with open(path, "r") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return 0
    if not isinstance(data, dict) or not data:
        return 0
    now = time.time()
    kept = {k: e for k, e in data.items()
            if isinstance(e, dict) and now - e.get("ts", 0) < e.get("ttl", 0)}
    dropped = len(data) - len(kept)
    if dropped:
        tmp = path + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(kept, f)
            os.replace(tmp, path)
        except OSError as exc:
            _log("cachemaint: api cache write failed: %s" % exc)
            return 0
        _log("cachemaint: pruned %d expired api cache entries" % dropped)
    return dropped


# ── Stale addon-update zips in Kodi's package cache ───────────────────

def prune_old_packages(keep_newest=True):
    """Delete Flixtor update zips from Kodi's package cache.

    keep_newest=True (auto-clean) keeps the most recent version per addon
    id; False (manual "Clear cached update zips") removes them all. Only
    our own zips are touched, and Kodi re-downloads from the repo if one
    is ever needed again. Returns (removed, freed_bytes).
    """
    try:
        pkg_dir = _packages_dir()
        names = os.listdir(pkg_dir)
    except OSError:
        return 0, 0
    by_addon = {}
    for name in names:
        m = _PACKAGE_RE.match(name)
        if m:
            version = tuple(int(p) for p in m.group(2).split("."))
            by_addon.setdefault(m.group(1), []).append((version, name))
    removed = 0
    freed = 0
    for versions in by_addon.values():
        versions.sort()
        for _, name in (versions[:-1] if keep_newest else versions):
            path = os.path.join(pkg_dir, name)
            try:
                size = os.path.getsize(path)
                os.remove(path)
                removed += 1
                freed += size
            except OSError:
                pass
    if removed:
        _log("cachemaint: pruned %d update zips, %.1f MB"
             % (removed, freed / 1048576.0))
    return removed, freed


def purge_all_packages():
    """Manual 'Clear cached update zips' — every version, incl. current."""
    return prune_old_packages(keep_newest=False)


# ── Usage report (settings "View cache storage usage") ────────────────

def measure_usage(rpc=None, progress=None):
    """Measure every cache surface the addon owns or feeds.

    Returns a dict:
      images    — (count, bytes) of our CDN textures in Kodi's cache, or
                  None when the Textures API can't be queried (UI shows
                  n/a rather than a misleading zero)
      tmdb      — (entry_count, bytes) of tmdb_cache.json
      subtitles — (file_count, bytes) of the localized-subtitle dir
      packages  — (zip_count, bytes) of our update zips in addons/packages/
                  (all versions, including the current one)
      other     — bytes of everything else in the profile dir (histories,
                  favorites, cookies, settings, stamp)
    """
    report = {}

    textures = _query_textures(rpc)
    if textures is None:
        report["images"] = None
    else:
        thumbs = _thumbnails_dir()
        total = 0
        for i, tex in enumerate(textures):
            cached = tex.get("cachedurl") or ""
            if cached:
                total += _file_size(os.path.join(thumbs, cached))
            if progress:
                progress(i + 1, len(textures))
        report["images"] = (len(textures), total)

    profile = _profile_dir()

    tmdb_path = os.path.join(profile, "tmdb_cache.json")
    entries = 0
    try:
        with open(tmdb_path, "r") as f:
            data = json.load(f)
        if isinstance(data, dict):
            entries = len(data)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    report["tmdb"] = (entries, _file_size(tmdb_path))

    report["subtitles"] = _dir_usage(os.path.join(profile, "subtitles"))

    pkg_count = 0
    pkg_bytes = 0
    try:
        pkg_dir = _packages_dir()
        for name in os.listdir(pkg_dir):
            if _PACKAGE_RE.match(name):
                pkg_count += 1
                pkg_bytes += _file_size(os.path.join(pkg_dir, name))
    except OSError:
        pass
    report["packages"] = (pkg_count, pkg_bytes)

    other = 0
    try:
        for name in os.listdir(profile):
            path = os.path.join(profile, name)
            if name != "tmdb_cache.json" and os.path.isfile(path):
                other += _file_size(path)
    except OSError:
        pass
    report["other"] = other
    return report


def last_auto_run():
    """(epoch_or_0, stats_dict) of the most recent auto-maintenance pass."""
    try:
        with open(_stamp_path(), "r") as f:
            data = json.load(f)
        return float(data.get("last_run", 0)), data.get("last_stats") or {}
    except (FileNotFoundError, json.JSONDecodeError, OSError, TypeError, ValueError):
        return 0, {}


# ── Orchestration ──────────────────────────────────────────────────────

def run_maintenance():
    """One full cleanup pass. Returns a stats dict (also logged)."""
    t0 = time.time()
    tex_n, tex_b = prune_textures()
    tmdb_n = prune_tmdb_cache()
    api_n = prune_api_cache()
    sub_n, sub_b = prune_subtitles()
    pkg_n, pkg_b = prune_old_packages()
    stats = {
        "images": tex_n, "images_bytes": tex_b,
        "tmdb_entries": tmdb_n,
        "api_entries": api_n,
        "subtitles": sub_n, "subtitles_bytes": sub_b,
        "packages": pkg_n, "packages_bytes": pkg_b,
    }
    _log("cachemaint: pass done in %.1fs — images %d (%.1f MB), tmdb %d, "
         "api %d, subs %d, packages %d (%.1f MB)"
         % (time.time() - t0, tex_n, tex_b / 1048576.0, tmdb_n,
            api_n, sub_n, pkg_n, pkg_b / 1048576.0))
    return stats


def _stamp_path():
    return os.path.join(_profile_dir(), STAMP_FILE)


def _last_run():
    return last_auto_run()[0]


def _write_stamp(now, stats):
    tmp = _stamp_path() + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump({"last_run": now, "last_stats": stats}, f)
        os.replace(tmp, _stamp_path())
    except OSError as exc:
        _log("cachemaint: stamp write failed: %s" % exc)


def maybe_run_auto():
    """Service entry point — called hourly, runs a real pass at most once
    per AUTO_INTERVAL_HOURS. A last_run stamp in the future (clock moved
    back) is ignored so a bad clock can't disable cleanup forever.
    Returns True when a pass ran."""
    if not _auto_cleanup_enabled():
        return False
    now = time.time()
    elapsed = now - _last_run()
    if 0 <= elapsed < AUTO_INTERVAL_HOURS * 3600:
        return False
    stats = run_maintenance()
    _write_stamp(now, stats)
    return True
