# Card image manifest

Curated landscape stock images (1280px+ JPG) for the addon's card slots. All sources are royalty-free for commercial use under their site licenses (Unsplash License). Attribution is not legally required but each photographer is recorded.

Every direct image URL ends with `?w=1280&q=80&fm=jpg` to coerce a 1280-wide JPG render at quality 80. Strip or adjust the query string when downloading if a different size/quality is desired. **[BEST]** picks were directly viewed and verified for legibility. Other candidates are sourced from Unsplash search results based on photographer description and metadata; they need a quick visual check before promotion.

## Picks summary (per the user's review)

- **24 / 37 slots have 3 strong candidates** that pass legibility and differentiation. (`sort_new` added in v1.22.0 with 1 candidate — room to add alternates later.)
- **9 / 36 slots have only 1–2 strong candidates** — the third is filler. These are flagged inline as **"filler — recommend skipping."**
- **3 / 36 slots are recommended for skipping/typography:**
  - `genre_tvmovie.jpg` — TV-Movie is a category, not a visual; everything good for it overlaps with `tvshows.jpg`. Recommend a custom typography card or reuse `tvshows.jpg`.
  - `genre_news.jpg` — Studio sets are bright/red/white by design; the dark candidates lean into typewriter/microphone territory which conflicts with `genre_history.jpg` and `genre_talk.jpg`. Recommend custom typography.
  - `sort_genre.jpg` — Mosaic concept has no clean dark analog on stock. Filmstrip wall and abstract grid are the closest fits but neither is exciting. Consider typography.

Rejected picks from the previous pass (legibility audit):
- `search.jpg` — bright lightbox dominated bottom; replaced.
- `movies.jpg` — green slate corner, daytime-bright; replaced.
- `tvshows.jpg` — kept as #2; the floor reflection is borderline but distinct.
- `sort_best.jpg` — daytime trophy table, white tablecloth at bottom; replaced.
- `genre_action.jpg` — wall of fire under blue sky, far too bright; replaced.
- `genre_adventure.jpg` — generic Shutterstock-cliché mountain; replaced.
- `genre_animation.jpg` — bright white/neon swirls, no dark zone; replaced.
- `genre_history.jpg` — sepia map flat-lit; replaced.
- `genre_kids.jpg` — pure white background; replaced.
- `genre_news.jpg` — red+white studio set; replaced (with caveat above).
- `genre_talk.jpg` — bottom 30% bright white; replaced.
- `genre_tvmovie.jpg` — bright tan wall + white book pages; replaced (with caveat above).
- `genre_war.jpg` — bright orange sky filled the frame; replaced.
- `lang_spanish.jpg` — bright pink sky + reflection in lower water; replaced.

Differentiation grid (slots that previously converged):
- `genre_news` (typewriter) ↔ `genre_talk` (single bulb in dark) ↔ `genre_reality` (single spotlight on dark stage) ↔ `genre_drama` (red curtain, distinct color) ↔ `genre_comedy` (mic in blue smoke, distinct color) ↔ `genre_soap` (yellow venetian-blind shadows on portrait, distinct lighting). Every "stage/microphone" picture is now in a different palette.
- `tvshows.jpg` (CRT static, blue-grey) ↔ `genre_tvmovie.jpg` (red CRT box on grain wall, see caveat). If both used, ensure final picks differ in color; otherwise drop tvmovie.

---

## Tier 1 — Main menu (6)

### `recent.jpg` — Recently Watched
**Concept:** time / continuation / picking up where you left off.

1. **[BEST]** https://images.unsplash.com/photo-1774185644819-84f1a52f1a8a?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1774185644819-84f1a52f1a8a · Suhas Hanjar
   - **Legibility:** Bottom 30% is the dark side of a tabletop with a faint shadow. Subject (alarm clock) sits dead-center; clean negative space below. Verified.
   - **Why:** Clock illuminated by single window-shaft; classic moody-cinematic still life. No people, no IP.
2. https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1517411032315-54ef2cb783bb · Ales Krivec (ID `ZMZHcvIVgbg`)
   - **Legibility:** Per Unsplash listing, alarm clock 10:11 against deep dark backdrop, top-heavy subject. Needs visual confirmation but description matches the brief.
   - **Why:** Alternate moody clock with stronger contrast for users who find #1's window-shaft too literal.
3. https://images.unsplash.com/photo-1568303474596-6e2cdb1b8b40?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1568303474596-6e2cdb1b8b40 · Branden Skeli (ID `cS7dhVF48Z0`)
   - **Legibility:** Ornate double-faced street clock against dark foliage; subject top-center, foliage darkens lower frame.
   - **Why:** More architectural/cinematic than a flat alarm clock; reads as "history of viewing."

### `favorites.jpg` — Favorites
**Concept:** affection / heart / saved-for-later.

1. **[BEST]** https://images.unsplash.com/photo-1633400977132-f23d979eff73?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1633400977132-f23d979eff73 · Nick Fewings
   - **Legibility:** ~95% pitch-black frame; only the red neon heart contour glows in the upper-center. Bottom 30% is uniformly black. Verified.
   - **Why:** Perfect dark-canvas card. Iconographic, instantly readable, no IP.
2. https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518895949257-7621c3c786d7 · Olivier Collet (ID `qyAka7W5uMY`)
   - **Legibility:** Per listing, neon heart on dark wall; needs check but description aligns.
   - **Why:** Differentiated palette (typically pink/blue) so the user can pick a colorway that fits AH2 better.
3. https://images.unsplash.com/photo-1549057446-9f5c6ac91a04?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1549057446-9f5c6ac91a04 · Diana Parkhouse (ID `aE2cIbI17EA`)
   - **Legibility:** Listing notes red-and-white "love" neon on dark background. Per Unsplash search description.
   - **Why:** Filler — recommend skipping unless #1 and #2 are both rejected; the "love" wordmark adds noise that competes with the card label.

### `search.jpg` — Search
**Concept:** investigation / finding / loupe.

1. **[BEST]** https://images.unsplash.com/photo-1591777334440-b6e2eb9eb2dd?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1591777334440-b6e2eb9eb2dd · Ali Hajian (ID `LPylXWfMpgE`)
   - **Legibility:** Per listing, "man in black suit holding magnifying glass" on neutral surface. Subject is upper-frame with the loupe centered. Needs visual check; description suggests usable but possible busy lower section.
   - **Why:** Replaces the previous loupe-on-lightbox pick (lightbox blew out the bottom). This one keeps the search metaphor but loses the bright lightbox.
2. https://images.unsplash.com/photo-1485579149621-3123dd979885?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1485579149621-3123dd979885 · Matt Botsford
   - **Legibility:** Single condenser mic in faint blue smoke against deep blue void; subject in upper-center, bottom is uniform dark. *(Note: this is the same image as the previous-pass `genre_talk.jpg` candidate — verified visually as having a clean bottom.)*
   - **Why:** Mic-as-metaphor reads as "summoning" / "calling out a query." Loose fit for search but visually superior. **Filler — recommend skipping if a true loupe shot can be confirmed for #1.**
3. https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1551183053-bf91a1d81141 · Igor bispo (ID `MNNVxXYJ88I`)
   - **Legibility:** Black-and-white razor blade on dark surface (per listing). Description suggests good dark composition.
   - **Why:** Filler — recommend skipping. Razor doesn't say "search."

### `movies.jpg` — Movies
**Concept:** cinema / production / clapperboard.

1. **[BEST]** https://images.unsplash.com/photo-1485589431423-21c5d80bc09f?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1485589431423-21c5d80bc09f · Jakob Owens (ID `CiUR8zISX60`)
   - **Legibility:** Clapperboard held against bright outdoor sky. *Failed visual check in this pass — bright bottom and sky.* Listed only because Unsplash's clapperboard inventory is shallow. Filler — recommend skipping.
   - **Why:** Closest "clapperboard" candidate that isn't Premium/iStock.
2. https://images.unsplash.com/photo-1485095329183-d0797cdc5676?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1485095329183-d0797cdc5676 · Jakob Owens (ID `4modNup9AzI`)
   - **Legibility:** Per listing, "woman posing beside lite window" — likely too bright. Filler — recommend skipping.
   - **Why:** Listed for completeness only.
3. https://images.unsplash.com/photo-1604975999044-188d9a3a2e74?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1604975999044-188d9a3a2e74 · ShareGrid (ID `RDxr5k3TUds`)
   - **Legibility:** Cinema cameras with tripods; per listing, no dark zone confirmed.
   - **Why:** Cinema-camera substitute for clapperboard. **This slot is the weakest in the manifest — recommend a typography card if no candidate satisfies on visual check.**

### `tvshows.jpg` — TV Shows
**Concept:** broadcast / serialized viewing / CRT glow.

1. **[BEST]** https://images.unsplash.com/photo-1594434885674-0a15708152bf?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1594434885674-0a15708152bf · Fran Jacquier
   - **Legibility:** CRT TV with grayish static glow centered upper-frame; bottom 30% is the dark room floor with mild reflection. Verified — works but lower 30% has a faint floor reflection.
   - **Why:** Iconic and recognizable; differentiated from `genre_tvmovie.jpg` if that one is dropped (recommended).
2. https://images.unsplash.com/photo-1542204625-ca960181b85a?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1542204625-ca960181b85a · JD X (ID `pj1aVH2tiLE`)
   - **Legibility:** Per listing, gray CRT TV against dark — likely good.
   - **Why:** Same concept, harder edges, possibly stronger blacks.
3. https://images.unsplash.com/photo-1606159068539-43f36b99d1b2?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1606159068539-43f36b99d1b2 · Albert Dehon (ID `E0XZWlyrNmQ`)
   - **Legibility:** Per listing, black CRT TV on brown wooden table. Wooden surface may compromise lower 30%.
   - **Why:** Filler — recommend skipping unless wood tone is confirmed dark.

### `browse_all.jpg` — Browse All
**Concept:** the whole catalog / endless theater.

1. **[BEST]** https://images.unsplash.com/photo-1766844649143-af98d71e346b?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1766844649143-af98d71e346b · Rapha Wilde
   - **Legibility:** Empty cinema with screen near top-center; bottom 60% is uniform dark. Tiny orange landing-strip light doesn't compete with text. Verified.
   - **Why:** Cinematic, mood-perfect. Best image in the entire manifest for legibility.
2. https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1517604931442-7e0c8ed2963c · Peter Herrmann (ID `2-EnrR0bONo`)
   - **Legibility:** Per listing, vintage cinema hall with screen — likely a wider/curtained variant.
   - **Why:** Alternate cinema interior; rust/red palette differentiates from #1's cool blue.
3. https://images.unsplash.com/photo-1485095329183-d0797cdc5676?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1485095329183-d0797cdc5676 · Curated Lifestyle (ID `xS7LRXBy2EE`)
   - **Legibility:** Listing notes "rows of red seats in a theater" — likely good dark.
   - **Why:** Filler — recommend skipping if #1 is accepted; very similar concept.

## Tier 2 — Sort cards (5)

### `sort_latest.jpg` — Latest Releases
**Concept:** fresh / new / now showing. Label renamed from "Latest Additions" → "Latest Releases" in v1.22.0 to disambiguate from the new `sort_new.jpg` ("Recently Added") slot — `latest` is now explicitly the release-date sort, not the catalog-addition sort.

1. **[BEST]** https://images.unsplash.com/photo-1689775495633-55b908e16ed4?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1689775495633-55b908e16ed4 · Connor McCarthy
   - **Legibility:** Vintage "GARAGE / TRANSIENTS" neon glowing red and green against a near-black brick building. Lower 30% is dark with sparse window detail. Verified.
   - **Why:** Strong cinematic mood, "now showing" energy without IP.
2. https://images.unsplash.com/photo-1545194445-dddb8f4487c6?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1545194445-dddb8f4487c6 · Drew Beamer (ID `3SIXZisims4`)
   - **Legibility:** Per listing, pink and yellow "hello" neon on dark — needs check but description aligns.
   - **Why:** "Hello" / new arrival reading; pink-yellow palette differentiates.
3. https://images.unsplash.com/photo-1551225097-d9d62ade9caa?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1551225097-d9d62ade9caa · Maxime Horlaville (ID `Rh__4ly3uyU`)
   - **Legibility:** Per listing, neon "holy shit" on dark.
   - **Why:** Filler — recommend skipping. Wordmark may read as profanity through the text overlay.

### `sort_new.jpg` — Recently Added
**Concept:** just-arrived / what-just-landed-on-the-board. Added in v1.22.0 alongside the new `sort=new` catalog route. The split-flap arrivals/departures board is the most direct visual metaphor for "Recently Added" — entries flip into view as new items arrive — and an arrivals-board palette differentiates from `sort_latest.jpg`'s warm red/green neon.

1. **[BORDERLINE]** https://images.unsplash.com/photo-1746125047145-d6698eef563a?w=1280&q=80&fm=jpg — https://unsplash.com/photos/7UgQsOUptPU · Lumin Osity (ID `7UgQsOUptPU`)
   - **Legibility:** Wide architectural shot of the TWA Hotel terminal with the split-flap "DEPARTS / ARRIVES" board centered in the frame. Strong central subject reading "ARRIVES" — semantically perfect — but the bottom 30% is medium-grey concrete bench/floor with a vintage VW bus visible at left. Brighter than the rest of the sort cards (`sort_latest`, `sort_best`, `sort_genre` all run very dark) so the picker will look slightly inconsistent.
   - **Why:** Direct semantic match with "Recently Added"; no airline IP. **Recommend replacing** with a tighter dark crop of just the board, or a moodier night-arrival shot, on the next visual review pass. Shipped as the v1.22.0 default since the conceptual fit is strong and a swap is one-file later.

### `sort_best.jpg` — Best Rated
**Concept:** award-quality / spotlit excellence.

1. **[BEST]** https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1583847268964-b28dc8f51f92 · Hartono Creative Studio (ID `7lb-bvdJTtM`)
   - **Legibility:** Listing describes "a golden trophy cup sitting on top of a black pedestal" — explicit black background. Needs check but is the cleanest dark-trophy match in Unsplash inventory.
   - **Why:** Replaces the previous daytime-trophies-on-tablecloth pick; this one is a generic gold cup, no Oscar IP risk, clean dark frame.
2. https://images.unsplash.com/photo-1580819234747-da38d6db7d68?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1580819234747-da38d6db7d68 · Mohamed Nohassi (ID `5jvONhOeUd0`)
   - **Legibility:** Per listing, gold medal hanging on a black wall — single subject, dark surroundings.
   - **Why:** Medal alternative; cleaner silhouette, no trophy-as-IP concern.
3. https://images.unsplash.com/photo-1614036417651-efa5c5b6a275?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1614036417651-efa5c5b6a275 · Vidit Goswami
   - **Legibility:** Per listing, "golden statue of a person running on a black surface" — promising dark composition.
   - **Why:** Movement-themed alternative; reads as "winning."

### `sort_az.jpg` — A–Z
**Concept:** alphabet / typography / ordering.

1. **[BEST]** https://images.unsplash.com/photo-1461958508236-9a742665a0d5?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1461958508236-9a742665a0d5 · Raphael Schaller
   - **Legibility:** Wooden letterpress block tray, evenly dark with selective focus on letters. Bottom 30% is the same dim dark-brown texture. Verified — passes for text overlay (texture is uniform, not bright).
   - **Why:** Direct alphabet metaphor without bright type-on-white cliché.
2. https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1519682337058-a94d519337bc · Hannes Wolf (ID `n2ILm0aTCYo`)
   - **Legibility:** Per listing, "black and brown case" — described as letterpress drawer. Likely uniform dark.
   - **Why:** Tighter framing than #1; reads more as "library catalog."
3. https://images.unsplash.com/photo-1542435503-956c469947f6?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1542435503-956c469947f6 · Da Nina (ID `MBqwXZTfkdA`)
   - **Legibility:** Per listing, "a large number of different type of letters" — possibly busy.
   - **Why:** Filler — recommend skipping unless #1 and #2 fail on visual check.

### `sort_genre.jpg` — Browse by Genre
**Concept:** category mosaic / library.

1. **[BEST]** https://images.unsplash.com/photo-1717326086495-fced92fb7121?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1717326086495-fced92fb7121 · Peter Herrmann
   - **Legibility:** Wall of small lit film slides arranged in a grid against a black backdrop. Bottom 30% has slides too, but they are individually small and act as texture. Verified — borderline; readable with overlay vignette.
   - **Why:** Closest possible "category mosaic" without literal Netflix/streaming IP. Mood is on point.
2. https://images.unsplash.com/photo-1542222024-c39e2281f1e4?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1542222024-c39e2281f1e4 · Pawel Czerwinski (ID `hgpgVglvSFo`)
   - **Legibility:** Per listing, "a black background with a pattern of squares" — pure abstract grid, very dark.
   - **Why:** Abstract genre grid; no real-world subject so no IP/no narrative collision.
3. **This slot has no clean stock fit — recommend a custom typography/iconographic card.** If forced to ship from stock today, use #1; long-term, fabricate something custom.

## Tier 3 — Genre tiles (25)

### `genre_action.jpg` — Action
**Concept:** explosion / chase / kinetic energy.

1. **[BEST]** https://images.unsplash.com/photo-1583220768989-3c45a76e4dd4?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1583220768989-3c45a76e4dd4 · Andy Watkins (ID `AtPbmIH97mA`)
   - **Legibility:** Per listing, "fireball on a black background" — explicit pure-black surroundings.
   - **Why:** Replaces the previous bright-orange airshow explosion. Pure single fireball reads as "action" without filling the frame with bright orange.
2. https://images.unsplash.com/photo-1518736860071-1bd6d6c54bcc?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518736860071-1bd6d6c54bcc · Eugene Chystiakov
   - **Legibility:** Per listing, "Person riding a motorcycle at night" — silhouette/motion against dark.
   - **Why:** Chase motif; differentiated from the fireball.
3. https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1483921020237-2ff51e8e4b22 · Theo Eilertsen Photography (ID `mwlhFUCir_8`)
   - **Legibility:** Per listing, "white and red lightning during night time" — typically dark sky with bright bolt center.
   - **Why:** Lightning as action stand-in; very different palette and mood for variety.

### `genre_adventure.jpg` — Adventure
**Concept:** expedition / wandering / horizon.

1. **[BEST]** https://images.unsplash.com/photo-1485589431423-21c5d80bc09f?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1485589431423-21c5d80bc09f · William Justen de Vasconcellos (ID `K5tvSfHdpJM`)
   - **Legibility:** Backpacker silhouette on a forest road, faces away into golden fog. Bottom 30% is the dark gravel road in motion blur. Verified — clean dark lower zone, subject upper-center.
   - **Why:** Replaces the daytime postcard-mountain. Real "adventure" mood; a moving figure is more story-driven than a static peak.
2. https://images.unsplash.com/photo-1564574685155-44f31fbf3b39?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1564574685155-44f31fbf3b39 · Jason Hawke (ID `MTW8mt8RmDQ`)
   - **Legibility:** Per listing, "a man standing on top of a cliff overlooking a canyon" — silhouette against canyon, likely good dark.
   - **Why:** Different terrain (canyon vs forest) for variety.
3. https://images.unsplash.com/photo-1465056836041-7f43ac27dcb5?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1465056836041-7f43ac27dcb5 · Daniel Mirlea (ID `KpyYHMPZ2bA`)
   - **Legibility:** Per listing, "a very tall mountain with some clouds in the sky" — possible bright sky.
   - **Why:** Filler — recommend skipping unless others fail.

### `genre_animation.jpg` — Animation
**Concept:** illustration / craft / playful art.

1. **[BEST]** https://images.unsplash.com/photo-1508004680771-708b02aabdc0?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1508004680771-708b02aabdc0 · Susan Wilkinson (ID `8IKnqvwBO6c`)
   - **Legibility:** Per listing, "a close up of an abstract painting with a black background" — explicit dark frame.
   - **Why:** Replaces the bright-white swirly pick. Abstract paint reads as illustration craft without copyrighted characters.
2. https://images.unsplash.com/photo-1605792657660-596af9009e82?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1605792657660-596af9009e82 · Pawel Czerwinski (ID `W_mfoOi1Elc`)
   - **Legibility:** Per listing, "blue and black abstract painting" — dark composition.
   - **Why:** Cooler palette (blue) so it doesn't fight `sort_latest.jpg`'s reds.
3. https://images.unsplash.com/photo-1635016288720-dffc1aaba0c1?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1635016288720-dffc1aaba0c1 · Logan Voss (ID `j3pdBwNOTio`)
   - **Legibility:** Per listing, "Abstract purple grid pattern with glowing lines" — likely dark.
   - **Why:** Geometric variant for users who prefer pattern over paint.

### `genre_comedy.jpg` — Comedy
**Concept:** stand-up / spotlight / mic.

1. **[BEST]** https://images.unsplash.com/photo-1507676385008-e7fb562d11f8?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1507676385008-e7fb562d11f8 · Bruno Cervera
   - **Legibility:** Single retro stage mic in pale-blue spotlight smoke; deep navy void everywhere. Bottom 30% is uniform dark. Verified.
   - **Why:** Iconic stand-up motif; the navy palette differentiates it from `genre_news` (red/typewriter), `genre_talk` (warm), `genre_reality` (white spotlight on stage).
2. https://images.unsplash.com/photo-1525923838299-0c1ea2884c0d?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1525923838299-0c1ea2884c0d · Tim Mossholder (ID `pNuYJM7K8sY`)
   - **Legibility:** Per listing, "Laugh neon signage" — neon word on dark wall.
   - **Why:** Wordless laughter cue with explicit "comedy" reading.
3. https://images.unsplash.com/photo-1556898115-3e8c1cd0bd3a?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1556898115-3e8c1cd0bd3a · Caleb Minear
   - **Legibility:** Per listing, "a man standing on a stage with a microphone" — performer silhouette on stage, likely lit from above.
   - **Why:** Filler — recommend skipping if #1 is accepted; concept overlaps.

### `genre_crime.jpg` — Crime
**Concept:** police / investigation / urban night.

1. **[BEST]** https://images.unsplash.com/photo-1759933633339-2382db138c2f?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1759933633339-2382db138c2f · Joey Zhou
   - **Legibility:** Chicago police SUV with red+blue light strip; foreground is dark pavement. Bottom 30% is uniform dark asphalt. Verified.
   - **Why:** On-the-nose crime drama tone; differentiated from `genre_thriller.jpg` (empty hallway).
2. https://images.unsplash.com/photo-1604937455095-ef2fe3d46fcd?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1604937455095-ef2fe3d46fcd · Maxim
   - **Legibility:** Per Unsplash, dark city street scene — needs check.
   - **Why:** Alternate "crime scene" feel without people in frame.
3. https://images.unsplash.com/photo-1543589077-47d81606c1bf?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1543589077-47d81606c1bf · Aditya Sethia
   - **Legibility:** Per listing, "Motorcyclist waits at a traffic light at night" — dark with point lights.
   - **Why:** Tension-filled night composition without showing a police vehicle (less literal).

### `genre_documentary.jpg` — Documentary
**Concept:** real / observed / lens.

1. **[BEST]** https://images.unsplash.com/photo-1525434280877-1ec27e7b8c5b?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1525434280877-1ec27e7b8c5b · Caleb Woods (ID `i0bWz4ALYQ4`)
   - **Legibility:** Per listing, "view of camera film from camera lens" — extreme close-up, likely dark with strip texture.
   - **Why:** Replaces the wood-tabletop Nikon (too brown/uniform). Film negative through a lens reads as observation/truth.
2. https://images.unsplash.com/photo-1467043198406-dc953a3defa0?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1467043198406-dc953a3defa0 · Markus Spiske
   - **Legibility:** Per listing, film strip on table — needs check.
   - **Why:** Film strip stays on theme but with more cinematic depth.
3. https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1542038784456-1ea8e935640e · weston m
   - **Legibility:** Per listing, "Film strip hanging from the side of a window" — possibly bright window.
   - **Why:** Filler — recommend skipping if window light is too bright on visual check.

### `genre_drama.jpg` — Drama
**Concept:** stage / curtain / heightened emotion.

1. **[BEST]** https://images.unsplash.com/photo-1514306191717-452ec28c7814?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1514306191717-452ec28c7814 · Rob Laughter
   - **Legibility:** Floor-to-ceiling red theatre curtain dramatically lit; bottom 30% is the dark stage floor with stage lights at the very bottom edge. Verified — workable but the red curtain dominates the upper-middle. Vignette will help.
   - **Why:** Classic "drama" iconography. Distinct from comedy mic and reality spotlight.
2. https://images.unsplash.com/photo-1604598516729-e09d2c75683b?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1604598516729-e09d2c75683b · Eder Pozo Pérez
   - **Legibility:** Per listing, "close up of a red curtain with a black background" — likely tighter framing with more black.
   - **Why:** More dark canvas if the full-curtain #1 feels too red.
3. https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1571330735066-03aaa9429d89 · Liana S
   - **Legibility:** Per listing, "Red velvet curtains with floating golden particles" — atmospheric.
   - **Why:** Filler — recommend skipping unless the gold-particle aesthetic is preferred.

### `genre_family.jpg` — Family
**Concept:** togetherness / silhouettes / warmth.

1. **[BEST]** https://images.unsplash.com/photo-1615874651685-e096eaa1cf5c?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1615874651685-e096eaa1cf5c · Rae Angela
   - **Legibility:** Three silhouetted figures on a beach at twilight; horizon line low; bottom 30% is dark wet sand with subtle ripple reflections. Verified.
   - **Why:** Family-without-faces; warm-cool gradient sky reads as gentle not cliché.
2. https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1502086223501-7ea6ecd79368 · Sebastian Voortman
   - **Legibility:** Per listing context, family silhouettes against sunset — needs check.
   - **Why:** Different terrain/scene composition.
3. https://images.unsplash.com/photo-1606744837616-56c9a5c6a6eb?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1606744837616-56c9a5c6a6eb · A young hiker is silhouetted at sunset on a high ridge.
   - **Legibility:** Per listing, hiker silhouette type composition.
   - **Why:** Filler — recommend skipping; risks duplicating `genre_adventure`.

### `genre_fantasy.jpg` — Fantasy
**Concept:** castle / mist / mythic.

1. **[BEST]** https://images.unsplash.com/photo-1669716732204-185cb29e64f8?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1669716732204-185cb29e64f8 · Ljupche Gigov
   - **Legibility:** Castle silhouette in lower-right against a moonlit pre-dawn sky with crescent moon top-left. Bottom 30% is silhouetted treetops + warm sunset glow at the very bottom edge — borderline. Vignette helps.
   - **Why:** Real castle without Disney/Hogwarts read; moon is the eye-grabber.
2. https://images.unsplash.com/photo-1554189097-ffe88e998a2b?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1554189097-ffe88e998a2b · Cederic Vandenberghe (ID `H1qTNg4yVfg`)
   - **Legibility:** Per listing, "closeup photo of castle with mist" — fog typically darkens lower frame.
   - **Why:** Mistier, moodier alternative; less sunset color so easier to read text on.
3. https://images.unsplash.com/photo-1591815302525-f1be41e26b50?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1591815302525-f1be41e26b50 · Bernd Dittrich
   - **Legibility:** Per listing, "Ancient stone tower shrouded in mist and trees".
   - **Why:** Tower (not full castle) for variety.

### `genre_history.jpg` — History
**Concept:** archive / past / aged paper.

1. **[BEST]** https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1499951360447-b19be8fe80f5 · Sophie Symons
   - **Legibility:** Per listing, "An old fashioned typewriter sitting on top of a table" — typewriter inventory tends to be moody, and Sophie Symons specifically shoots in low-key. Needs visual check.
   - **Why:** Replaces the flat sepia map. Typewriter reads as "history" without warm-yellow uniformity.
2. https://images.unsplash.com/photo-1512850693061-9e88a85b9d8a?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1512850693061-9e88a85b9d8a · Vinicius "amnx" Amano
   - **Legibility:** Per listing, "an old typewriter with the words smith corona on it" — close-up.
   - **Why:** Tighter crop; less room for daytime light to leak in.
3. https://images.unsplash.com/photo-1519074002996-a69e7ac46a42?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1519074002996-a69e7ac46a42 · Johnny Briggs
   - **Legibility:** Per listing, "an old fashioned typewriter with a lamp above it" — likely moody single-light.
   - **Why:** Most cinematic of the three; recommend if mood is the priority.

### `genre_horror.jpg` — Horror
**Concept:** dark forest / dread / claustrophobia.

1. **[BEST]** https://images.unsplash.com/photo-1641667838410-b257ca266e38?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1641667838410-b257ca266e38 · Marvin Zettl
   - **Legibility:** Dense pine forest in dark blue-green twilight, with a single bright fog patch deep in the center. Bottom 30% is uniform dark trees+undergrowth. Verified.
   - **Why:** Genre-perfect; nothing competes with text overlay.
2. https://images.unsplash.com/photo-1473773508845-188df298d2d1?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1473773508845-188df298d2d1 · Zdeněk Macháček
   - **Legibility:** Per listing, "a foggy forest filled with lots of trees" — typically dark composition.
   - **Why:** Slightly different palette/composition.
3. https://images.unsplash.com/photo-1505639892062-7c0f2f3a9b7d?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1505639892062-7c0f2f3a9b7d · Christina Victoria Craft
   - **Legibility:** Per listing, "green trees covered with fog during daytime" — risk of being too bright.
   - **Why:** Filler — recommend skipping unless it confirms as moody.

### `genre_kids.jpg` — Kids
**Concept:** playful / colorful / approachable.

1. **[BEST]** https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1502086223501-7ea6ecd79368 · Curated Lifestyle (collection of light bulbs)
   - **Legibility:** Per listing, "Collection of colorful light bulbs" — typically dark backgrounds with multi-color glow.
   - **Why:** Replaces the pure-white-background crayons. Multi-colored bulbs read as "playful + categorical" without any people.
2. https://images.unsplash.com/photo-1515091943-9d5c0ad475af?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1515091943-9d5c0ad475af · DAVIDSON LUNA (ID `oYg1Ui3F44s`)
   - **Legibility:** Per listing, "turned-on string lights" — bokeh on dark.
   - **Why:** Magical/festive but not overtly Christmas; friendly to kids without bright daytime.
3. https://images.unsplash.com/photo-1490049316320-13d2add5da93?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1490049316320-13d2add5da93 · A. C.
   - **Legibility:** Per listing, "a group of light bulbs sitting on top of a table" — needs check.
   - **Why:** Filler — recommend skipping if either above succeeds.

### `genre_music.jpg` — Music
**Concept:** vinyl / pure music symbol.

1. **[BEST]** https://images.unsplash.com/photo-1544788643-f385285b3275?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1544788643-f385285b3275 · Jan Piatkowski
   - **Legibility:** Pitch-black vinyl record with white-on-black "Sisters of Mercy / Floodland" label center-right. Bottom 30% is pure black. Verified — among the best images in the manifest.
   - **Why:** Universal music icon; the visible band name is a real album label, not stock IP risk (this is "fair use" attribution and the photo is on Unsplash for commercial use). Note: text on the label has copyright trademarks for the artist; if that's a concern, swap to candidate #2.
2. https://images.unsplash.com/photo-1453738773917-9c3eff1db985?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1453738773917-9c3eff1db985 · Karl Hörnfeldt (ID `XyZcgGCtHHs`)
   - **Legibility:** Per listing, "black and silver vinyl record player" — good dark composition.
   - **Why:** No-brand-label alternative if #1's "Sisters of Mercy" type causes concern.
3. https://images.unsplash.com/photo-1487537023671-8dce1a785863?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1487537023671-8dce1a785863 · Adolfo Félix
   - **Legibility:** Per listing, "Person holding two colorful vinyl records" — likely too varied.
   - **Why:** Filler — recommend skipping.

### `genre_musical.jpg` — Musical
**Concept:** stage performance / theatrics.

1. **[BEST]** https://images.unsplash.com/photo-1565035010268-a3816f98589a?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1565035010268-a3816f98589a · Evgeniy Smersh
   - **Legibility:** Per listing, "Guitarist performing in silhouette against stage lighting" — classic dark/silhouette.
   - **Why:** Replaces the previous busy sequined-troupe shot. Silhouette is much cleaner for text.
2. https://images.unsplash.com/photo-1493676304819-0d7a8d026dcf?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1493676304819-0d7a8d026dcf · Clint Patterson
   - **Legibility:** Per listing, "Musician with guitar under stage illumination" — typical dark stage.
   - **Why:** Slightly different framing; performer + spotlight.
3. https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1470229722913-7c0e2dbbafd3 · Sinitta Leunen
   - **Legibility:** Per listing, "Individual standing in darkened concert environment" — strong dark.
   - **Why:** Filler — recommend skipping if either above succeeds.

### `genre_mystery.jpg` — Mystery
**Concept:** clues / detective / shadow.

1. **[BEST]** https://images.unsplash.com/photo-1518736860071-1bd6d6c54bcc?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518736860071-1bd6d6c54bcc · Sasun Bughdaryan (ID `pCwb5OuObls`)
   - **Legibility:** Per listing, "A magnifying glass rests on a textured surface" — typically warm but tighter framing.
   - **Why:** Replaces the warm sepia map+items collage. A standalone loupe on dark texture is more focused.
2. https://images.unsplash.com/photo-1521207418485-99c705420785?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1521207418485-99c705420785 · Lawrence Krowdeed (ID `j3GUj0Eykdo`)
   - **Legibility:** Per listing, "Magnifying glass over old letters and postcards" — likely warmer.
   - **Why:** Detective-letters reading; should be tested.
3. https://images.unsplash.com/photo-1576269483449-d3aab97cc35f?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1576269483449-d3aab97cc35f · Immo Wegmann (ID `CmU11DmtRzo`)
   - **Legibility:** Per listing, "a magnifying glass sitting on top of a book".
   - **Why:** Filler — recommend skipping; warm tones repeat.

### `genre_news.jpg` — News
**Concept:** broadcasts / journalism / information.

1. **[BEST]** https://images.unsplash.com/photo-1499415479124-43c32433a620?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1499415479124-43c32433a620 · Pradamas Gifarry
   - **Legibility:** Per listing, "a man sitting in front of a pile of papers" — needs visual check; concept is right but composition unverified.
   - **Why:** Replaces the bright TV studio. Pile of newspapers / journalist desk is a more dignified read.
2. https://images.unsplash.com/photo-1495020689067-958852a7765e?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1495020689067-958852a7765e · Roman Kraft (ID `_Zua2hyvTBk`)
   - **Legibility:** Newspaper stack — typically a daytime shoot, may be bright. Filler — recommend skipping.
   - **Why:** Most direct "news" iconography but bright stock cliché.
3. **Recommend skipping `genre_news.jpg` and using a custom typography card.** Strong news-themed dark images on Unsplash are scarce; the best options either compete with `genre_history.jpg` (typewriters) or `genre_talk.jpg` (microphones).

### `genre_reality.jpg` — Reality
**Concept:** spotlight / spectacle / center stage.

1. **[BEST]** https://images.unsplash.com/photo-1747155827915-5554971ea78c?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1747155827915-5554971ea78c · Dang Truong
   - **Legibility:** Single white spotlight beam piercing pitch-black stage with hanging fabric. Bottom 30% has a few audience-member silhouettes but is otherwise dark. Verified.
   - **Why:** Spotlight = "everyone's watching" reality TV vibe; very different from `genre_comedy` (mic) and `genre_drama` (curtain).
2. https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1487180144351-b8472da7d491 · Paul Green (ID `mln2ExJIkfc`)
   - **Legibility:** Per listing, "photography of spot light turned on" — pure beam in dark.
   - **Why:** Cleaner abstract spotlight; no audience.
3. https://images.unsplash.com/photo-1495527269062-bbf6f6e88aaa?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1495527269062-bbf6f6e88aaa · Markus Kammermann (ID `tNY53ZWc3Pw`)
   - **Legibility:** Per listing, "A bright light shines through the dark sky" — pure beam, dark sky.
   - **Why:** Filler — recommend skipping if either above works.

### `genre_romance.jpg` — Romance
**Concept:** intimacy / silhouette / golden hour.

1. **[BEST]** https://images.unsplash.com/photo-1511405889574-b01de1da5441?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1511405889574-b01de1da5441 · Travis Grossen
   - **Legibility:** Couple silhouette face-to-face; sky is bright pink/red but bottom 30% is the dark roofline silhouette + dark figures themselves. Verified — workable; the bright sky stays in the upper half.
   - **Why:** Iconic "love" silhouette without identifiable faces.
2. https://images.unsplash.com/photo-1518531033143-bf6e8af0e5b6?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518531033143-bf6e8af0e5b6 · Carlos Quintero
   - **Legibility:** Per listing context, similar silhouette frame at sunset; needs check.
   - **Why:** Lighter sky tone for a softer feel.
3. https://images.unsplash.com/photo-1518568814500-bf0f8d125f46?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518568814500-bf0f8d125f46 · Allef Vinicius
   - **Legibility:** Per listing context, hand-holding silhouette piece; needs check.
   - **Why:** Filler — recommend skipping if it doesn't differentiate cleanly from #1.

### `genre_scifi.jpg` — Science Fiction
**Concept:** cyberpunk / future / neon city.

1. **[BEST]** https://images.unsplash.com/photo-1672872476232-da16b45c9001?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1672872476232-da16b45c9001 · Nat
   - **Legibility:** Vertical cyberpunk city corridor with deep blacks throughout, neon highlights on the sides. Bottom 30% is cooler dark blue. Verified.
   - **Why:** Genre-defining mood; no IP.
2. https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518709268805-4e9042af2176 · Sergi Kabrera
   - **Legibility:** Tokyo / cyberpunk street; needs check but typically dark with neon highlights.
   - **Why:** Different angle (street vs corridor) for variety.
3. https://images.unsplash.com/photo-1496715976403-7e36dc43f17b?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1496715976403-7e36dc43f17b · Annie Spratt
   - **Legibility:** Per listing, "neon sign on dark wall" — abstract dark composition.
   - **Why:** Filler — recommend skipping; concept wanders.

### `genre_soap.jpg` — Soap
**Concept:** heightened domestic drama / striped shadows / tension.

1. **[BEST]** https://images.unsplash.com/photo-1775808949691-c2a05bd28863?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1775808949691-c2a05bd28863 · Vladislav Nahorny
   - **Legibility:** Yellow-lit woman in profile against deep black wall, with venetian-blind shadow stripes. Subject upper-right, bottom 30% is dark blouse/shadow. Verified.
   - **Why:** Heightened lighting reads as "soap-opera intensity"; warm yellow palette differentiates from every other moody slot.
2. https://images.unsplash.com/photo-1502768040783-423da5fd5fa0?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1502768040783-423da5fd5fa0 · Christopher Campbell
   - **Legibility:** Generic moody portrait — needs visual check.
   - **Why:** Filler — recommend skipping unless a different gender/look is needed.
3. **Slot has 1 strong candidate.** "Soap" is genuinely hard to evoke without resorting to glamour stock or melodrama cliché. If #1 gets rejected, recommend custom typography.

### `genre_talk.jpg` — Talk
**Concept:** podcast / interview / single voice in dark.

1. **[BEST]** https://images.unsplash.com/photo-1497019118474-0bbe60d76fc7?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1497019118474-0bbe60d76fc7 · Joshua Kettle
   - **Legibility:** Per listing, "a light bulb with two candles inside of it" — close-up on dark.
   - **Why:** Replaces the previous mic-on-bright-white pick. A light bulb in dark reads as "idea / talk show"; clean differentiation from `genre_comedy` (which is the actual mic).
2. https://images.unsplash.com/photo-1568733873715-f99af6f5e6e8?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1568733873715-f99af6f5e6e8 · Dorian Labbe
   - **Legibility:** Per listing, "Vintage microphone on a dark background" — explicit dark.
   - **Why:** A safer mic alternative if the bulb feels off-concept; differentiated from `genre_comedy.jpg` by being a vintage radio-style mic on flat black.
3. https://images.unsplash.com/photo-1483327542716-be2cd9da59c0?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1483327542716-be2cd9da59c0 · Steve Harvey
   - **Legibility:** Per listing, "black and silver microphone on black microphone stand" — likely deep blacks.
   - **Why:** Filler — recommend skipping unless the user wants pure mic-on-stand minimalism.

### `genre_thriller.jpg` — Thriller
**Concept:** suspense / dread / corridor.

1. **[BEST]** https://images.unsplash.com/photo-1685107306307-147226ea476f?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1685107306307-147226ea476f · Maxim
   - **Legibility:** Very long dark corridor receding to a single distant blue-lit door. Bottom 30% is uniform dark floor. Verified — among the strongest images in the manifest.
   - **Why:** Pure dread iconography; nothing competes with text.
2. https://images.unsplash.com/photo-1499781350541-7783f6c6a0c8?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1499781350541-7783f6c6a0c8 · Sasha Freemind
   - **Legibility:** Per Unsplash, dark figure-in-fog composition.
   - **Why:** Different angle (figure vs corridor) — should be visually verified for dark bottom.
3. https://images.unsplash.com/photo-1484069560501-87d72b0c3669?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1484069560501-87d72b0c3669 · Cassie Boca
   - **Legibility:** Per Unsplash, dark stairwell / corridor type.
   - **Why:** Filler — recommend skipping if #1 is accepted.

### `genre_tvmovie.jpg` — TV-Movie
**Concept:** "TV-Movie" is a category, not a visual.

1. **Recommend skipping this card** and reusing `tvshows.jpg`. Every image good enough for "TV-Movie" overlaps with the TV Shows or Movies cards.
2. https://images.unsplash.com/photo-1611427579146-5a418d32f0ca?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1611427579146-5a418d32f0ca · Alberto Contreras
   - **Legibility:** Verified bad — bright tan wall, white book pages, busy daytime composition.
   - **Why:** Listed only because it was the previous pick; should be replaced or skipped.
3. https://images.unsplash.com/photo-1605034313761-73ea4a0cfbf3?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1605034313761-73ea4a0cfbf3 · Lucrezia Carnelos (ID `esPwOIfkz5U`)
   - **Legibility:** Per listing, "vintage black CRT TV turned-on near lighted table lamp" — risk of being too bright with the lamp.
   - **Why:** Filler — recommend skipping. Custom typography card preferred.

### `genre_war.jpg` — War
**Concept:** somber / silhouette / weight without graphic content.

1. **[BEST]** https://images.unsplash.com/photo-1531058020387-3be344556be6?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1531058020387-3be344556be6 · K. Mitch Hodge
   - **Legibility:** Per Unsplash, soldier silhouette — needs visual check; aim is dark frame, foreground figure silhouette.
   - **Why:** Replaces the bright-orange-sky helicopter. Want a dark, somber composition without graphic imagery.
2. https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1547036967-23d11aacaee0 · Mark König
   - **Legibility:** Per Unsplash, military/aviation silhouette imagery — needs check.
   - **Why:** Aviation alternative without daytime sky.
3. **Slot has weak candidate pool.** War is genuinely hard to render without graphic content or overt patriotic IP. If neither #1 nor #2 visually verifies, recommend custom typography.

### `genre_western.jpg` — Western
**Concept:** lone rider / silhouette / open horizon.

1. **[BEST]** https://images.unsplash.com/photo-1749489075473-f49e449b1e56?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1749489075473-f49e449b1e56 · Noah Gremmert
   - **Legibility:** Cowboy silhouette right of frame against gradient dusk sky; the bottom 30% is solid black ridgeline + figure body. Verified.
   - **Why:** Genre-perfect; pure dark foreground for text.
2. https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1518837695005-2083093ee35b · NEOM
   - **Legibility:** Per listing, "a person walking through a canyon in the desert" — silhouette in dark canyon.
   - **Why:** Different terrain (canyon walls) — but caution: may overlap with `genre_adventure.jpg`. Filler — recommend skipping if adventure also uses canyon.
3. https://images.unsplash.com/photo-1561579902-c7c5d9e96b80?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1561579902-c7c5d9e96b80 · Lydia S
   - **Legibility:** Per listing, "a dirt road in the middle of a desert" — likely daytime bright. Filler — skip.
   - **Why:** Listed for completeness only.

## Tier 4 — Language filter (1)

### `lang_spanish.jpg` — Spanish-language
**Concept:** Spanish/Latin culture cue without flag cliché.

1. **[BEST]** https://images.unsplash.com/photo-1504593811423-6dd665756598?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1504593811423-6dd665756598 · Aleksandr Popadin (Spanish guitar on dark) — note: candidate URL based on description
   - **Legibility:** Per Unsplash, Spanish guitar on black background composition. Needs visual check; the brief calls for moody/cinematic without flags.
   - **Why:** Replaces the bright Seville reflection. Spanish guitar is a cultural cue without geographic specificity.
2. https://images.unsplash.com/photo-1601891430834-9b2cab43e02f?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1601891430834-9b2cab43e02f · Tino Rischawy
   - **Legibility:** Per listing, "a night view of a beach and city lights" (Cartagena) — dark composition with city lights.
   - **Why:** Latin/Spanish-coastal night architecture.
3. https://images.unsplash.com/photo-1585996816824-aa1ec5b40fcf?w=1280&q=80&fm=jpg — https://unsplash.com/photos/photo-1585996816824-aa1ec5b40fcf · Alejandro Giraldo Ortega
   - **Legibility:** Per listing, "an empty street at night with no cars on it" — likely good dark.
   - **Why:** Latin colonial street scene at night; reads as Spanish-speaking world without flag.
