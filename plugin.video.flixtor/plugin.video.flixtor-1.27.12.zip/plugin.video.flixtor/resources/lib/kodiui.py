"""Small Kodi UI-setting helpers shared by the plug-in and resident service."""

import json


PARENT_ITEMS_SETTING = "filelists.showparentdiritems"


def set_parent_folder_items(visible):
    """Set Kodi's parent-folder preference only when its value must change."""
    import xbmc

    visible = bool(visible)
    try:
        get_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.GetSettingValue",
            "params": {"setting": PARENT_ITEMS_SETTING},
        })
        current = json.loads(xbmc.executeJSONRPC(get_request))
        if current.get("result", {}).get("value") is visible:
            return False

        set_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.SetSettingValue",
            "params": {
                "setting": PARENT_ITEMS_SETTING,
                "value": visible,
            },
        })
        result = json.loads(xbmc.executeJSONRPC(set_request))
        if result.get("result") != "OK":
            raise RuntimeError("unexpected JSON-RPC response: %r" % result)
        xbmc.log(
            "FLIXTOR: Kodi parent-folder cards %s"
            % ("restored" if visible else "hidden at Flixtor root"),
            xbmc.LOGINFO,
        )
        return True
    except Exception as exc:
        xbmc.log(
            "FLIXTOR: could not update parent-folder cards: %s" % exc,
            xbmc.LOGINFO,
        )
        return False
