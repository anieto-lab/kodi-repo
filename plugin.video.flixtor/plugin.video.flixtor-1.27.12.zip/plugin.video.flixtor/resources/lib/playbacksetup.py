"""Safe Kodi-wide cache tuning for Flixtor playback.

Kodi 21 exposes its file cache controls through the normal Settings JSON-RPC
API.  Keep the mutation logic here small, capability-driven, and transactional
so unsupported Kodi versions or a failed second write never leave a device in
a partially configured state.
"""

import json


MEMORY_SETTING = "filecache.memorysize"
READ_FACTOR_SETTING = "filecache.readfactor"
SETTING_ORDER = (MEMORY_SETTING, READ_FACTOR_SETTING)
RECOMMENDED_VALUES = {
    MEMORY_SETTING: 64,
    READ_FACTOR_SETTING: 0,
}


class KodiSettingsError(RuntimeError):
    """Raised when Kodi cannot read, change, or verify a cache setting."""


def _execute(method, params, execute_json_rpc=None):
    if execute_json_rpc is None:
        import xbmc
        execute_json_rpc = xbmc.executeJSONRPC

    request = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params,
    })
    try:
        response = json.loads(execute_json_rpc(request))
    except Exception as exc:
        raise KodiSettingsError("Kodi settings request failed: %s" % exc)
    if response.get("error"):
        error = response["error"]
        raise KodiSettingsError(
            "Kodi does not expose this cache setting (%s)" %
            error.get("message", "unknown error")
        )
    if "result" not in response:
        raise KodiSettingsError("Kodi returned no settings result")
    return response["result"]


def get_setting(setting_id, execute_json_rpc=None):
    result = _execute(
        "Settings.GetSettingValue",
        {"setting": setting_id},
        execute_json_rpc,
    )
    if not isinstance(result, dict) or "value" not in result:
        raise KodiSettingsError("Kodi returned an invalid value for %s" % setting_id)
    value = result["value"]
    if isinstance(value, bool) or not isinstance(value, int):
        raise KodiSettingsError("Kodi returned an invalid type for %s" % setting_id)
    return value


def set_setting(setting_id, value, execute_json_rpc=None):
    result = _execute(
        "Settings.SetSettingValue",
        {"setting": setting_id, "value": int(value)},
        execute_json_rpc,
    )
    # Kodi's generated schema describes a boolean, while current Kodi builds
    # return the standard JSON-RPC mutation token "OK".  Accept both forms.
    if result not in (True, "OK"):
        raise KodiSettingsError("Kodi rejected the value for %s" % setting_id)


def read_cache_settings(execute_json_rpc=None):
    return {
        setting_id: get_setting(setting_id, execute_json_rpc)
        for setting_id in SETTING_ORDER
    }


def cache_is_optimized(values):
    return all(values.get(setting_id) == target
               for setting_id, target in RECOMMENDED_VALUES.items())


def apply_cache_values(values, execute_json_rpc=None):
    """Apply and verify both cache values, rolling back on any failure."""
    targets = {setting_id: int(values[setting_id]) for setting_id in SETTING_ORDER}
    before = read_cache_settings(execute_json_rpc)
    changed = []
    try:
        for setting_id in SETTING_ORDER:
            if before[setting_id] == targets[setting_id]:
                continue
            set_setting(setting_id, targets[setting_id], execute_json_rpc)
            changed.append(setting_id)

        after = read_cache_settings(execute_json_rpc)
        if any(after[setting_id] != targets[setting_id]
               for setting_id in SETTING_ORDER):
            raise KodiSettingsError("Kodi did not retain the requested cache values")
    except Exception as exc:
        rollback_errors = []
        for setting_id in reversed(changed):
            try:
                set_setting(setting_id, before[setting_id], execute_json_rpc)
            except Exception as rollback_exc:
                rollback_errors.append(str(rollback_exc))
        if rollback_errors:
            raise KodiSettingsError(
                "%s; rollback also failed: %s" %
                (exc, "; ".join(rollback_errors))
            )
        if isinstance(exc, KodiSettingsError):
            raise
        raise KodiSettingsError(str(exc))

    return {
        "before": before,
        "after": after,
        "changed": bool(changed),
    }


def apply_recommended(execute_json_rpc=None):
    return apply_cache_values(RECOMMENDED_VALUES, execute_json_rpc)


def memory_label(value):
    return "%d MB" % int(value)


def read_factor_label(value):
    value = int(value)
    if value == 0:
        return "Adaptive"
    return "%gx" % (value / 100.0)


def summary_lines(values):
    return [
        "Memory: %s" % memory_label(values[MEMORY_SETTING]),
        "Read rate: %s" % read_factor_label(values[READ_FACTOR_SETTING]),
    ]
