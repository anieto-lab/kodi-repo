"""Local-only protocol for the optional Fire TV voice-keyboard companion."""

import json
import os
import re
import socket
import time
import urllib.parse
import urllib.request


PROTOCOL_VERSION = 1
PACKAGE_NAME = "com.anietolab.flixtor.voice"
INSTALL_URL = "https://anieto-lab.github.io/kodi-repo/firetv-voice/"
METADATA_URL = INSTALL_URL + "latest.json"
DOWNLOADER_PACKAGE = "com.esaba.downloader"
DOWNLOADER_STORE_URI = (
    "amzn://apps/android?p=" + DOWNLOADER_PACKAGE
)
AMAZON_APPSTORE_PACKAGE = "com.amazon.venezia"
MAX_QUERY_CHARS = 200
MAX_MESSAGE_BYTES = 4096
MAX_METADATA_BYTES = 16384
_VERSION_RE = re.compile(r"[0-9]+(?:\.[0-9]+){1,3}")
_SHA256_RE = re.compile(r"[0-9a-f]{64}")
_REPOSITORY_HOST = "anieto-lab.github.io"
_USER_AGENT = "Flixtor-Kodi-Voice-Setup/1"


class ReleaseMetadataError(ValueError):
    """The published companion release metadata is missing or unsafe."""


def _trusted_repository_url(url):
    try:
        parsed = urllib.parse.urlsplit(str(url))
        port = parsed.port
    except (TypeError, ValueError):
        return False
    return (
        parsed.scheme == "https"
        and parsed.hostname == _REPOSITORY_HOST
        and port in (None, 443)
        and parsed.username is None
        and parsed.password is None
        and not parsed.fragment
        and parsed.path.startswith("/kodi-repo/firetv-voice/")
    )


def parse_release_metadata(payload, metadata_url=METADATA_URL):
    """Validate repository metadata and return an immutable APK URL."""
    if isinstance(payload, bytes):
        if len(payload) > MAX_METADATA_BYTES:
            raise ReleaseMetadataError("release metadata is too large")
        try:
            payload = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ReleaseMetadataError("release metadata is not UTF-8") from exc
    if not isinstance(payload, str) or len(payload.encode("utf-8")) > MAX_METADATA_BYTES:
        raise ReleaseMetadataError("release metadata is too large")
    try:
        metadata = json.loads(payload)
    except (TypeError, ValueError) as exc:
        raise ReleaseMetadataError("release metadata is not valid JSON") from exc
    if not isinstance(metadata, dict):
        raise ReleaseMetadataError("release metadata is not an object")

    version = metadata.get("version")
    if not isinstance(version, str) or not _VERSION_RE.fullmatch(version):
        raise ReleaseMetadataError("release version is invalid")
    if metadata.get("package") != PACKAGE_NAME:
        raise ReleaseMetadataError("release package name is invalid")

    apk = metadata.get("apk")
    expected_apk = "flixtor-voice-%s.apk" % version
    if apk != expected_apk:
        raise ReleaseMetadataError("release APK name is invalid")

    sha256 = metadata.get("sha256")
    if not isinstance(sha256, str) or not _SHA256_RE.fullmatch(sha256):
        raise ReleaseMetadataError("release checksum is invalid")

    version_code = metadata.get("versionCode")
    if version_code is not None and (
        isinstance(version_code, bool)
        or not isinstance(version_code, int)
        or version_code < 1
    ):
        raise ReleaseMetadataError("release version code is invalid")

    size_bytes = metadata.get("bytes")
    if size_bytes is not None and (
        isinstance(size_bytes, bool)
        or not isinstance(size_bytes, int)
        or size_bytes < 1024
        or size_bytes > 20 * 1024 * 1024
    ):
        raise ReleaseMetadataError("release size is invalid")

    if not _trusted_repository_url(metadata_url):
        raise ReleaseMetadataError("metadata URL is not trusted")
    download_url = urllib.parse.urljoin(metadata_url, apk)
    if not _trusted_repository_url(download_url):
        raise ReleaseMetadataError("release download URL is not trusted")

    return {
        "apk": apk,
        "bytes": size_bytes,
        "download_url": download_url,
        "package": PACKAGE_NAME,
        "sha256": sha256,
        "version": version,
        "version_code": version_code,
    }


def fetch_release_metadata(opener=urllib.request.urlopen, timeout=8.0):
    """Fetch and validate the small public companion-release manifest."""
    request = urllib.request.Request(
        METADATA_URL,
        headers={
            "Accept": "application/json",
            "User-Agent": _USER_AGENT,
        },
    )
    with opener(request, timeout=float(timeout)) as response:
        final_url = response.geturl()
        if not _trusted_repository_url(final_url):
            raise ReleaseMetadataError("metadata redirected outside the repository")
        content_length = response.headers.get("Content-Length")
        if content_length:
            try:
                if int(content_length) > MAX_METADATA_BYTES:
                    raise ReleaseMetadataError("release metadata is too large")
            except ValueError as exc:
                raise ReleaseMetadataError(
                    "release metadata length is invalid"
                ) from exc
        payload = response.read(MAX_METADATA_BYTES + 1)
    if len(payload) > MAX_METADATA_BYTES:
        raise ReleaseMetadataError("release metadata is too large")
    return parse_release_metadata(payload, final_url)


def build_downloader_uri(download_url):
    """Return Downloader's documented deep link for a trusted release APK."""
    if not _trusted_repository_url(download_url):
        raise ReleaseMetadataError("release download URL is not trusted")
    if len(download_url) > 2048:
        raise ReleaseMetadataError("release download URL is too long")
    return "downloader://" + download_url


def version_key(value):
    """Return a comparable numeric key for versions such as 0.1.1-debug."""
    match = re.match(r"^([0-9]+(?:\.[0-9]+){1,3})", str(value or ""))
    if not match:
        return ()
    parts = tuple(int(part) for part in match.group(1).split("."))
    return parts + (0,) * (4 - len(parts))


def _token():
    """Return a URL-safe, single-use authentication token."""
    return urllib.parse.quote_from_bytes(os.urandom(24), safe="")


def build_launch_uri(port, token, mode):
    query = urllib.parse.urlencode({
        "port": int(port),
        "token": token,
        "protocol": PROTOCOL_VERSION,
        "mode": mode,
    })
    return "flixtorvoice://input?%s" % query


def _remaining(deadline):
    return max(0.0, deadline - time.monotonic())


class _MessageReader:
    """Preserve data after a newline so coalesced replies are never lost."""

    def __init__(self, connection):
        self.connection = connection
        self.buffer = bytearray()

    def read(self, deadline, stop_requested=None):
        while _remaining(deadline) > 0:
            newline = self.buffer.find(b"\n")
            if newline >= 0:
                if newline > MAX_MESSAGE_BYTES:
                    return None, "message too large"
                raw = bytes(self.buffer[:newline])
                del self.buffer[:newline + 1]
                try:
                    message = json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, ValueError):
                    return None, "invalid JSON"
                if not isinstance(message, dict):
                    return None, "message is not an object"
                return message, ""
            if len(self.buffer) > MAX_MESSAGE_BYTES:
                return None, "message too large"
            if stop_requested and stop_requested():
                return None, "aborted"
            self.connection.settimeout(min(0.25, _remaining(deadline)))
            try:
                chunk = self.connection.recv(1024)
            except socket.timeout:
                continue
            except OSError as exc:
                return None, "socket error: %s" % exc
            if not chunk:
                return None, "connection closed"
            self.buffer.extend(chunk)
        return None, "timeout"


def _result(status, detail="", query="", version_name="", version_code=0):
    return {
        "status": status,
        "detail": detail,
        "query": query,
        "version_name": version_name,
        "version_code": version_code,
    }


def request_input(
    launcher,
    mode="search",
    accept_timeout=3.0,
    response_timeout=180.0,
    stop_requested=None,
):
    """Launch the helper and receive one authenticated result over loopback.

    ``launcher`` is called with a ``flixtorvoice://`` URI after the listener is
    ready. The companion first sends ``hello`` and then ``result``, ``cancel``,
    or ``ready``. No server is exposed beyond this single request.
    """
    if mode not in {"search", "probe"}:
        raise ValueError("unsupported bridge mode")

    token = _token()
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("127.0.0.1", 0))
        listener.listen(2)
        port = listener.getsockname()[1]
        uri = build_launch_uri(port, token, mode)
        try:
            launcher(uri)
        except Exception as exc:
            return _result("unavailable", "launch failed: %s" % exc)

        accept_deadline = time.monotonic() + max(0.1, float(accept_timeout))
        connection = None
        hello = None
        reader = None
        while _remaining(accept_deadline) > 0:
            if stop_requested and stop_requested():
                return _result("cancel", "aborted")
            listener.settimeout(min(0.25, _remaining(accept_deadline)))
            try:
                candidate, _address = listener.accept()
            except socket.timeout:
                continue
            except OSError as exc:
                return _result("unavailable", "accept failed: %s" % exc)
            candidate.settimeout(0.25)
            candidate_reader = _MessageReader(candidate)
            candidate_hello, error = candidate_reader.read(
                accept_deadline, stop_requested
            )
            if (
                not error
                and candidate_hello.get("type") == "hello"
                and candidate_hello.get("token") == token
                and candidate_hello.get("protocol") == PROTOCOL_VERSION
            ):
                connection = candidate
                hello = candidate_hello
                reader = candidate_reader
                break
            try:
                candidate.close()
            except OSError:
                pass

        if connection is None:
            return _result("unavailable", "companion did not acknowledge")

        version_name = str(hello.get("versionName") or "")
        try:
            version_code = int(hello.get("versionCode") or 0)
        except (TypeError, ValueError):
            version_code = 0
        try:
            response_deadline = time.monotonic() + max(
                0.1, float(response_timeout)
            )
            message, error = reader.read(response_deadline, stop_requested)
        finally:
            try:
                connection.close()
            except OSError:
                pass

        if error:
            if error == "aborted":
                return _result("cancel", error, version_name=version_name,
                               version_code=version_code)
            return _result("unavailable", error, version_name=version_name,
                           version_code=version_code)

        message_type = message.get("type")
        if message.get("token") != token:
            return _result("unavailable", "response token mismatch",
                           version_name=version_name, version_code=version_code)
        if mode == "probe" and message_type == "ready":
            return _result("ready", version_name=version_name,
                           version_code=version_code)
        if message_type == "cancel":
            return _result("cancel", version_name=version_name,
                           version_code=version_code)
        if mode == "search" and message_type == "result":
            query = message.get("text")
            if not isinstance(query, str):
                return _result("unavailable", "result text is not a string",
                               version_name=version_name,
                               version_code=version_code)
            query = query.strip()
            if not query:
                return _result("cancel", version_name=version_name,
                               version_code=version_code)
            if len(query) > MAX_QUERY_CHARS:
                return _result("unavailable", "result text is too long",
                               version_name=version_name,
                               version_code=version_code)
            return _result("query", query=query, version_name=version_name,
                           version_code=version_code)
        return _result("unavailable", "unexpected companion response",
                       version_name=version_name, version_code=version_code)
    finally:
        try:
            listener.close()
        except OSError:
            pass
