"""Pure subtitle conversion and stream-selection helpers."""

import re


_VTT_TIMING = re.compile(
    r"^\s*((?:\d{1,3}:)?\d{2}:\d{2}[.,]\d{3})\s+-->\s+"
    r"((?:\d{1,3}:)?\d{2}:\d{2}[.,]\d{3})(?:\s+.*)?$"
)

_LANGUAGE_CODES = {
    "english": ("eng", "en"),
    "spanish": ("spa", "es"),
    "french": ("fre", "fr"),
    "german": ("ger", "de"),
    "portuguese": ("por", "pt"),
    "italian": ("ita", "it"),
    "arabic": ("ara", "ar"),
    "russian": ("rus", "ru"),
    "japanese": ("jpn", "ja"),
    "korean": ("kor", "ko"),
    "chinese": ("chi", "zh"),
}


def _srt_timestamp(value):
    value = value.replace(".", ",")
    if value.count(":") == 1:
        value = "00:" + value
    return value


def webvtt_to_srt(data):
    """Convert a complete WebVTT document to SRT text.

    Cue identifiers and WebVTT positioning settings are intentionally omitted;
    cue text and timing are preserved. Returns an empty string when no valid
    cues are present so callers can retain the original VTT as a fallback.
    """
    if isinstance(data, bytes):
        text = data.decode("utf-8-sig", "replace")
    else:
        text = str(data or "").lstrip("\ufeff")
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    cues = []
    for block in re.split(r"\n\s*\n", text):
        lines = [line.rstrip() for line in block.splitlines()]
        if not lines:
            continue
        first = lines[0].strip()
        if (
            first.startswith("WEBVTT")
            or first.startswith("NOTE")
            or first in ("STYLE", "REGION")
        ):
            continue

        timing_index = -1
        match = None
        for index, line in enumerate(lines):
            match = _VTT_TIMING.match(line)
            if match:
                timing_index = index
                break
        if timing_index < 0:
            continue

        payload = "\n".join(lines[timing_index + 1:]).strip()
        if not payload:
            continue
        # WebVTT karaoke timestamp tags are not valid SRT markup.
        payload = re.sub(
            r"<(?:\d{1,3}:)?\d{2}:\d{2}[.,]\d{3}>",
            "",
            payload,
        )
        cues.append((_srt_timestamp(match.group(1)),
                     _srt_timestamp(match.group(2)), payload))

    if not cues:
        return ""
    blocks = [
        "%d\r\n%s --> %s\r\n%s" % (index, start, end, payload)
        for index, (start, end, payload) in enumerate(cues, 1)
    ]
    return "\r\n\r\n".join(blocks) + "\r\n"


def _language_tokens(value):
    normalized = re.sub(r"[^a-z0-9]+", " ", (value or "").lower()).strip()
    tokens = set(normalized.split())
    if normalized:
        tokens.add(normalized)
    for language, codes in _LANGUAGE_CODES.items():
        if language in normalized or any(code in tokens for code in codes):
            tokens.add(language)
            tokens.update(codes)
    return tokens


def choose_subtitle_stream_index(streams, preferred="", current="", fallback=-1):
    """Choose a stream index while preserving a user's current selection.

    Kodi may expose the active subtitle as a friendly filename while the
    available-stream list contains only ISO codes. Language-token matching
    bridges those representations. A validated fallback preserves the index
    selected at playback start when Kodi cannot describe the active stream.
    """
    stream_values = [str(stream or "") for stream in (streams or [])]
    for needle in (current, preferred):
        needle_tokens = _language_tokens(needle)
        if not needle_tokens:
            continue
        for index, stream in enumerate(stream_values):
            if needle_tokens.intersection(_language_tokens(stream)):
                return index
    if isinstance(fallback, int) and 0 <= fallback < len(stream_values):
        return fallback
    return -1
