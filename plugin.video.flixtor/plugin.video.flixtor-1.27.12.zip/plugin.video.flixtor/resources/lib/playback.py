"""Pure helpers for adaptive HLS playback policy and manifest parsing."""

import re
import urllib.parse


_SETTING_QUALITY = {
    "0": "auto",
    "1": "1080p",
    "2": "720p",
    "3": "480p",
    "4": "360p",
    "5": "ask",
}


def normalize_quality(value):
    """Return a stable quality token for settings and saved watch history."""
    text = str(value or "").strip().lower()
    if not text:
        return ""
    if text.startswith("auto"):
        return "auto"
    if text.startswith("ask"):
        return "ask"
    match = re.search(r"\b(1080|720|480|360)p\b", text)
    return "%sp" % match.group(1) if match else ""


def adaptive_policy(setting_value, preferred=""):
    """Resolve the saved/default quality into InputStream Adaptive controls.

    A saved quality from watch history takes precedence, matching the previous
    resume behavior.  Fixed qualities are now ceilings so the player can step
    down when bandwidth drops.  InputStream Adaptive has no 360p resolution
    ceiling, so that mode also asks the caller to derive a bandwidth ceiling
    from the current master manifest.
    """
    quality = normalize_quality(preferred)
    if not quality:
        quality = _SETTING_QUALITY.get(str(setting_value or "0"), "auto")

    if quality == "ask":
        return {
            "label": "Ask",
            "selection_type": "ask-quality",
            "resolution_max": "",
            "bandwidth_height": 0,
        }
    if quality == "auto":
        return {
            "label": "Auto",
            "selection_type": "adaptive",
            "resolution_max": "",
            "bandwidth_height": 0,
        }

    height = int(quality[:-1])
    return {
        "label": quality,
        "selection_type": "adaptive",
        # ISA's documented resolution ceilings begin at 480p.  For 360p,
        # combine the 480p safety ceiling with the manifest-derived bitrate.
        "resolution_max": quality if height >= 480 else "480p",
        "bandwidth_height": height if height < 480 else 0,
    }


def _manifest_attributes(line):
    attributes = {}
    for match in re.finditer(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', line):
        value = match.group(2).strip()
        if len(value) >= 2 and value[0] == value[-1] == '"':
            value = value[1:-1]
        attributes[match.group(1)] = value
    return attributes


def parse_hls_variants(master_url, manifest):
    """Return normalized variant dictionaries from an HLS master playlist."""
    lines = [line.strip() for line in str(manifest or "").splitlines()]
    variants = []
    for index, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF:"):
            continue
        attrs = _manifest_attributes(line)
        uri = ""
        for candidate in lines[index + 1:]:
            if candidate and not candidate.startswith("#"):
                uri = candidate
                break
        if not uri:
            continue

        resolution = attrs.get("RESOLUTION", "")
        match = re.match(r"^(\d+)x(\d+)$", resolution)
        height = int(match.group(2)) if match else 0
        # chooser_bandwidth_max is compared with the representation's declared
        # peak BANDWIDTH, so do not cap it at the lower average and
        # accidentally exclude the intended rendition.
        bandwidth_text = attrs.get("BANDWIDTH") or attrs.get("AVERAGE-BANDWIDTH") or "0"
        try:
            bandwidth = int(bandwidth_text)
        except (TypeError, ValueError):
            bandwidth = 0
        label = attrs.get("NAME") or ("%dp" % height if height else "Auto")
        variants.append({
            "label": label,
            "resolution": resolution,
            "height": height,
            "bandwidth": bandwidth,
            "url": urllib.parse.urljoin(master_url, uri),
        })
    return variants


def bandwidth_ceiling(variants, max_height):
    """Return the highest advertised bitrate at/below ``max_height``.

    If the requested resolution is unavailable, cap at the lowest advertised
    representation rather than leaving a nominal low-quality preference
    uncapped.
    """
    usable = [
        variant for variant in variants
        if variant.get("bandwidth", 0) > 0 and variant.get("height", 0) <= max_height
    ]
    if usable:
        return max(variant["bandwidth"] for variant in usable)
    advertised = [
        variant["bandwidth"] for variant in variants
        if variant.get("bandwidth", 0) > 0
    ]
    return min(advertised) if advertised else 0
