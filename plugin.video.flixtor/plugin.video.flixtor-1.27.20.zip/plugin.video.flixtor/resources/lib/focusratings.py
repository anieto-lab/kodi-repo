"""IMDb / Rotten Tomatoes ratings for the highlighted Flixtor title.

Listings already carry cached ratings (main._attach_ratings). This service
helper covers titles that have none yet: once the highlight rests on a title
for one poll, it fetches that title's ratings (one OMDb request, cached for
weeks) and publishes them as Home window properties keyed by the title. The
skin shows them only on the item whose Flixtor.RatingsKey matches, so a
fetch that finishes late can never label another title.

It runs only while Flixtor Horizon is the skin. Other skins keep TMDb
Helper's own ratings and never pay for these requests.
"""

import threading

SKIN_ID = "skin.flixtor.horizon"
POLL_SECONDS = 0.25
KEY = "Flixtor.Focus.Key"
IMDB = "Flixtor.Focus.IMDbRating"
RT = "Flixtor.Focus.RTScore"


class FocusRatings:
    def __init__(self, can_run, get_label, get_skin, window, fetch):
        self.can_run = can_run
        self.get_label = get_label
        self.get_skin = get_skin
        self.window = window
        self.fetch = fetch
        self.last = ""
        self.settled = False
        self.stopped = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True, name="FlixtorFocusRatings")

    def start(self):
        self.thread.start()

    def close(self):
        self.stopped.set()

    def _run(self):
        while not self.stopped.wait(POLL_SECONDS):
            try:
                self.step()
            except Exception:
                # Optional enrichment must never take the service down.
                self.stopped.wait(1)

    def _focused(self, name):
        return self.get_label("ListItem.Property(Flixtor.%s)" % name)

    def step(self):
        """One poll. Fetches at most once per resting highlight."""
        if self.get_skin() != SKIN_ID or not self.can_run():
            self.last, self.settled = "", False
            return
        key = self._focused("RatingsKey")
        if not key or key != self.last:
            self.last, self.settled = key, False
            return
        if self.settled:
            return
        self.settled = True
        if self.window.getProperty(KEY) == key:
            return  # Already published for this title.
        if self._focused("IMDbRating") or self._focused("RTScore"):
            return  # The listing had cached ratings.
        media, _, tmdb_id = key.partition(":")
        entry = self.fetch(media, tmdb_id)
        if not entry or entry.get("miss") or self._focused("RatingsKey") != key:
            return
        self.window.clearProperty(KEY)
        self.window.setProperty(IMDB, entry.get("imdb") or "")
        rt = entry.get("rt")
        self.window.setProperty(RT, "" if rt is None else str(rt))
        self.window.setProperty(KEY, key)
