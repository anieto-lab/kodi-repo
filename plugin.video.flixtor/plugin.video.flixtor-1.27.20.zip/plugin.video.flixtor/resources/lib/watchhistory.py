"""Watch history, search history, and resume point storage for Flixtor addon."""

import json
import os
import time
from functools import wraps
from resources.lib.storage import atomic_json, read_json, profile_lock, recover_library


def library_operation(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with profile_lock(self._dir):
            recover_library(self._dir)
            return method(self, *args, **kwargs)
    return guarded


def is_completed(record):
    if "completed" in record:
        return record["completed"] is True
    return bool(record.get("total_seconds", 0) > 0 and record.get("resume_seconds", 0) == 0)

try:
    import xbmcvfs
    import xbmcaddon

    def _get_userdata_dir():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        return xbmcvfs.translatePath(addon.getAddonInfo("profile"))
except ImportError:
    # For local testing outside Kodi
    def _get_userdata_dir():
        return os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata")


MAX_HISTORY = 50  # Default recent-history window; durable state is never truncated.
WATCH_HISTORY_VERSION_PROPERTY = "Flixtor.WatchHistoryVersion"
MAX_SEARCHES = 10
STALE_MARKER_SECONDS = 60


def notify_watch_change():
    """Invalidate Home feeds after a committed state change, when Kodi is present."""
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty(WATCH_HISTORY_VERSION_PROPERTY, str(time.time_ns()))
    except (ImportError, AttributeError, RuntimeError):
        pass


def normalize_inventory(seasons):
    """Validate an authoritative available-episode snapshot before any mutation."""
    if not isinstance(seasons, dict) or not seasons:
        raise ValueError("Available episodes are unknown")
    normalized, seen = {}, set()
    for season, episodes in seasons.items():
        if isinstance(season, bool) or not str(season).isdigit():
            raise ValueError("Invalid season identity")
        canonical_season = str(int(season))
        if canonical_season in seen:
            raise ValueError("Duplicate season identity")
        seen.add(canonical_season)
        if not isinstance(episodes, (list, tuple, set)):
            raise ValueError("Invalid available episodes")
        values = set()
        for episode in episodes:
            if isinstance(episode, bool) or not str(episode).isdigit() or int(episode) < 1:
                raise ValueError("Invalid episode identity")
            values.add(int(episode))
        if values:
            normalized[canonical_season] = sorted(values)
    if not normalized:
        raise ValueError("Available episodes are unknown")
    return normalized


def _record_key(rec):
    """Unique key for a watch record: pid for movies, (pid, season, episode) for TV."""
    if rec.get("media_type") == "movie" or rec.get("season") is None:
        return str(rec["pid"])
    return _make_key(rec["pid"], rec["season"], rec["episode"])


def _make_key(pid, season=None, episode=None):
    """Build a record key from explicit values."""
    if season is not None:
        return (str(pid), int(season), int(episode))
    return str(pid)


class WatchHistory:
    def __init__(self):
        self._dir = _get_userdata_dir()
        self._history_path = os.path.join(self._dir, "watch_history.json")
        self._nowplaying_path = os.path.join(self._dir, "now_playing.json")
        self._inventory_path = os.path.join(self._dir, "watch_inventory.json")

    def _ensure_dir(self):
        if not os.path.isdir(self._dir):
            os.makedirs(self._dir, exist_ok=True)

    def _read_json(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return None

    def _write_json(self, path, data):
        atomic_json(path, data)

    # ── now_playing marker (plugin → service handoff) ────────────────

    @library_operation
    def set_now_playing(self, metadata):
        self._write_json(self._nowplaying_path, metadata)

    @library_operation
    def get_now_playing(self):
        data = self._read_json(self._nowplaying_path)
        if not data:
            return None
        # Ignore stale markers
        ts = data.get("timestamp", 0)
        if time.time() - ts > STALE_MARKER_SECONDS:
            self.clear_now_playing()
            return None
        return data

    @library_operation
    def clear_now_playing(self):
        try:
            os.remove(self._nowplaying_path)
        except OSError:
            pass

    # ── watch history persistence ────────────────────────────────────

    @library_operation
    def _load_history(self):
        data = read_json(self._history_path, [])
        if not isinstance(data, list):
            raise ValueError("Invalid watch history; original file preserved")
        return data

    def _save_history(self, history):
        # A recent shelf is bounded; durable completion and explicit unwatched
        # records are not. Dropping old rows would lose ticks and resurrect old
        # watched state when a backup is merged later.
        self._write_json(self._history_path, history)
        notify_watch_change()

    @library_operation
    def get_all(self):
        """Return every durable movie/episode state, newest first."""
        return self._load_history()

    @library_operation
    def get_inventory(self, pid=None):
        inventories = read_json(self._inventory_path, {})
        if not isinstance(inventories, dict):
            raise ValueError("Invalid episode inventory; original file preserved")
        return inventories.get(str(pid), {}) if pid is not None else inventories

    @library_operation
    def remember_inventory(self, pid, seasons, metadata=None):
        """Save known episode identities from an already-fetched show listing."""
        pid = str(pid or "")
        if not pid:
            raise ValueError("Missing show identity")
        normalized = normalize_inventory(seasons)
        inventories = self.get_inventory()
        previous = inventories.get(pid, {})
        entry = dict(previous)
        for key in ("title", "slug", "poster", "year", "tmdb_id"):
            value = (metadata or {}).get(key)
            if value not in (None, ""):
                entry[key] = value
        entry.update(pid=pid, seasons=normalized)
        if entry == previous:
            return False
        entry["timestamp"] = time.time()
        inventories[pid] = entry
        self._write_json(self._inventory_path, inventories)
        notify_watch_change()
        return True

    @library_operation
    def set_watched(self, pid, watched, media_type="movie", season=None,
                    episode=None, metadata=None):
        """Atomically mark a movie, episode, known season, or known show.

        Explicit unwatched rows remain as timestamped tombstones so an older
        backup cannot silently restore the completion the user just cleared.
        """
        pid = str(pid or "")
        if not pid or media_type not in ("movie", "tv") or type(watched) is not bool:
            raise ValueError("Invalid watch-state request")
        if episode is not None and season is None:
            raise ValueError("Missing season identity")
        for number, minimum in ((season, 0), (episode, 1)):
            if number is not None and (isinstance(number, bool) or not str(number).isdigit()
                                       or int(number) < minimum):
                raise ValueError("Invalid episode identity")
        season = int(season) if season is not None else None
        episode = int(episode) if episode is not None else None
        if media_type == "movie" and (season is not None or episode is not None):
            raise ValueError("A movie cannot have episode coordinates")
        common = dict(metadata or {})
        if media_type == "movie":
            keys = [(None, None)]
        elif episode is not None:
            keys = [(season, episode)]
        else:
            inventory = self.get_inventory(pid)
            available = normalize_inventory(inventory.get("seasons"))
            if season is not None and str(season) not in available:
                raise ValueError("Available episodes for this season are unknown")
            keys = [(int(s), e) for s, values in available.items()
                    if season is None or int(s) == season for e in values]
            common = dict(inventory, **common)
        history = self._load_history()
        existing = {_record_key(record): record for record in history}
        if not watched and media_type == "tv" and episode is None:
            # A reset also clears old known episodes/queued items that are no
            # longer listed by the source, within the selected scope only.
            keys = list(set(keys) | {(int(record["season"]), int(record["episode"]))
                        for record in history if str(record.get("pid")) == pid
                        and record.get("media_type") == "tv" and record.get("season") is not None
                        and record.get("episode") is not None
                        and (season is None or int(record["season"]) == season)})
        timestamp = time.time()
        changed, affected = [], set()
        allowed = ("title", "slug", "poster", "year", "rating", "rating_provider",
                   "genres", "tmdb_id", "episode_title")
        for s, e in sorted(keys, key=lambda pair: (pair[0] or 0, pair[1] or 0)):
            key = _make_key(pid, s, e)
            record = dict(existing.get(key, {}))
            for field in allowed:
                value = common.get(field)
                if value not in (None, ""):
                    # A bulk show action must not replace real episode titles.
                    if field != "episode_title" or episode is not None:
                        record[field] = value
            record.update(pid=pid, media_type=media_type, completed=watched,
                          resume_seconds=0.0, up_next=False, timestamp=timestamp)
            record.setdefault("total_seconds", 0.0)
            if s is not None:
                record.update(season=s, episode=e)
            else:
                record.pop("season", None)
                record.pop("episode", None)
            changed.append(record)
            affected.add(key)
        self._save_history(changed + [record for record in history if _record_key(record) not in affected])
        return len(changed)

    @library_operation
    def update_position(self, metadata):
        """Upsert a record in the history. Moves it to the top (most recent)."""
        history = self._load_history()
        key = _record_key(metadata)

        # Remove existing entry for this content
        history = [r for r in history if _record_key(r) != key]

        # Update timestamp and insert at top
        metadata = dict(metadata)
        metadata["timestamp"] = time.time()
        metadata.pop("up_next", None)
        history.insert(0, metadata)

        self._save_history(history)

    @library_operation
    def queue_next(self, metadata):
        """Queue a successor after completion, preserving actual progress/ticks.

        An explicit unwatched zero-position row may become Up Next after new
        playback; the reset itself still leaves both shelves immediately.
        """
        key = _record_key(metadata)
        history = self._load_history()
        previous = {}
        for rec in history:
            if _record_key(rec) == key:
                if is_completed(rec) or float(rec.get("resume_seconds") or 0) > 0:
                    return
                previous = rec
                break
        meta = dict(previous)
        meta.update({field: value for field, value in metadata.items()
                     if value not in (None, "")})
        meta["up_next"] = True
        meta["completed"] = False
        meta["resume_seconds"] = 0.0
        meta["total_seconds"] = 0.0
        meta["timestamp"] = time.time()
        history = [r for r in history if _record_key(r) != key]
        history.insert(0, meta)
        self._save_history(history)

    @library_operation
    def get_resume_position(self, pid, season=None, episode=None):
        """Return resume seconds for a specific item, or 0 if none/completed."""
        key = _make_key(pid, season, episode)
        for rec in self._load_history():
            if _record_key(rec) == key:
                return 0 if is_completed(rec) else rec.get("resume_seconds", 0)
        return 0

    @library_operation
    def get_quality(self, pid, season=None, episode=None):
        """Return the saved quality name for a specific item, or '' if none."""
        key = _make_key(pid, season, episode)
        for rec in self._load_history():
            if _record_key(rec) == key:
                return rec.get("quality", "")
        return ""

    @library_operation
    def get_recent(self, limit=20):
        """Return the most recent watch history items."""
        return self._load_history()[:limit]

    @library_operation
    def remove_item(self, pid, season=None, episode=None):
        """Remove a record from watch history by key."""
        key = _make_key(pid, season, episode)
        history = self._load_history()
        history = [r for r in history if _record_key(r) != key]
        self._save_history(history)

    @library_operation
    def remove_show(self, pid):
        """Remove every episode record for a TV show from watch history."""
        pid = str(pid)
        history = self._load_history()
        history = [r for r in history if str(r.get("pid") or "") != pid]
        self._save_history(history)

    @library_operation
    def clear_resume(self, pid, season=None, episode=None):
        """Clear the resume point for a record, which marks it watched."""
        key = _make_key(pid, season, episode)
        history = self._load_history()
        for rec in history:
            if _record_key(rec) == key:
                rec["resume_seconds"] = 0.0
                rec["completed"] = True
                rec["up_next"] = False
                rec["timestamp"] = time.time()
                break
        self._save_history(history)

    @library_operation
    def clear_all(self):
        """Wipe all watch history."""
        self._save_history([])


class SearchHistory:
    """Persists recent search queries to avoid re-typing on Fire TV."""

    def __init__(self):
        self._dir = _get_userdata_dir()
        self._path = os.path.join(self._dir, "search_history.json")

    def _load(self):
        try:
            data = read_json(self._path, [])
            if isinstance(data, list):
                return [query for query in data if isinstance(query, str) and query.strip()]
        except ValueError:
            pass
        return []

    def add(self, query):
        """Return whether the recent searches shown on Home changed."""
        with profile_lock(self._dir):
            queries = self._load()
            recent = [query] + [q for q in queries if q.casefold() != query.casefold()]
            recent = recent[:MAX_SEARCHES]
            if recent == queries:
                return False
            atomic_json(self._path, recent)
            return True

    def get_all(self):
        """Return all saved queries, most recent first."""
        try:
            return self._load()
        except OSError:
            return []

    def remove(self, query):
        """Remove a specific query."""
        with profile_lock(self._dir):
            atomic_json(self._path, [q for q in self._load() if q != query])

    def clear_all(self):
        """Wipe all saved search queries."""
        with profile_lock(self._dir):
            atomic_json(self._path, [])


class FavoritesHistory:
    """Persists favorite movies and TV shows."""

    def __init__(self):
        self._dir = _get_userdata_dir()
        self._path = os.path.join(self._dir, "favorites.json")

    def _ensure_dir(self):
        if not os.path.isdir(self._dir):
            os.makedirs(self._dir, exist_ok=True)

    @library_operation
    def _load(self):
        data = read_json(self._path, [])
        if not isinstance(data, list):
            raise ValueError("Invalid favorites; original file preserved")
        return data

    def _save(self, items):
        atomic_json(self._path, items)

    @library_operation
    def add(self, item):
        """Add an item to favorites (deduplicates by pid)."""
        items = self._load()
        item = dict(item)
        pid = str(item.get("pid", ""))
        item["pid"] = pid
        items = [i for i in items if i.get("pid") != pid]
        item["timestamp"] = time.time()
        items.insert(0, item)
        self._save(items)

    @library_operation
    def remove(self, pid):
        """Remove a favorite by pid."""
        items = self._load()
        items = [i for i in items if i.get("pid") != str(pid)]
        self._save(items)

    @library_operation
    def get_all(self):
        """Return all favorites, most recently added first."""
        return self._load()

    @library_operation
    def is_favorite(self, pid):
        """Check if a pid is in favorites."""
        return any(i.get("pid") == str(pid) for i in self._load())

    @library_operation
    def clear_all(self):
        """Wipe all favorites."""
        self._save([])
