"""Bounded, deduplicated metadata work owned by the resident Kodi service."""

import json
import os
import sqlite3
import threading
import time

MAX_JOBS = 256          # the queue never grows past this many pending jobs
JOB_LIFETIME = 900      # an unfinished job is dropped after 15 minutes


def _connect(folder):
    os.makedirs(folder, exist_ok=True)
    connection = sqlite3.connect(os.path.join(folder, 'tmdb_jobs.sqlite'), timeout=0.2)
    connection.execute('CREATE TABLE IF NOT EXISTS jobs (key TEXT PRIMARY KEY, payload TEXT, due REAL, expires REAL)')
    return connection


def enqueue_jobs(folder, jobs):
    """Queue (key, payload) pairs; duplicates and overflow are ignored."""
    now = time.time()
    connection = _connect(folder)
    try:
        with connection:
            connection.execute('DELETE FROM jobs WHERE expires < ?', (now,))
            for key, payload in jobs:
                connection.execute('INSERT OR IGNORE INTO jobs SELECT ?,?,?,? WHERE (SELECT count(*) FROM jobs) < ?',
                                   (key, json.dumps(payload), now, now + JOB_LIFETIME, MAX_JOBS))
    finally:
        connection.close()


def enqueue(folder, requests):
    """Queue TMDb title searches: (cache key, title, year, media type)."""
    enqueue_jobs(folder, [(key, [title, year, media_type]) for key, title, year, media_type in requests])


def _claim(folder):
    connection = _connect(folder)
    try:
        connection.execute('BEGIN IMMEDIATE')
        now = time.time()
        connection.execute('DELETE FROM jobs WHERE expires < ?', (now,))
        row = connection.execute('SELECT key,payload FROM jobs WHERE due <= ? ORDER BY due LIMIT 1', (now,)).fetchone()
        if row:
            connection.execute('UPDATE jobs SET due=? WHERE key=?', (now + 30, row[0]))
        connection.commit()
        return (row[0], json.loads(row[1])) if row else None
    finally:
        connection.close()


class MetadataWorkers:
    def __init__(self, folder, can_run):
        self.folder = folder
        self.can_run = can_run
        self.stopped = threading.Event()
        self.threads = [threading.Thread(target=self._run, daemon=True, name='FlixtorMetadata') for _ in range(4)]

    def start(self):
        for thread in self.threads:
            thread.start()

    def close(self):
        self.stopped.set()

    def _run(self):
        while not self.stopped.wait(0.1):
            try:
                if not self.can_run():
                    continue
                if not self._run_one():
                    self.stopped.wait(0.2)
            except Exception:
                # Optional enrichment must never terminate playback monitoring.
                self.stopped.wait(1)

    def _run_one(self):
        """Claim and run one job; False when the queue had nothing due."""
        from resources.lib.tmdb import TmdbClient, _entry_is_usable, _title_only_match
        job = _claim(self.folder)
        if not job:
            return False
        key, args = job
        if not self.can_run():
            return True
        client = TmdbClient()
        if isinstance(args, dict) and args.get('kind') == 'season':
            from resources.lib import enrichment
            success = enrichment.fetch_season(client, self.folder, args['tmdb_id'], args['season'])
        else:
            title, year, media_type = args
            client.lookup_info(title, year, media_type)
            success = (_entry_is_usable(client._mem_cache.get(key), key)
                       or (not year and _title_only_match(client._mem_cache, title, media_type)[1] is not None))
        connection = _connect(self.folder)
        try:
            with connection:
                if success:
                    connection.execute('DELETE FROM jobs WHERE key=?', (key,))
                else:
                    connection.execute('UPDATE jobs SET due=? WHERE key=?', (time.time() + 60, key))
        finally:
            connection.close()
        return True
