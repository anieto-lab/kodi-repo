"""Episode synopses and IMDb / Rotten Tomatoes ratings, cached with hard caps.

Listings only read these stores, so browsing never waits on the network. The
resident service fills them: season synopses through the metadata queue,
ratings for the title in focus. Both stores are small JSON files in the
add-on profile, expire, and are size-capped so a Fire TV's storage cannot
fill up:

- episodes_cache.json: at most EPISODE_MAX_SEASONS seasons, each synopsis
  cut to EPISODE_MAX_CHARS characters (about 1.5 MB at the cap)
- ratings_cache.json: at most RATINGS_MAX_TITLES titles (about 300 KB)

Ratings come from one OMDb request per title, which carries both IMDb's
rating and the Rotten Tomatoes critics score; the IMDb id comes from TMDb.
"""

import json
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

from resources.lib.storage import atomic_json, profile_lock, read_json

EPISODES_FILE = "episodes_cache.json"
RATINGS_FILE = "ratings_cache.json"

EPISODE_MAX_SEASONS = 200
EPISODE_MAX_CHARS = 500
EPISODE_MAX_AGE_DAYS = 60
EPISODE_NEW_EPISODE_RECHECK = 2 * 86400   # a missing episode re-asks after this

RATINGS_MAX_TITLES = 3000
RATINGS_RECENT_MAX_AGE_DAYS = 21           # titles from this year or last
RATINGS_MAX_AGE_DAYS = 120
RATINGS_MISS_MAX_AGE_DAYS = 14

OMDB_API = "https://www.omdbapi.com/"
_TIMEOUT = 3
_UA = "plugin.video.flixtor/1 (Kodi)"
DAY = 86400


def _load(path):
    """A cache is disposable: unreadable or corrupt files count as empty."""
    try:
        value = read_json(path, {})
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def _newest(entries, limit):
    """Keep the `limit` most recently fetched entries."""
    if len(entries) <= limit:
        return entries
    ranked = sorted(entries.items(), key=lambda item: item[1].get("ts", 0) if isinstance(item[1], dict) else 0)
    return dict(ranked[len(ranked) - limit:])


# ── episode synopses ────────────────────────────────────────────────────

class EpisodeStore:
    def __init__(self, folder):
        self.folder = folder
        self.path = os.path.join(folder, EPISODES_FILE)
        self._entries = None

    def _all(self):
        if self._entries is None:
            self._entries = _load(self.path)
        return self._entries

    @staticmethod
    def key(tmdb_id, season):
        return "%s|%s" % (tmdb_id, int(season))

    def seasons(self):
        return dict(self._all())

    def plot(self, tmdb_id, season, episode):
        entry = self._all().get(self.key(tmdb_id, season))
        if not isinstance(entry, dict):
            return ""
        return str((entry.get("eps") or {}).get(str(int(episode)), ""))

    def needs_fetch(self, tmdb_id, season, episode, now=None):
        now = time.time() if now is None else now
        entry = self._all().get(self.key(tmdb_id, season))
        if not isinstance(entry, dict):
            return True
        age = now - entry.get("ts", 0)
        if age > EPISODE_MAX_AGE_DAYS * DAY:
            return True
        # A new episode of a running season: ask again, but not on every view.
        return str(int(episode)) not in (entry.get("eps") or {}) and age > EPISODE_NEW_EPISODE_RECHECK

    def save(self, tmdb_id, season, synopses):
        with profile_lock(self.folder):
            entries = _load(self.path)
            entries[self.key(tmdb_id, season)] = {"ts": time.time(), "eps": synopses}
            entries = _newest(entries, EPISODE_MAX_SEASONS)
            atomic_json(self.path, entries)
            self._entries = entries

    def prune(self, now=None):
        now = time.time() if now is None else now
        with profile_lock(self.folder):
            entries = _load(self.path)
            kept = {key: entry for key, entry in entries.items()
                    if isinstance(entry, dict) and now - entry.get("ts", 0) <= EPISODE_MAX_AGE_DAYS * DAY}
            kept = _newest(kept, EPISODE_MAX_SEASONS)
            if len(kept) != len(entries):
                atomic_json(self.path, kept)
            self._entries = kept
            return len(entries) - len(kept)


def fetch_season(client, folder, tmdb_id, season):
    """Store one season's episode synopses from TMDb; False on any failure."""
    if not re.fullmatch(r"[1-9][0-9]*", str(tmdb_id)) or not re.fullmatch(r"[0-9]{1,3}", str(season)):
        return False
    payload = client._request_json("tv/%s/season/%s" % (tmdb_id, int(season)), {"language": "en-US"})
    if not isinstance(payload, dict) or not isinstance(payload.get("episodes"), list):
        return False
    synopses = {}
    for episode in payload["episodes"]:
        if not isinstance(episode, dict):
            continue
        number, overview = episode.get("episode_number"), episode.get("overview")
        if isinstance(number, int) and isinstance(overview, str) and overview.strip():
            text = " ".join(overview.split())
            if len(text) > EPISODE_MAX_CHARS:
                text = text[:EPISODE_MAX_CHARS - 1].rsplit(" ", 1)[0] + "…"
            synopses[str(number)] = text
    EpisodeStore(folder).save(tmdb_id, season, synopses)
    return True


# ── IMDb / Rotten Tomatoes ratings ──────────────────────────────────────

class RatingsStore:
    def __init__(self, folder):
        self.folder = folder
        self.path = os.path.join(folder, RATINGS_FILE)
        self._data = None

    def _all(self):
        if self._data is None:
            data = _load(self.path)
            titles = data.get("titles")
            self._data = {"titles": titles if isinstance(titles, dict) else {},
                          "backoff_until": data.get("backoff_until", 0) or 0}
        return self._data

    @staticmethod
    def max_age(entry):
        if entry.get("miss"):
            return RATINGS_MISS_MAX_AGE_DAYS * DAY
        year = entry.get("year") or 0
        recent = isinstance(year, int) and year >= time.gmtime().tm_year - 1
        return (RATINGS_RECENT_MAX_AGE_DAYS if recent else RATINGS_MAX_AGE_DAYS) * DAY

    def titles(self):
        return dict(self._all()["titles"])

    def get(self, key, now=None):
        """A fresh entry, or None when absent or expired."""
        now = time.time() if now is None else now
        entry = self._all()["titles"].get(key)
        if not isinstance(entry, dict) or now - entry.get("ts", 0) > self.max_age(entry):
            return None
        return entry

    def stale(self, key):
        entry = self._all()["titles"].get(key)
        return entry if isinstance(entry, dict) else None

    def backoff_until(self):
        return self._all()["backoff_until"]

    def _write(self, change):
        with profile_lock(self.folder):
            self._data = None
            data = self._all()
            change(data)
            data["titles"] = _newest(data["titles"], RATINGS_MAX_TITLES)
            atomic_json(self.path, data)

    def put(self, key, entry):
        self._write(lambda data: data["titles"].__setitem__(key, entry))

    def pause_until(self, when):
        self._write(lambda data: data.__setitem__("backoff_until", when))

    def prune(self, now=None):
        now = time.time() if now is None else now
        dropped = []

        def change(data):
            titles = data["titles"]
            keep = {key: entry for key, entry in titles.items()
                    if isinstance(entry, dict) and now - entry.get("ts", 0) <= self.max_age(entry)}
            dropped.append(len(titles) - len(keep))
            data["titles"] = keep
        self._write(change)
        return dropped[0]


def omdb_request(imdb_id, api_key):
    """One OMDb lookup: the decoded payload, or None on a network error."""
    query = urllib.parse.urlencode({"i": imdb_id, "apikey": api_key})
    request = urllib.request.Request(OMDB_API + "?" + query,
                                     headers={"User-Agent": _UA, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=_TIMEOUT) as response:
            payload = json.loads(response.read(256 * 1024).decode("utf-8"))
    except (urllib.error.URLError, socket.timeout, OSError, ValueError):
        return None
    return payload if isinstance(payload, dict) else None


def _parse_omdb(payload):
    imdb = str(payload.get("imdbRating") or "")
    imdb = "%.1f" % float(imdb) if re.fullmatch(r"\d{1,2}(\.\d)?", imdb) else ""
    votes = re.sub(r"[^0-9]", "", str(payload.get("imdbVotes") or ""))
    rt = None
    for rating in payload.get("Ratings") or []:
        if isinstance(rating, dict) and rating.get("Source") == "Rotten Tomatoes":
            match = re.fullmatch(r"(\d{1,3})%", str(rating.get("Value") or ""))
            rt = int(match.group(1)) if match else None
    year = re.match(r"\d{4}", str(payload.get("Year") or ""))
    return {"imdb": imdb, "votes": int(votes) if votes else 0, "rt": rt,
            "year": int(year.group(0)) if year else 0}


def ratings_key(media_type, tmdb_id):
    return "%s:%s" % ("movie" if media_type == "movie" else "tv", tmdb_id)


def fetch_ratings(client, folder, media_type, tmdb_id, api_key, omdb_get=omdb_request, now=None):
    """Cached-or-fetched ratings for one title, or None when unavailable now.

    Network failures are never cached. OMDb's daily limit pauses every
    request until the next UTC midnight, when the limit resets.
    """
    now = time.time() if now is None else now
    store = RatingsStore(folder)
    key = ratings_key(media_type, tmdb_id)
    entry = store.get(key, now)
    if entry is not None:
        return entry
    if not api_key or store.backoff_until() > now:
        return None
    previous = store.stale(key) or {}
    imdb_id = previous.get("imdb_id") or client.external_imdb_id(
        "movie" if media_type == "movie" else "tv", tmdb_id)
    if imdb_id is None:
        return None
    if not imdb_id:
        entry = {"miss": True, "imdb_id": "", "ts": now}
        store.put(key, entry)
        return entry
    payload = omdb_get(imdb_id, api_key)
    if payload is None:
        return None
    if str(payload.get("Response")) != "True":
        if "limit" in str(payload.get("Error", "")).lower():
            store.pause_until((now // DAY + 1) * DAY)
            return None
        entry = {"miss": True, "imdb_id": imdb_id, "ts": now}
    else:
        entry = dict(_parse_omdb(payload), imdb_id=imdb_id, ts=now)
        if not entry["imdb"] and entry["rt"] is None:
            entry["miss"] = True
    store.put(key, entry)
    return entry
