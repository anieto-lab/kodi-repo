"""Flixtor Kodi addon — browse, search, and stream movies/TV from Flixtor VIP."""

import base64
import hashlib
import json
import os
import sqlite3
import re
import sys
import time
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import xbmc
from resources.lib import cachemaint
from resources.lib import playbacksetup
from resources.lib import voicebridge
from resources.lib.flixtor import FlixtorClient, _cookie_path, _api_cache_path
from resources.lib.kodiui import set_parent_folder_items
from resources.lib.playback import (
    adaptive_policy,
    bandwidth_ceiling,
    parse_hls_variants,
)
from resources.lib.navigation import (
    AH2_DETAILS_CONTROL_IDS,
    ROOT_EXIT_ALLOW_PROPERTY,
    ROOT_ROUTE_PROPERTY,
    canonical_show_title,
    collapse_recent_items,
    is_dialog_open,
    is_supported_skin,
    skin_owns_home,
    select_flixtor_match,
    flixtor_match_candidates,
    should_guard_flixtor_root_back,
    should_open_one_press_details,
)
from resources.lib.subtitles import webvtt_to_srt
from resources.lib.tmdb import TmdbClient
from resources.lib.widgets import is_widget_action, widget_base_route
from resources.lib.watchhistory import (
    WatchHistory, SearchHistory, FavoritesHistory, is_completed, normalize_inventory,
    _make_key as _watch_key, _record_key as _watch_record_key,
)

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
PAGE_SIZE = 24
CONTINUE_WATCHING_MAX = 2  # distinct titles shown in the Continue Watching band
NEXT_PAGE_ICON = "special://home/addons/plugin.video.flixtor/resources/media/next.png"
CARD_ART_BASE = "special://home/addons/plugin.video.flixtor/resources/media/cards"
ACTIVE_SEARCH_QUERY_PROPERTY = "Flixtor.ActiveSearchQuery"
SEARCH_HISTORY_VERSION_PROPERTY = "Flixtor.SearchHistoryVersion"
_LEGACY_STREAM_HEADERS = "Referer=https://flixtor.to/&Origin=https://flixtor.to"
_INPUTSTREAM_HEADERS = (
    "Referer=https%3A%2F%2Fflixtor.to%2F&"
    "Origin=https%3A%2F%2Fflixtor.to"
)
_PLAYBACK_SETUP_STATE = "playback_setup_state"
_PLAYBACK_SETUP_ORIGINAL_MEMORY = "playback_setup_original_memory"
_PLAYBACK_SETUP_ORIGINAL_READ_FACTOR = "playback_setup_original_readfactor"


def _card_art(slug):
    """Return setArt() dict for a bundled card image. AH2 picks different art
    types per view (icon/thumb/poster/landscape), so set them all to the same
    image to ensure the card image renders regardless of the active view."""
    path = "%s/%s.jpg" % (CARD_ART_BASE, slug)
    return {
        "icon": path, "thumb": path, "poster": path,
        "landscape": path, "fanart": path,
    }


def _set_navigation_info(li, label, plot, title=None, empty=False):
    """Give menu cards readable guidance without presenting them as media."""
    li.setInfo("video", {"title": title or label, "plot": plot})
    li.setProperty("Flixtor.Category", "true")
    li.setProperty("Flixtor.ItemKind", "navigation")
    li.setProperty("Flixtor.NavigationLabel", label)
    if empty:
        li.setProperty("Flixtor.EmptyState", "true")


def _listing_content(items):
    """Use a media view only when every real title has the same type."""
    media_types = {item.get("media_type") for item in items}
    return ("movies" if media_types == {"movie"} else
            "tvshows" if media_types == {"tv"} else "videos")


# Genre-name → card slug. Movie and TV genre lists differ but several share a
# concept (Movies "Action" + TV "Action-Adventure" → genre_action), so the map
# folds aliases onto a single slug to keep the card-image set small.
_GENRE_CARD_SLUGS = {
    "Action": "genre_action", "Action-Adventure": "genre_action",
    "Adventure": "genre_adventure",
    "Animation": "genre_animation",
    "Comedy": "genre_comedy",
    "Crime": "genre_crime",
    "Documentary": "genre_documentary",
    "Drama": "genre_drama",
    "Family": "genre_family",
    "Fantasy": "genre_fantasy",
    "History": "genre_history",
    "Horror": "genre_horror",
    "Kids": "genre_kids",
    "Music": "genre_music",
    "Musical": "genre_musical",
    "Mystery": "genre_mystery",
    "News": "genre_news",
    "Reality": "genre_reality",
    "Romance": "genre_romance",
    "Science-Fiction": "genre_scifi", "Sci-Fi-Fantasy": "genre_scifi",
    "Soap": "genre_soap",
    "Talk": "genre_talk",
    "Thriller": "genre_thriller",
    "TV-Movie": "genre_tvmovie",
    "War": "genre_war", "War-Politics": "genre_war",
    "Western": "genre_western",
}
_OBF_PREFIX = "__obf1__"

_client = None
_tmdb = None
_device_key_cached = None


def _rating_enrichment_enabled():
    """True unless the user disabled the rating-strip TMDb lookup in Settings."""
    return ADDON.getSetting("rating_enrichment") != "false"


def _get_tmdb():
    """Lazy TmdbClient singleton. Returns None when enrichment is disabled so
    callers can skip lookups without additional conditionals."""
    global _tmdb
    if not _rating_enrichment_enabled():
        return None
    if _tmdb is None:
        _tmdb = TmdbClient()
    return _tmdb


def _attach_tmdb_id(li, tmdb_id, media_type=None):
    """Set uniqueid.tmdb on a ListItem so TMDb Helper's service monitor can
    enrich container 99950 (powers AH2's rating strip). No-op on falsy ids.

    With a media type the item also carries its cached IMDb and Rotten
    Tomatoes ratings as plain properties. Skins that do not read them are
    unaffected; Flixtor Horizon shows them and fetches missing ones for the
    title in focus."""
    if not tmdb_id:
        return
    try:
        li.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
    except Exception as exc:
        _log("tmdb: setUniqueIDs failed: %s" % exc)
    if media_type:
        _attach_ratings(li, media_type, tmdb_id)


_enrichment_stores = {}
_queued_seasons = set()


def _enrichment_store(kind):
    """One read of each enrichment store per plugin call."""
    store = _enrichment_stores.get(kind)
    if store is None:
        from resources.lib import enrichment
        folder = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
        store = (enrichment.RatingsStore if kind == "ratings" else enrichment.EpisodeStore)(folder)
        _enrichment_stores[kind] = store
    return store


def _attach_ratings(li, media_type, tmdb_id):
    """Cached IMDb / Rotten Tomatoes ratings only; listings never fetch."""
    from resources.lib.enrichment import ratings_key
    key = ratings_key(media_type, tmdb_id)
    li.setProperty("Flixtor.RatingsKey", key)
    try:
        entry = _enrichment_store("ratings").get(key)
    except (OSError, ValueError):
        entry = None
    if not entry or entry.get("miss"):
        return
    if entry.get("imdb"):
        li.setProperty("Flixtor.IMDbRating", entry["imdb"])
        try:
            li.setRating("imdb", float(entry["imdb"]), int(entry.get("votes") or 0), False)
        except (AttributeError, TypeError, ValueError):
            pass
    if entry.get("rt") is not None:
        li.setProperty("Flixtor.RTScore", str(entry["rt"]))


def _episode_plot(tmdb_id, season, episode):
    """The episode's own synopsis when cached. Otherwise its season is queued
    for the resident service and "" lets the caller use the show's synopsis."""
    if not tmdb_id or season is None or episode is None:
        return ""
    try:
        store = _enrichment_store("episodes")
        plot = store.plot(tmdb_id, season, episode)
        key = "season|%s|%s" % (tmdb_id, int(season))
        if key not in _queued_seasons and store.needs_fetch(tmdb_id, season, episode):
            from resources.lib.metadataqueue import enqueue_jobs
            enqueue_jobs(store.folder, [(key, {"kind": "season", "tmdb_id": int(tmdb_id),
                                               "season": int(season)})])
            _queued_seasons.add(key)
        return plot
    except (OSError, ValueError, TypeError, sqlite3.Error) as exc:
        _log("episodes: synopsis lookup failed: %s" % exc)
        return ""


def _history_identity(title, media_type):
    """Year and TMDb id of a title already matched while browsing, saved with
    watch history so its synopsis and ratings resolve later. Cache only."""
    tmdb_client = _get_tmdb()
    if not tmdb_client or not title:
        return {}
    try:
        info = tmdb_client.lookup_cached_info(title, "", "movie" if media_type == "movie" else "tv")
    except Exception as exc:
        _log("history: identity lookup failed: %s" % exc)
        return {}
    identity = {}
    if info.get("tmdb_id"):
        identity["tmdb_id"] = info["tmdb_id"]
    if str(info.get("year") or "").isdigit():
        identity["year"] = info["year"]
    return identity


_favorites_pid_cache = None


def _favorites_pid_set():
    """Lazily load the favorited pid set for this plugin process. Avoids
    re-reading favorites.json for every item in a directory listing."""
    global _favorites_pid_cache
    if _favorites_pid_cache is None:
        _favorites_pid_cache = {
            str(i.get("pid", "")) for i in FavoritesHistory().get_all()
        }
    return _favorites_pid_cache


def _favorites_context_item(pid, item_payload=None):
    """Return a (label, RunPlugin(...)) context menu tuple that toggles
    between adding and removing from the addon's Favorites depending on
    current state. ``item_payload`` is the dict of fields to persist on add
    (title, slug, poster, etc.); only the pid is needed for remove."""
    pid_str = str(pid)
    if pid_str in _favorites_pid_set():
        return (
            "Remove from Flixtor Favorites",
            "RunPlugin(%s)" % build_url("ctx_remove_favorite", pid=pid_str),
        )
    payload = dict(item_payload or {})
    payload["pid"] = pid_str
    return (
        "Add to Flixtor Favorites",
        "RunPlugin(%s)" % build_url("ctx_add_favorite", **payload),
    )


def _title_discovery_context_items(pid, slug, media_type, li=None):
    """Return the stable Flixtor-owned trailer and recommendation actions.

    Keep Watch Trailer visible even when Kodi reports the YouTube add-on
    missing or disabled. Selecting it then reaches ``play_trailer()``, which
    explains the dependency and offers Kodi's normal install flow. Hiding the
    entry made the feature impossible to discover after Flixtor replaced the
    skin's conflicting native context menu.
    """
    normalized_type = "movie" if media_type == "movie" else "tv"
    return [
        (
            "Watch Trailer",
            (li.getProperty("Flixtor.TrailerAction") if li is not None else "") or "RunPlugin(%s)" % build_url(
                "play_trailer",
                pid=pid,
                slug=slug,
                media_type=normalized_type,
            ),
        ),
        (
            "Similar Titles",
            _open_listing_command(build_url(
                "recommendations",
                pid=pid,
                slug=slug,
                media_type=normalized_type,
            )),
        ),
    ]


def _open_listing_command(url):
    """Open a Flixtor listing from a menu, wherever that menu was raised.

    Horizon raises menus over its own Home rows, so the listing needs the
    Videos window; inside the add-on's folders the current container updates.
    """
    if skin_owns_home(xbmc.getSkinDir()):
        return "ActivateWindow(Videos,%s,return)" % url
    return "Container.Update(%s)" % url


def _prefetch_tmdb(items):
    """Batch-resolve TMDb info for a list of item dicts. Mutates each item
    with ``tmdb_id``/``tmdb_plot``/``tmdb_fanart``/``tmdb_vote`` keys.
    No-op when enrichment is disabled."""
    client = _get_tmdb()
    if client and items:
        client.lookup_many(items, stop_requested=xbmc.Monitor().abortRequested)


_watch_state_cache = None
_watch_inventory_cache = None
_trailer_cache = None


def _watch_state():
    """Lazily-loaded watch-history map for this plugin process:
    record key (pid, or (pid, season, episode)) → record. One file read
    per process so every listing can show native watched ticks/progress."""
    global _watch_state_cache
    if _watch_state_cache is None:
        _watch_state_cache = {
            _watch_record_key(rec): rec
            for rec in WatchHistory().get_all()
            if rec.get("pid")
        }
    return _watch_state_cache


def _watch_inventory():
    global _watch_inventory_cache
    if _watch_inventory_cache is None:
        _watch_inventory_cache = WatchHistory().get_inventory()
    return _watch_inventory_cache


def _watch_status(pid, media_type="movie", season=None, episode=None):
    """Read single-item or all-known-episodes state without any network work."""
    records = _watch_state()
    if media_type == "movie" or episode is not None:
        record = records.get(_watch_key(pid, season, episode), {})
        completed = bool(record) and is_completed(record)
        resume = 0.0 if completed else float(record.get("resume_seconds") or 0)
        total = float(record.get("total_seconds") or 0)
        return {"state": "watched" if completed else "in_progress" if resume > 0 else "unwatched",
                "completed": completed, "resume": resume, "total": total,
                "up_next": bool(record.get("up_next")) and not completed}
    inventory = _watch_inventory().get(str(pid), {})
    seasons = inventory.get("seasons") or {}
    identities = [(int(s), int(e)) for s, episodes in seasons.items()
                  if season is None or int(s) == int(season) for e in episodes]
    if not identities:
        return {"state": "unknown", "completed": False, "resume": 0.0, "total": 0.0}
    selected = [records.get(_watch_key(pid, s, e), {}) for s, e in identities]
    watched = sum(bool(record) and is_completed(record) for record in selected)
    has_progress = any(float(record.get("resume_seconds") or 0) > 0 or record.get("up_next")
                       for record in selected if not is_completed(record))
    state = ("watched" if watched == len(identities) else
             "in_progress" if watched or has_progress else "unwatched")
    return {"state": state, "completed": state == "watched", "resume": 0.0, "total": 0.0,
            "watched_episodes": watched, "total_episodes": len(identities)}


def _apply_watch_state(li, info, pid, season=None, episode=None, media_type=None):
    """Set Flixtor's durable state and native Kodi ticks/progress consistently."""
    media_type = media_type or ("tv" if season is not None or info.get("mediatype") == "tvshow" else "movie")
    status = _watch_status(pid, media_type, season, episode)
    info["playcount"] = 1 if status["completed"] else 0
    li.setProperty("Flixtor.WatchState", status["state"])
    label = {"watched": "Watched", "in_progress": "In progress", "unwatched": "Unwatched",
             "unknown": "Episode status not yet available"}[status["state"]]
    if "total_episodes" in status:
        watched, total = status["watched_episodes"], status["total_episodes"]
        label = "%d of %d available episodes watched" % (watched, total)
        for key, value in (("WatchedEpisodes", watched), ("TotalEpisodes", total),
                           ("UnwatchedEpisodes", total - watched)):
            li.setProperty("Flixtor." + key, str(value))
            li.setProperty(key, str(value))
    if status["resume"] > 0 and status["total"] > 0:
        li.setProperty("ResumeTime", str(status["resume"]))
        li.setProperty("TotalTime", str(status["total"]))
        li.setProperty("Flixtor.ResumeText", "%s remaining" % _format_time(
            max(0, status["total"] - status["resume"])))
    li.setProperty("Flixtor.WatchStatus", label)
    return status


def _known_trailer(item):
    """Return a known ID, empty for known absence, or None when unknown."""
    trailer = item.get("trailer") or ""
    if trailer:
        return _youtube_video_id(trailer)
    global _trailer_cache
    if _trailer_cache is None:
        try:
            with open(_api_cache_path(), "r", encoding="utf-8") as source:
                cached = json.load(source)
            _trailer_cache = cached if isinstance(cached, dict) else {}
        except (OSError, ValueError):
            _trailer_cache = {}
    prefix = "movie_" if item.get("media_type", "movie") == "movie" else "show_info:"
    cached = _trailer_cache.get(prefix + str(item.get("pid", "")))
    if not isinstance(cached, dict) or time.time() - cached.get("ts", 0) >= cached.get("ttl", 0):
        return None
    metadata = cached.get("data")
    if not isinstance(metadata, dict) or "trailer" not in metadata:
        return None
    return _youtube_video_id(metadata.get("trailer", ""))


def _media_actions(li, item, scope=None, season=None, episode=None):
    """Expose exact item commands to both Kodi context menus and skin details."""
    pid, slug = str(item.get("pid") or ""), item.get("slug", "")
    if not pid:
        return []
    media_type = item.get("media_type", "movie")
    scope = scope or ("movie" if media_type == "movie" else
                      "episode" if episode is not None else "season" if season is not None else "show")
    title = item.get("title", "")
    if media_type == "tv":
        title = canonical_show_title(title)
    status = _watch_status(pid, media_type, season, episode)
    params = dict(pid=pid, slug=slug, title=title, poster=item.get("poster", ""))
    if scope == "movie":
        action = "resume_movie" if status["resume"] > 0 else "play_movie"
        play_label = "Resume" if status["resume"] > 0 else "Play"
    elif scope == "episode":
        action = "resume_episode" if status["resume"] > 0 else "play_episode"
        params.update(season=season, episode=episode, episode_title=item.get("episode_title", ""))
        play_label = "Resume" if status["resume"] > 0 else "Up Next" if item.get("up_next") else "Play"
    elif scope == "season":
        action, play_label = "episodes", "Browse episodes"
        params["season"] = season
    else:
        action, play_label = "seasons", "Browse seasons"
    play_url = build_url(action, **params)
    play_command = ("ActivateWindow(Videos,%s,return)" if scope in ("show", "season") else "PlayMedia(%s)") % play_url
    similar_url = build_url("recommendations", pid=pid, slug=slug, media_type=media_type)
    mark_params = dict(params, scope=scope)
    for key in ("year", "rating", "genres", "tmdb_id"):
        if item.get(key) not in (None, ""):
            mark_params[key] = item[key]
    watched_action = "RunPlugin(%s)" % build_url("set_watched", watched="true", **mark_params)
    unwatched_action = "RunPlugin(%s)" % build_url("set_watched", watched="false", **mark_params)
    toggle_label = "Mark as Unwatched" if status["completed"] else "Mark as Watched"
    for key, value in {
            "IsMedia": "true", "PlayUrl": play_url, "PlayAction": play_command, "PlayLabel": play_label,
            "SimilarUrl": similar_url, "SimilarAction": "ActivateWindow(Videos,%s,return)" % similar_url,
            "MarkWatchedAction": watched_action, "MarkUnwatchedAction": unwatched_action,
            "WatchedAction": unwatched_action if status["completed"] else watched_action,
            "WatchedLabel": toggle_label}.items():
        li.setProperty("Flixtor." + key, value)
    trailer = _known_trailer(item)
    matched_id = item.get("tmdb_id")
    if trailer is None or trailer or matched_id:
        # A matched TMDb title may offer its own trailer.
        li.setProperty("Flixtor.TrailerLabel", "Trailer" if trailer else "Find trailer")
        li.setProperty("Flixtor.TrailerAction", "RunPlugin(%s)" % build_url(
            "play_trailer", pid=pid, slug=slug, media_type=media_type,
            video_id=trailer or "", tmdb_id=matched_id or ""))
    noun = {"movie": "Movie", "show": "Show", "season": "Season", "episode": "Episode"}[scope]
    watched_entry = ("Mark %s as Watched" % noun, watched_action)
    unwatched_entry = ("Mark %s as Unwatched" % noun, unwatched_action)
    # Offer only a toggle that changes something, as Title details does. A
    # partly watched or not-yet-listed show or season can still go either way.
    if scope in ("movie", "episode"):
        return [unwatched_entry if status["completed"] else watched_entry]
    if status["state"] == "watched":
        return [unwatched_entry]
    if status["state"] == "unwatched":
        return [watched_entry]
    return [watched_entry, unwatched_entry]


def do_set_watched(params):
    """Apply an explicit scoped action; unavailable bulk inventory fails closed."""
    global _watch_state_cache, _watch_inventory_cache
    scope = params.get("scope")
    if scope not in ("movie", "show", "season", "episode") or params.get("watched") not in ("true", "false"):
        xbmcgui.Dialog().notification("Flixtor", "Could not identify this watch action.", xbmcgui.NOTIFICATION_ERROR)
        return
    watched = params["watched"] == "true"
    pid, slug = params.get("pid", ""), params.get("slug", "")
    metadata = {key: params[key] for key in ("title", "slug", "poster", "year", "rating", "genres", "tmdb_id", "episode_title")
                if params.get(key) not in (None, "")}
    # Validate the requested scope before opening stores or looking up any
    # inventory. Missing episode coordinates must never widen to a show action.
    try:
        season = episode = None
        if scope in ("season", "episode"):
            value = params.get("season")
            if isinstance(value, bool) or not str(value).isdigit():
                raise ValueError("Missing season identity")
            season = int(value)
        elif params.get("season") not in (None, ""):
            raise ValueError("Unexpected season identity")
        if scope == "episode":
            value = params.get("episode")
            if isinstance(value, bool) or not str(value).isdigit() or int(value) < 1:
                raise ValueError("Missing episode identity")
            episode = int(value)
        elif params.get("episode") not in (None, ""):
            raise ValueError("Unexpected episode identity")
        if not pid:
            raise ValueError("Missing title identity")
    except ValueError:
        xbmcgui.Dialog().notification("Flixtor", "Could not identify this watch action.", xbmcgui.NOTIFICATION_ERROR)
        return
    history = WatchHistory()
    try:
        if scope in ("show", "season"):
            client = get_client()
            if not client:
                return
            seasons = client.get_seasons(pid, slug)
            # Validate the entire snapshot before recording inventory or state.
            normalize_inventory(seasons)
            history.remember_inventory(pid, seasons, metadata)
        count = history.set_watched(pid, watched, "movie" if scope == "movie" else "tv",
                                    season=season, episode=episode, metadata=metadata)
    except (ValueError, OSError) as exc:
        _log("watch action failed: %s" % type(exc).__name__)
        xbmcgui.Dialog().notification("Flixtor", "Could not update watched status. Please try again.",
                                      xbmcgui.NOTIFICATION_ERROR)
        return
    _watch_state_cache = None
    _watch_inventory_cache = None
    xbmc.executebuiltin("Container.Refresh")
    target = ("Season %s: %d available episodes" % (season, count) if scope == "season" else
              "Show: %d available episodes" % count if scope == "show" else "Title")
    message = "%s marked %s." % (target, "watched" if watched else "unwatched")
    xbmcgui.Dialog().notification("Flixtor", message, xbmcgui.NOTIFICATION_INFO, 2000)


def _log(msg):
    xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)


def _has_youtube():
    """Whether YouTube can be invoked, including after enabling it in Kodi."""
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"))


def _device_key():
    """Stable per-device key derived from MAC address. Used for password obfuscation."""
    global _device_key_cached
    if _device_key_cached is None:
        _device_key_cached = hashlib.sha256(str(uuid.getnode()).encode()).digest()
    return _device_key_cached


def _legacy_deobfuscate(b64):
    """Best-effort reverse of the legacy v1.10-v1.13.x obfuscation. Returns '' on
    any decoding error. Kept only for one-shot migration away from the obfuscated
    form — the new code stores passwords as plaintext (masked in the UI via
    option='hidden'). The obfuscation used `uuid.getnode()` as its key, which on
    Fire TV falls back to a RANDOM value per plugin process when the Android
    sandbox blocks MAC discovery, silently corrupting the stored password."""
    if not b64:
        return ""
    try:
        xored = base64.b64decode(b64.encode("ascii"))
    except Exception:
        return ""
    key = _device_key()
    raw = bytes(b ^ key[i % len(key)] for i, b in enumerate(xored))
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return ""


def _read_password():
    """Read the VIP password from settings.

    Legacy obfuscated values (prefixed with `__obf1__`, written by v1.10-v1.13.x)
    are best-effort recovered and rewritten as plaintext. If recovery fails —
    likely because `uuid.getnode()` returned a different value than when the
    password was encoded — the setting is cleared to force a single re-auth.
    """
    raw = ADDON.getSetting("password") or ""
    if raw.startswith(_OBF_PREFIX):
        decoded = _legacy_deobfuscate(raw[len(_OBF_PREFIX):])
        # Sanity check: a real password is non-empty printable ASCII. Deobfuscation
        # with a mismatched key yields non-printable byte garbage that may still
        # pass the UTF-8 decode in _legacy_deobfuscate.
        if decoded and all(32 <= ord(c) < 127 for c in decoded):
            _log("password: migrated legacy obfuscated value to plaintext")
            ADDON.setSetting("password", decoded)
            return decoded
        _log("password: legacy obfuscated value unrecoverable; clearing (re-auth required)")
        ADDON.setSetting("password", "")
        return ""
    return raw


def _show_qr_dialog():
    """Show a fullscreen dialog with the QR code for flixtor.to/donate."""
    qr_path = os.path.join(ADDON.getAddonInfo("path"), "resources", "qr_donate.png")
    # Create a custom window with the QR code centered and instructions
    window = xbmcgui.WindowDialog()
    # Semi-transparent dark background
    window.addControl(xbmcgui.ControlImage(0, 0, 1920, 1080, "", colorDiffuse="CC000000"))
    # QR code centered (400x400 in the middle of 1280x720)
    qr_size = 400
    qr_x = (1280 - qr_size) // 2
    qr_y = 180
    window.addControl(xbmcgui.ControlImage(qr_x, qr_y, qr_size, qr_size, qr_path))
    # Instructions above
    label1 = xbmcgui.ControlLabel(0, 80, 1280, 60, "Scan with your phone to sign up for Flixtor VIP",
                                   alignment=0x00000002, textColor="FFFFFFFF", font="font14")
    window.addControl(label1)
    # URL below QR
    label2 = xbmcgui.ControlLabel(0, qr_y + qr_size + 30, 1280, 40, "flixtor.to/donate",
                                   alignment=0x00000002, textColor="FF00BFFF", font="font14")
    window.addControl(label2)
    # Dismiss instruction
    label3 = xbmcgui.ControlLabel(0, qr_y + qr_size + 90, 1280, 40, "Press any button to close",
                                   alignment=0x00000002, textColor="FF888888", font="font12")
    window.addControl(label3)
    window.doModal()
    del window


def _show_signup_prompt():
    """Show VIP signup info with pricing tiers, then offer to open settings or show QR code."""
    while True:
        choice = xbmcgui.Dialog().select(
            "Flixtor — VIP Account Required",
            [
                "Enter VIP Credentials (already have an account)",
                "Show QR Code to Sign Up (flixtor.to/donate)",
                "[COLOR grey]VIP Plans:  30 Days $14.95  |  90 Days $29.95  |  180 Days $49.95  |  2 Years $89.95[/COLOR]",
            ],
        )
        if choice == 0:
            ADDON.openSettings()
            break
        elif choice == 1:
            _show_qr_dialog()
            # After QR, loop back to let them enter credentials
        else:
            break


def _clear_stored_credentials():
    """Wipe email, password, persisted cookies, and the API response cache
    (it holds session-fingerprinted warm flags and the previous account's
    browse results). Caller handles _client reset."""
    ADDON.setSetting("email", "")
    ADDON.setSetting("password", "")
    for path in (_cookie_path(), _api_cache_path()):
        try:
            os.remove(path)
        except OSError:
            pass


def do_sign_out():
    """Clear stored credentials, persisted cookies, and the in-memory client."""
    if not xbmcgui.Dialog().yesno("Flixtor", "Sign out of Flixtor on this device?"):
        return
    global _client
    _clear_stored_credentials()
    _client = None
    _log("sign_out: credentials cleared")
    xbmcgui.Dialog().notification("Flixtor", "Signed out.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _handle_auth_failure(detail=""):
    """Prompt the user to fix their sign-in after a failed login.

    When Flixtor's rejection text differs from the plain wrong-credentials
    message, show it verbatim first (e.g. a VIP-expiry notice — exact body
    unknown until it happens, so trust the server's words) plus the
    renewal pointer."""
    if detail and "incorrect email" not in detail.lower():
        xbmcgui.Dialog().ok(
            "Flixtor — Sign-in failed",
            "%s\n\nIf your VIP expired, renew at flixtor.to/donate." % detail)
    choice = xbmcgui.Dialog().select(
        "Sign-in failed",
        [
            "Update email or password",
            "Sign in with a different account",
        ],
    )
    if choice == 0:
        ADDON.openSettings()
    elif choice == 1:
        _clear_stored_credentials()
        ADDON.openSettings()


def do_backup_library():
    from resources.lib.librarybackup import export_library
    folder = xbmcgui.Dialog().browseSingle(3, "Choose backup folder", "files")
    if not folder:
        return
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    try:
        payload = export_library(profile)
        name = "Flixtor-library-%s-%s.json" % (time.strftime("%Y%m%d-%H%M%S"), uuid.uuid4().hex[:8])
        destination = folder.rstrip("/\\") + "/" + name
        target = xbmcvfs.File(destination, "w")
        try:
            if not target.write(payload.decode("utf-8")):
                raise OSError("Backup write failed")
        finally:
            target.close()
        verify = xbmcvfs.File(destination)
        try:
            if bytes(verify.readBytes()) != payload:
                raise OSError("Backup readback failed")
        finally:
            verify.close()
        xbmcgui.Dialog().ok("Library backup saved", name)
    except Exception:
        xbmcgui.Dialog().ok("Backup failed", "Could not save and verify the backup. Your library has not changed.")


def do_restore_library():
    from resources.lib.librarybackup import restore_library, validate_backup, MAX_BACKUP_BYTES
    source = xbmcgui.Dialog().browseSingle(1, "Choose Flixtor library backup", "files", mask=".json")
    if not source:
        return
    try:
        handle = xbmcvfs.File(source)
        try:
            if handle.size() > MAX_BACKUP_BYTES:
                raise ValueError("Backup too large")
            payload = bytes(handle.readBytes(MAX_BACKUP_BYTES + 1))
        finally:
            handle.close()
        data = validate_backup(payload)
        if not xbmcgui.Dialog().yesno("Restore library backup",
                "Merge %d favorites and %d history records? Newer local progress is preserved. A recovery backup is saved first." %
                (len(data["favorites"]), len(data["watch_history"]))):
            return
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
        result = restore_library(profile, payload)
        xbmcgui.Dialog().ok("Library restored", "%d favorites and %d recent history records are available." %
                           (result["favorites"], result["watch_history"]))
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        xbmcgui.Dialog().ok("Restore failed", "The backup could not be restored. Existing library data and the recovery backup have been preserved.")


def do_health_check():
    from resources.lib.healthchecks import run_checks
    client = FlixtorClient(ADDON.getSetting("email"), ADDON.getSetting("password"))
    client.request_timeout = 5
    client._get_cached = lambda *_: None
    client._set_cached = lambda _key, data, *_args, **_kwargs: data
    client._ensure_login = lambda: None
    client._relogin = lambda: False
    monitor = xbmc.Monitor()
    dialog = xbmcgui.DialogProgress()
    dialog.create("Flixtor health check", "Checking connections...")
    cancelled = lambda: dialog.iscanceled() or monitor.abortRequested()
    def voice_probe():
        return voicebridge.request_input(_launch_voice_keyboard, mode="probe",
            accept_timeout=8.0, response_timeout=5.0, stop_requested=cancelled)
    try:
        results = run_checks(client,
            metadata_probe=lambda: TmdbClient()._search_online("Inception", "2010", "movie") is not None,
            voice_probe=voice_probe if _is_android() else None,
            allow_voice=lambda: not xbmc.Player().isPlaying(), cancelled=cancelled,
            progress=lambda percent, name: dialog.update(percent, "Checking " + name))
    finally:
        dialog.close()
    text = "Flixtor %s\n\n" % ADDON.getAddonInfo("version")
    text += "\n\n".join("%s: %s\n%s" % (r["name"], r["status"].upper(), r["detail"]) for r in results)
    xbmcgui.Dialog().textviewer("Flixtor health check", text)


def do_clear_watch_history():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your watch history? This can't be undone."):
        return
    WatchHistory().clear_all()
    _log("clear_watch_history: done")
    xbmcgui.Dialog().notification("Flixtor", "Watch history cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_favorites():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your favorites? This can't be undone."):
        return
    FavoritesHistory().clear_all()
    _log("clear_favorites: done")
    xbmcgui.Dialog().notification("Flixtor", "Favorites cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_searches():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear your search history? This can't be undone."):
        return
    SearchHistory().clear_all()
    _refresh_search_history()
    _log("clear_searches: done")
    xbmcgui.Dialog().notification("Flixtor", "Search history cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def do_clear_tmdb_cache():
    if not xbmcgui.Dialog().yesno("Flixtor", "Clear cached TMDb lookups? Rating badges will refresh on next browse."):
        return
    TmdbClient().clear_cache()
    _log("clear_tmdb_cache: done")
    xbmcgui.Dialog().notification("Flixtor", "TMDb cache cleared.",
                                  xbmcgui.NOTIFICATION_INFO, 2000)


def _counted(count, singular, plural):
    return "{:,} {}".format(count, singular if count == 1 else plural)


def do_show_cache_usage():
    """Settings > Maintenance > "View cache storage usage" — per-cache
    breakdown in a monospace textviewer, plus auto-clean status."""
    progress = xbmcgui.DialogProgressBG()
    progress.create("Flixtor", "Measuring caches...")
    try:
        report = cachemaint.measure_usage(
            progress=lambda done, total: progress.update(int(done * 100 / max(total, 1))))
    finally:
        progress.close()

    lines = []
    total = 0

    def row(label, size, detail=""):
        text = "%-28s %9s" % (label, size)
        lines.append(text + ("   " + detail if detail else ""))

    images = report.get("images")
    if images is None:
        row("Poster images (Kodi cache)", "n/a")
    else:
        count, size = images
        total += size
        row("Poster images (Kodi cache)", cachemaint.format_size(size),
            _counted(count, "image", "images"))
    count, size = report.get("tmdb", (0, 0))
    total += size
    row("TMDb rating cache", cachemaint.format_size(size),
        _counted(count, "entry", "entries"))
    count, size = report.get("subtitles", (0, 0))
    total += size
    row("Subtitle files", cachemaint.format_size(size),
        _counted(count, "file", "files"))
    count, size = report.get("packages", (0, 0))
    total += size
    row("Update zips (Kodi packages)", cachemaint.format_size(size),
        _counted(count, "zip", "zips"))
    size = report.get("other", 0)
    total += size
    row("History & settings data", cachemaint.format_size(size))
    lines.append("-" * 40)
    row("Total", cachemaint.format_size(total))
    lines.append("")

    if ADDON.getSetting("auto_cache_cleanup") != "false":
        lines.append("Auto-clean: on (daily). Removes posters unused")
        lines.append("30+ days, expired TMDb entries, week-old")
        lines.append("subtitles, and superseded update zips.")
    else:
        lines.append("Auto-clean: OFF (enable in Settings > General).")
    ts, stats = cachemaint.last_auto_run()
    if ts:
        freed = (stats.get("images_bytes", 0) + stats.get("subtitles_bytes", 0)
                 + stats.get("packages_bytes", 0))
        lines.append("Last auto-clean: %s — freed %s" % (
            time.strftime("%a %b %d, %H:%M", time.localtime(ts)),
            cachemaint.format_size(freed)))
    else:
        lines.append("Last auto-clean: not yet run (runs ~60s after")
        lines.append("Kodi starts).")

    _log("cache_usage: total=%d" % total)
    xbmcgui.Dialog().textviewer("Flixtor — Cache storage", "\n".join(lines), True)


def do_clear_image_cache():
    if not xbmcgui.Dialog().yesno(
            "Flixtor",
            "Remove all cached poster images? They re-download as you browse."):
        return
    progress = xbmcgui.DialogProgressBG()
    progress.create("Flixtor", "Clearing cached images...")

    def update(done, total):
        progress.update(int(done * 100 / max(total, 1)),
                        message="Removed %d of %d images" % (done, total))

    try:
        removed, freed = cachemaint.purge_all_images(progress=update)
    finally:
        progress.close()
    _log("clear_image_cache: removed=%d freed=%d" % (removed, freed))
    if removed:
        msg = "Removed %s (%s)." % (_counted(removed, "image", "images"),
                                    cachemaint.format_size(freed))
    else:
        msg = "No cached images to remove."
    xbmcgui.Dialog().notification("Flixtor", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def do_clear_subtitles():
    if not xbmcgui.Dialog().yesno(
            "Flixtor",
            "Remove downloaded subtitle files? They re-download when you play with subtitles on."):
        return
    removed, freed = cachemaint.purge_all_subtitles()
    _log("clear_subtitles: removed=%d freed=%d" % (removed, freed))
    if removed:
        msg = "Removed %s (%s)." % (_counted(removed, "subtitle file", "subtitle files"),
                                    cachemaint.format_size(freed))
    else:
        msg = "No subtitle files to remove."
    xbmcgui.Dialog().notification("Flixtor", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def do_clear_update_zips():
    if not xbmcgui.Dialog().yesno(
            "Flixtor",
            "Remove cached addon update zips? Kodi re-downloads them from the repo when needed."):
        return
    removed, freed = cachemaint.purge_all_packages()
    _log("clear_update_zips: removed=%d freed=%d" % (removed, freed))
    if removed:
        msg = "Removed %s (%s)." % (_counted(removed, "zip", "zips"),
                                    cachemaint.format_size(freed))
    else:
        msg = "No cached update zips to remove."
    xbmcgui.Dialog().notification("Flixtor", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def do_check_updates():
    """Refresh enabled Kodi repositories using Kodi's native update system."""
    _log("check_updates: requesting enabled repository refresh")
    xbmcgui.Dialog().notification(
        "Flixtor",
        "Checking for updates. Kodi will install any available version according to its update settings.",
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )
    xbmc.executebuiltin("UpdateAddonRepos")


def _saved_playback_settings():
    memory = ADDON.getSetting(_PLAYBACK_SETUP_ORIGINAL_MEMORY)
    read_factor = ADDON.getSetting(_PLAYBACK_SETUP_ORIGINAL_READ_FACTOR)
    if not memory or not read_factor:
        return None
    try:
        return {
            playbacksetup.MEMORY_SETTING: int(memory),
            playbacksetup.READ_FACTOR_SETTING: int(read_factor),
        }
    except (TypeError, ValueError):
        return None


def _remember_playback_settings(values):
    """Save the pre-Flixtor values once so Restore remains truthful."""
    if _saved_playback_settings() is not None:
        return
    ADDON.setSetting(
        _PLAYBACK_SETUP_ORIGINAL_MEMORY,
        str(values[playbacksetup.MEMORY_SETTING]),
    )
    ADDON.setSetting(
        _PLAYBACK_SETUP_ORIGINAL_READ_FACTOR,
        str(values[playbacksetup.READ_FACTOR_SETTING]),
    )


def _playback_settings_text(values):
    return "\n".join(playbacksetup.summary_lines(values))


def do_optimize_playback(automatic=False):
    """Offer and apply reversible Kodi-wide caching recommendations."""
    if automatic and ADDON.getSetting(_PLAYBACK_SETUP_STATE):
        return
    try:
        current = playbacksetup.read_cache_settings()
    except playbacksetup.KodiSettingsError as exc:
        _log("playback setup unavailable: %s" % exc)
        if automatic:
            ADDON.setSetting(_PLAYBACK_SETUP_STATE, "unsupported")
        else:
            xbmcgui.Dialog().ok(
                "Playback optimization unavailable",
                "This Kodi version does not expose the supported cache controls. "
                "Flixtor's adaptive video quality will still work when InputStream "
                "Adaptive is available.",
            )
        return

    if playbacksetup.cache_is_optimized(current):
        ADDON.setSetting(_PLAYBACK_SETUP_STATE, "applied")
        if not automatic:
            xbmcgui.Dialog().ok(
                "Kodi playback is optimized",
                "%s\n\nNo changes were needed." % _playback_settings_text(current),
            )
        return

    message = (
        "Flixtor can adjust two Kodi-wide cache settings to reduce pauses "
        "during temporary Wi-Fi or video-server slowdowns.\n\n"
        "Current\n%s\n\nRecommended\n%s\n\n"
        "This affects playback in every Kodi add-on and can be reversed from "
        "Flixtor settings."
        % (
            _playback_settings_text(current),
            _playback_settings_text(playbacksetup.RECOMMENDED_VALUES),
        )
    )
    if not xbmcgui.Dialog().yesno(
            "Optimize Kodi playback?", message,
            nolabel="Not now", yeslabel="Optimize"):
        if automatic:
            # Prompt only once. The Maintenance action remains available.
            ADDON.setSetting(_PLAYBACK_SETUP_STATE, "declined")
        return

    _remember_playback_settings(current)
    try:
        result = playbacksetup.apply_recommended()
    except playbacksetup.KodiSettingsError as exc:
        ADDON.setSetting(_PLAYBACK_SETUP_STATE, "failed")
        _log("playback setup failed: %s" % exc)
        xbmcgui.Dialog().ok(
            "Could not optimize playback",
            "Kodi did not accept both cache settings, so Flixtor restored the "
            "previous values. Nothing else was changed.",
        )
        return

    ADDON.setSetting(_PLAYBACK_SETUP_STATE, "applied")
    _log("playback setup applied: changed=%s" % result["changed"])
    xbmcgui.Dialog().ok(
        "Kodi playback optimized",
        "%s\n\nThe settings will be used for your next video."
        % _playback_settings_text(result["after"]),
    )


def do_restore_playback():
    """Restore the exact Kodi cache values saved before optimization."""
    originals = _saved_playback_settings()
    if originals is None:
        xbmcgui.Dialog().ok(
            "Nothing to restore",
            "Flixtor has no previous Kodi playback settings saved on this device.",
        )
        return
    try:
        current = playbacksetup.read_cache_settings()
    except playbacksetup.KodiSettingsError as exc:
        _log("playback restore unavailable: %s" % exc)
        xbmcgui.Dialog().ok(
            "Could not restore playback settings",
            "Kodi's cache controls are unavailable on this device.",
        )
        return

    if current == originals:
        ADDON.setSetting(_PLAYBACK_SETUP_STATE, "restored")
        xbmcgui.Dialog().ok(
            "Kodi settings already restored",
            _playback_settings_text(current),
        )
        return
    if not playbacksetup.cache_is_optimized(current):
        # Someone changed Kodi after Flixtor's setup. Never overwrite their
        # newer choice under the guise of restoring an older snapshot.
        xbmcgui.Dialog().ok(
            "Kodi settings were changed",
            "These cache settings no longer match Flixtor's recommendations, "
            "so Flixtor will not overwrite them.",
        )
        return
    if not xbmcgui.Dialog().yesno(
            "Restore previous Kodi settings?",
            "Current\n%s\n\nRestore\n%s"
            % (_playback_settings_text(current),
               _playback_settings_text(originals)),
            nolabel="Cancel", yeslabel="Restore"):
        return
    try:
        result = playbacksetup.apply_cache_values(originals)
    except playbacksetup.KodiSettingsError as exc:
        _log("playback restore failed: %s" % exc)
        xbmcgui.Dialog().ok(
            "Could not restore playback settings",
            "Kodi did not accept both saved values. Flixtor left the current "
            "settings in place.",
        )
        return
    ADDON.setSetting(_PLAYBACK_SETUP_STATE, "restored")
    _log("playback setup restored: changed=%s" % result["changed"])
    xbmcgui.Dialog().ok(
        "Kodi playback settings restored",
        _playback_settings_text(result["after"]),
    )


def get_client(quiet=False, defer_login=False):
    global _client
    if _client is None:
        email = ADDON.getSetting("email")
        password = _read_password()
        if (not email or not password) and not quiet:
            _show_signup_prompt()
            email = ADDON.getSetting("email")
            password = _read_password()
        if not email or not password:
            return None
        if defer_login:
            # Listing routes check their cache before authenticating and
            # report service failures in their own window.
            return FlixtorClient(email, password)
        _client = FlixtorClient(email, password)
        login_result = _client.login()
        if login_result == "network_error":
            _log("get_client: login network error")
            if not quiet:
                xbmcgui.Dialog().ok("Flixtor", "Could not connect to Flixtor. Check your internet or try again later.")
            _client = None
        elif not login_result:
            _log("get_client: login failed (bad credentials)")
            detail = getattr(_client, "last_login_error", "")
            _client = None
            if not quiet:
                _handle_auth_failure(detail)
    return _client


def build_url(action, **kwargs):
    if str(action).startswith("widget_"):
        # Items listed inside a Home widget must open the normal route.
        action = str(action)[len("widget_"):]
    kwargs["action"] = action
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def _attach_flixtor_context(li, entries):
    """Store exact Flixtor actions for keyboard, pointer, and remote menus.

    Kodi always appends core actions such as Queue, Kodi favourites, and
    Play from here even when ``replaceItems=True`` is requested.  The custom
    keymap reads this property and shows only these add-on-owned actions.
    ``addContextMenuItems`` remains a fallback for other invocation paths.

    Every title menu uses one order, matching the Title details buttons:
    playback and navigation first, then discovery, favourites, watched state
    and history housekeeping. Unknown entries keep their place at the end.
    """
    def rank(label):
        if label.startswith("Resume "):
            return 0
        fixed = {"Go to Show": 1, "Play from Beginning": 2, "Watch Trailer": 3,
                 "Similar Titles": 4, "Add to Flixtor Favorites": 5,
                 "Remove from Flixtor Favorites": 5, "Remove from History": 8,
                 "Remove Show from History": 8}
        if label in fixed:
            return fixed[label]
        if label.startswith("Mark "):
            return 7 if label.endswith(" as Unwatched") else 6
        return 9

    safe_entries = sorted((
        [str(label), str(command)]
        for label, command in (entries or [])
        if label and command
    ), key=lambda entry: rank(entry[0]))
    for label, command in safe_entries:
        if label in ("Add to Flixtor Favorites", "Remove from Flixtor Favorites"):
            li.setProperty("Flixtor.FavoriteLabel", "Add to favorites" if label.startswith("Add") else "Remove favorite")
            li.setProperty("Flixtor.FavoriteAction", command)
            break
    li.setProperty(
        "Flixtor.Context",
        json.dumps(safe_entries, ensure_ascii=False, separators=(",", ":")),
    )
    li.addContextMenuItems([(label, command) for label, command in safe_entries],
                           replaceItems=True)


# ── Main menu ────────────────────────────────────────────────────────

def main_menu():
    # Continue Watching band: one card per distinct title (deduped by pid),
    # capped at CONTINUE_WATCHING_MAX. Each card is the show's newest active
    # episode — an in-progress "Resume" or a queued "Up Next" (the successor of
    # an episode you just finished). Kodi focuses the first item on launch, so
    # power-on → auto-launch → one click resumes the last thing you watched.
    band = [("Up Next" if rec.get("up_next") and not rec.get("resume_seconds") else "Resume", rec)
            for rec in _continue_records(WatchHistory().get_all(), limit=CONTINUE_WATCHING_MAX)]
    for kind, rec in band:
        url, li = _build_resume_item(rec)
        li.setLabel("[B]%s[/B]  %s" % (kind, li.getLabel()))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    items = [
        ("Recently Watched", build_url("recent"), "recent",
         "Return to movies and TV shows you have watched recently."),
        ("Favorites", build_url("favorites"), "favorites",
         "Browse titles saved to Flixtor Favorites. Use a title's context menu to add or remove it."),
        ("Search", build_url("search"), "search",
         "Find a movie or TV show by title, or run a recent search again."),
        ("Movies", build_url("movies"), "movies",
         "Explore movie releases, recently added titles, best rated movies, and genres."),
        ("TV Shows", build_url("tvshows"), "tvshows",
         "Explore TV shows by release date, recently added, rating, or genre."),
        ("Browse All", build_url("home"), "browse_all",
         "Browse the current selection of movies and TV shows together."),
    ]
    for label, url, card_slug, description in items:
        li = xbmcgui.ListItem(label)
        li.setArt(_card_art(card_slug))
        _set_navigation_info(li, label, description)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setPluginCategory(HANDLE, "Flixtor")
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)
    _maybe_show_update_notice()


def _maybe_schedule_playback_setup():
    """Offer Kodi-wide tuning once, after the root view has settled."""
    if ADDON.getSetting(_PLAYBACK_SETUP_STATE):
        _log("playback setup already handled")
        return
    setup_url = build_url("playback_setup")
    xbmc.executebuiltin("CancelAlarm(FlixtorPlaybackSetup,true)")
    xbmc.executebuiltin(
        "AlarmClock(FlixtorPlaybackSetup,RunPlugin(%s),00:00:02,silent)"
        % setup_url
    )
    _log("scheduled first-run playback setup")


def _maybe_show_update_notice():
    """Schedule the curated notice after Kodi finishes rendering the root."""
    version = _installed_addon_version()
    if ADDON.getSetting("last_update_notice_version") == version:
        _log("update notice already shown for v%s" % version)
        _maybe_schedule_playback_setup()
        return

    notice = _release_notice_for_version(version)
    if not notice:
        # Private/intermediate versions without curated notes stay silent.
        _maybe_schedule_playback_setup()
        return

    # A modal dialog opened directly after endOfDirectory races AH2's folder
    # transition and can be discarded without ever becoming visible. Launch a
    # separate plug-in action after the view has settled instead.
    notice_url = build_url("show_update_notice", version=version)
    xbmc.executebuiltin("CancelAlarm(FlixtorUpdateNotice,true)")
    xbmc.executebuiltin(
        "AlarmClock(FlixtorUpdateNotice,RunPlugin(%s),00:00:02,silent)"
        % notice_url
    )
    _log("scheduled update notice for v%s" % version)


def _installed_addon_version():
    """Read the installed manifest so a hot update cannot use stale metadata."""
    addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
    manifest_path = os.path.join(addon_path, "addon.xml")
    try:
        return str(ET.parse(manifest_path).getroot().get("version") or "")
    except (ET.ParseError, OSError, TypeError, ValueError) as exc:
        _log("manifest version unavailable: %s" % exc)
        return str(ADDON.getAddonInfo("version") or "")


def _release_notice_for_version(version):
    """Return a curated notice, or None for silent/intermediate builds."""
    notice_path = os.path.join(
        xbmcvfs.translatePath(ADDON.getAddonInfo("path")),
        "resources",
        "release_notices.json",
    )
    try:
        with open(notice_path, "r", encoding="utf-8") as notice_file:
            return json.load(notice_file).get(version)
    except (OSError, TypeError, ValueError) as exc:
        _log("update notice unavailable: %s" % exc)
        return None


def _show_update_notice(expected_version=""):
    """Show and record one notice from the delayed utility action."""
    version = _installed_addon_version()
    if expected_version and expected_version != version:
        _log(
            "ignored stale update notice for v%s; installed v%s"
            % (expected_version, version)
        )
        return
    if ADDON.getSetting("last_update_notice_version") == version:
        _log("update notice already shown for v%s" % version)
        _maybe_schedule_playback_setup()
        return

    notice = _release_notice_for_version(version)
    if not notice:
        _maybe_schedule_playback_setup()
        return

    heading = str(notice.get("heading") or "Flixtor updated")
    message = str(notice.get("message") or "").strip()
    if not message:
        _maybe_schedule_playback_setup()
        return
    _log("showing update notice for v%s" % version)
    xbmcgui.Dialog().ok("%s to v%s" % (heading, version), message)
    ADDON.setSetting("last_update_notice_version", version)
    _log("update notice acknowledged for v%s" % version)
    _maybe_schedule_playback_setup()


def exit_flixtor():
    """Leave the add-on deliberately while bypassing its root Back guard."""
    set_parent_folder_items(True)
    window = xbmcgui.Window(10000)
    window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    window.setProperty(
        ROOT_EXIT_ALLOW_PROPERTY, str(time.time() + 5)
    )
    xbmc.executebuiltin("ActivateWindow(Home)")


def exit_kodi():
    """Close Kodi after explicit confirmation."""
    if not xbmcgui.Dialog().yesno(
            "Exit Kodi?", "Close Kodi and return to the Fire TV home screen?"):
        return
    set_parent_folder_items(True)
    window = xbmcgui.Window(10000)
    window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    window.setProperty(
        ROOT_EXIT_ALLOW_PROPERTY, str(time.time() + 5)
    )
    xbmc.executebuiltin("Quit")


def _add_empty_hint(heading, message):
    """Friendly placeholder for an empty Favorites/Recently Watched list —
    links into the Movies picker instead of toasting over a blank screen."""
    li = xbmcgui.ListItem("Browse Movies")
    li.setArt(_card_art("browse_all"))
    _set_navigation_info(li, "Browse Movies", message, title=heading, empty=True)
    xbmcplugin.setPluginCategory(HANDLE, heading)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.addDirectoryItem(HANDLE, build_url("movies"), li, isFolder=True)


# ── Search ────────────────────────────────────────────────────────────

def _refresh_search_history():
    """Reload Home's query row after a successful history write."""
    xbmcgui.Window(10000).setProperty(SEARCH_HISTORY_VERSION_PROPERTY, str(time.time_ns()))


def _add_search_history_items():
    """Render saved queries without starting input or changing route state."""
    for query in SearchHistory().get_all():
        url = build_url("search_execute", q=query)
        li = xbmcgui.ListItem(query)
        li.setArt(_card_art("search"))
        _set_navigation_info(li, query, 'Search again for "%s".' % query)
        li.addContextMenuItems([
            ("Remove from Search History",
             "RunPlugin(%s)" % build_url("remove_search", q=query)),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def show_search_history():
    """Quiet query-only feed; an empty history deliberately has no actions."""
    _add_search_history_items()
    xbmcplugin.setPluginCategory(HANDLE, "Recent Searches")
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def do_search():
    """Show the legacy search menu for skins without Flixtor Home."""
    # ``new_search`` owns its result directory in legacy skins. Reaching its
    # parent ends the session so the next New Search opens a fresh keyboard.
    xbmcgui.Window(10000).clearProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
    li = xbmcgui.ListItem("New Search...")
    li.setArt(_card_art("search"))
    _set_navigation_info(li, "New Search", "Enter a movie or TV show title to search Flixtor.")
    xbmcplugin.addDirectoryItem(HANDLE, build_url("new_search"), li, isFolder=True)
    _add_search_history_items()
    xbmcplugin.setPluginCategory(HANDLE, "Search")
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


def _collect_search_query(initial_query=""):
    """Return a query from the configured keyboard, or None after cancellation."""
    _offer_voice_recovery()
    query = None
    # Editing retains the existing text in Kodi's keyboard. New searches
    # keep the configured Fire TV voice flow without putting text in intents.
    if not initial_query and _voice_keyboard_enabled():
        result = _request_voice_keyboard("search")
        if result["status"] == "query":
            query = result["query"]
        elif result["status"] == "cancel":
            return None
        else:
            # Failure affects this attempt only; preserve the user preference.
            xbmcgui.Dialog().notification(
                "Flixtor",
                "Voice keyboard unavailable — using the Kodi keyboard.",
                xbmcgui.NOTIFICATION_WARNING,
                3500,
            )
    if query is None:
        query = _kodi_keyboard_query(initial_query)
    return query or None


def do_search_input(initial_query=""):
    """Home command: collect input, then open a non-interactive results route."""
    query = _collect_search_query(initial_query)
    if query:
        # Search also appears inside video details and its quick-navigation
        # context menu. Close only those overlays after confirmation, otherwise
        # the new results load behind them. Cancellation preserves the dialog.
        for dialog in ("contextmenu", "movieinformation"):
            if xbmc.getCondVisibility("Window.IsVisible(%s)" % dialog):
                xbmc.executebuiltin("Dialog.Close(%s,true)" % dialog, True)
        xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" %
                            build_url("search_execute", q=query))


def do_play_next_episode(params):
    """Submit a current-playback request without changing its directory."""
    window = xbmcgui.Window(10000)
    session = params.get("session", "")
    if (session and window.getProperty("Flixtor.NextEpisodeAvailable") == "true"
            and session == window.getProperty("Flixtor.NextEpisodeSession")):
        window.setProperty("Flixtor.NextEpisodeRequest", session)


def do_new_search(initial_query=""):
    """Legacy directory input; playback reloads restore its existing results."""
    route_window = xbmcgui.Window(10000)
    active_query = route_window.getProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
    if active_query:
        # Playback completion rebuilds its owning Kodi directory. Re-render
        # results instead of treating the reload as another keyboard request.
        _log("search: restoring active result set after container reload")
        if not _do_search_execute(active_query, save=False, page=1):
            route_window.clearProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
        return
    query = _collect_search_query(initial_query)
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if _do_search_execute(query, save=True, page=1):
        # This is process-memory only; no query enters an Android intent or log.
        route_window.setProperty(ACTIVE_SEARCH_QUERY_PROPERTY, query)


def _offer_voice_recovery():
    if (_is_android() and ADDON.getSetting("voice_keyboard_enabled") == "false"
            and ADDON.getSetting("voice_helper_version")
            and ADDON.getSetting("voice_recovery_offered") != "true"):
        ADDON.setSetting("voice_recovery_offered", "true")
        if xbmcgui.Dialog().yesno("Restore Fire TV voice search?",
                "A previous companion failure may have disabled voice search. Try it again?",
                yeslabel="Recover voice", nolabel="Keep Kodi keyboard"):
            ADDON.setSetting("voice_keyboard_enabled", "true")


def _kodi_keyboard_query(initial_query=""):
    """Return text from Kodi's built-in keyboard, or an empty string."""
    kb = xbmc.Keyboard(initial_query, "Search Flixtor")
    kb.doModal()
    if not kb.isConfirmed():
        return ""
    return kb.getText().strip()


def _is_android():
    try:
        return bool(xbmc.getCondVisibility("System.Platform.Android"))
    except (AttributeError, RuntimeError):
        return False


def _voice_keyboard_enabled():
    return _is_android() and ADDON.getSetting("voice_keyboard_enabled") == "true"


def _launch_voice_keyboard(uri):
    """Open the optional Android companion with no query text in the intent."""
    command = "StartAndroidActivity(%s,android.intent.action.VIEW,,%s)" % (
        voicebridge.PACKAGE_NAME,
        uri,
    )
    xbmc.executebuiltin(command)


def _request_voice_keyboard(mode):
    monitor = xbmc.Monitor()
    result = voicebridge.request_input(
        _launch_voice_keyboard,
        mode=mode,
        accept_timeout=8.0,
        response_timeout=180.0 if mode == "search" else 5.0,
        stop_requested=monitor.abortRequested,
    )
    if result.get("version_name"):
        ADDON.setSetting("voice_helper_version", result["version_name"])
    # Deliberately omit the query from logs. Status and compatibility details
    # are sufficient to diagnose bridge failures without retaining searches.
    _log(
        "voice keyboard: mode=%s status=%s version=%s detail=%s"
        % (
            mode,
            result.get("status", ""),
            result.get("version_name", ""),
            result.get("detail", ""),
        )
    )
    return result


def _android_package_installed(package_name):
    """Use Kodi's Android-app VFS instead of private Android APIs."""
    if not _is_android():
        return False
    try:
        return bool(
            xbmcvfs.exists(
                "androidapp://sources/apps/%s.png" % package_name
            )
        )
    except (AttributeError, RuntimeError):
        return False


def _start_android_view(package_name, uri):
    command = "StartAndroidActivity(%s,android.intent.action.VIEW,,%s)" % (
        package_name,
        uri,
    )
    xbmc.executebuiltin(command)


def _voice_release_size_label(size_bytes):
    if not size_bytes:
        return "a small download"
    if size_bytes < 1024 * 1024:
        return "%d KB" % max(1, (size_bytes + 1023) // 1024)
    return "%.1f MB" % (size_bytes / float(1024 * 1024))


def _offer_downloader_install():
    """Guide the one-time prerequisite without making users hunt for it."""
    if not xbmcgui.Dialog().yesno(
        "One-time Fire TV setup",
        "Fire TV requires the free Downloader app to approve companion-app "
        "installs. Flixtor can open its Amazon Appstore page now.\n\n"
        "After Downloader is installed, return here and choose "
        "Set up / update Alexa voice search again.",
        yeslabel="Open Appstore",
        nolabel="Not now",
    ):
        return
    _start_android_view(
        voicebridge.AMAZON_APPSTORE_PACKAGE,
        voicebridge.DOWNLOADER_STORE_URI,
    )


def do_setup_voice_keyboard():
    """Check, install, repair, or update the Fire TV voice companion."""
    if not _is_android():
        xbmcgui.Dialog().ok(
            "Fire TV voice keyboard",
            "This optional keyboard is available only on Android-based Fire TV devices.",
        )
        return

    # The companion deliberately has no launcher icon, so Kodi's Android-app
    # VFS does not list it. Probe the authenticated loopback bridge instead;
    # this detects both installation and whether the helper actually works.
    result = _request_voice_keyboard("probe")
    current_version = ADDON.getSetting("voice_helper_version")
    if result.get("version_name"):
        current_version = result["version_name"]
    companion_installed = (
        result.get("status") == "ready" or bool(current_version)
    )

    try:
        release = voicebridge.fetch_release_metadata()
    except Exception as exc:
        _log("voice setup: release check failed: %s" % exc)
        if result and result["status"] == "ready":
            ADDON.setSetting("voice_keyboard_enabled", "true")
            xbmcgui.Dialog().ok(
                "Alexa voice search is connected",
                "The companion connected. Dictation has not been tested. Flixtor could not check "
                "for updates right now, so please try again later.",
            )
        else:
            xbmcgui.Dialog().ok(
                "Alexa voice search setup",
                "Flixtor could not reach the official companion repository. "
                "Check the Fire TV network connection and try again.",
            )
        return

    latest_version = release["version"]
    current_key = voicebridge.version_key(current_version)
    latest_key = voicebridge.version_key(latest_version)
    if (
        result
        and result["status"] == "ready"
        and current_key
        and current_key >= latest_key
    ):
        ADDON.setSetting("voice_keyboard_enabled", "true")
        xbmcgui.Dialog().ok(
            "Alexa voice search is ready",
            "The voice companion is connected and up to date. Dictation has not been tested.\n\n"
            "Selecting Search will now open the Fire TV keyboard. "
            "Type with the remote or hold the Alexa button to dictate.",
        )
        return

    if not _android_package_installed(voicebridge.DOWNLOADER_PACKAGE):
        _offer_downloader_install()
        return

    if result and result["status"] == "ready":
        heading = "Update Alexa voice search"
        prompt = (
            "An Alexa voice search update is available (%s).\n\n"
            "Flixtor will download it automatically. Fire TV "
            "will then ask you to choose Install."
            % (
                _voice_release_size_label(release.get("bytes")),
            )
        )
        yes_label = "Update"
    elif companion_installed:
        heading = "Repair Alexa voice search"
        prompt = (
            "Alexa voice search did not respond. Flixtor can download "
            "a fresh copy (%s) and reopen the Fire "
            "TV installer.\n\nYour Flixtor account and watch history are "
            "not affected."
            % (
                _voice_release_size_label(release.get("bytes")),
            )
        )
        yes_label = "Repair"
    else:
        heading = "Set up Alexa voice search"
        prompt = (
            "Flixtor will download the optional Alexa voice search helper "
            "(%s). Fire TV will then show its own installation screen; "
            "choose Install there to finish.\n\nThe companion only opens "
            "the Fire TV keyboard for Flixtor search."
            % (
                _voice_release_size_label(release.get("bytes")),
            )
        )
        yes_label = "Continue"

    if not xbmcgui.Dialog().yesno(
        heading,
        prompt,
        yeslabel=yes_label,
        nolabel="Not now",
    ):
        return

    try:
        downloader_uri = voicebridge.build_downloader_uri(
            release["download_url"]
        )
    except voicebridge.ReleaseMetadataError as exc:
        _log("voice setup: unsafe release handoff rejected: %s" % exc)
        xbmcgui.Dialog().ok(
            "Alexa voice search setup",
            "The published companion download did not pass Flixtor's "
            "safety checks. Nothing was downloaded.",
        )
        return

    # Downloader owns Fire OS's package-install permission. Stock Kodi does
    # not, so direct PackageInstaller intents are rejected before any prompt.
    # The deep link fills the verified URL, downloads it, and opens Fire OS's
    # required confirmation screen without exposing a manual address-entry step.
    ADDON.setSetting("voice_keyboard_enabled", "true")
    xbmcgui.Dialog().notification(
        "Flixtor",
        "Preparing Alexa voice search...",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )
    _start_android_view(voicebridge.DOWNLOADER_PACKAGE, downloader_uri)


def do_test_voice_keyboard():
    """Backward-compatible route used by pre-setup-action settings files."""
    do_setup_voice_keyboard()


def _listing_error_text(result):
    code = (result.get("error") or {}).get("code", "network")
    return {"network": "Kodi could not reach Flixtor. Try again in a moment.",
            "service_refused": "Flixtor declined the request (HTTP 403). Try again later.",
            "auth": "Your Flixtor session expired. Check your account settings.",
            "invalid_response": "Flixtor returned an unexpected page. Please retry."}.get(code, "Could not load this page.")


def _listing_error_message(result, retry_url=""):
    code = (result.get("error") or {}).get("code", "network")
    message = _listing_error_text(result)
    if retry_url:
        if xbmcgui.Dialog().yesno("Flixtor", message, yeslabel="Account settings" if code == "auth" else "Retry", nolabel="Cancel"):
            if code == "auth":
                ADDON.openSettings()
            else:
                xbmc.executebuiltin("Container.Update(%s)" % retry_url)
    else:
        xbmcgui.Dialog().notification("Flixtor", message, xbmcgui.NOTIFICATION_ERROR)


def _add_page_controls(action, page, total_pages, *, route_first_page=1, **params):
    """Display one-based page numbers, including for legacy zero-based routes."""
    def page_url(target_page):
        return build_url(action, page=target_page - 1 + route_first_page, **params)

    def add(label, navigation_label, artwork, target_page):
        li = xbmcgui.ListItem(label)
        li.setArt({key: artwork for key in ("icon", "thumb", "poster", "landscape")})
        description = ("Return to the first page of this list." if target_page == 1
                       else "Browse page %d of %d." % (target_page, total_pages))
        _set_navigation_info(li, navigation_label, description, title=label)
        xbmcplugin.addDirectoryItem(HANDLE, page_url(target_page), li, isFolder=True)
    if page < total_pages:
        xbmcplugin.setProperty(HANDLE, "Flixtor.NextPage", page_url(page + 1))
        add("Next Page (%d/%d)" % (page + 1, total_pages), "Next Page", NEXT_PAGE_ICON, page + 1)
    if page > 1:
        xbmcplugin.setProperty(HANDLE, "Flixtor.PreviousPage", page_url(page - 1))
        add("First Page", "First Page", "DefaultFolderBack.png", 1)


def do_search_execute(query, page=1):
    """Re-execute a saved search query (or paginate through it)."""
    _do_search_execute(query, save=(page == 1), page=page)


def _do_search_execute(query, save=False, page=1):
    """Run a search query and display one page of results."""
    _log("search request: page=%d" % page)
    direct_input = skin_owns_home(xbmc.getSkinDir())
    client = get_client(defer_login=True) if direct_input else get_client()
    if not client:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return False
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        result = client.search(query, page=page)
        items = result.get("items") or []
        # Inside the busy dialog so a cold TMDb cache doesn't leave dead
        # air between the spinner closing and the list appearing.
        _prefetch_tmdb(items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    error = result.get("error")
    if error and not direct_input:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        _listing_error_message(result, build_url("search_execute", q=query, page=page))
        return False
    if error or not items:
        xbmcgui.Window(10000).clearProperty(ACTIVE_SEARCH_QUERY_PROPERTY)
        if error:
            needs_account = error.get("code") == "auth"
            action_label = "Account settings" if needs_account else "Retry Search"
            retry = xbmcgui.ListItem(action_label)
            retry.setArt(_card_art("search"))
            _set_navigation_info(retry, action_label, _listing_error_text(result), empty=True)
            retry_url = (build_url("search_account") if needs_account else
                         build_url("search_execute", q=query, page=page))
            retry.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(HANDLE, retry_url, retry, isFolder=not needs_account)
        li = xbmcgui.ListItem("Edit Search...")
        li.setArt(_card_art("search"))
        description = ('Edit the search for "%s".' if error else
                       'No titles matched "%s". Select Edit Search to change your query.') % query
        _set_navigation_info(li, "Edit Search", description,
                             title="Edit Search", empty=True)
        edit_action = "search_input" if direct_input else "new_search"
        if direct_input:
            li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(HANDLE, build_url(edit_action, q=query), li,
                                    isFolder=not direct_input)
        xbmcplugin.setPluginCategory(HANDLE, ("Search unavailable: %s" if error else "No matches: %s") % query)
        xbmcplugin.setContent(HANDLE, "files")
        if error:
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        else:
            xbmcplugin.endOfDirectory(HANDLE)
        return False
    if save:
        try:
            if SearchHistory().add(query):
                _refresh_search_history()
        except (OSError, sqlite3.Error):
            _log("search: could not save recent search")

    total_pages = result.get("total_pages") or page
    heading = "Search: %s" % query
    if page > 1 or total_pages > 1:
        heading += " (page %d/%d)" % (page, total_pages)
    xbmcplugin.setPluginCategory(HANDLE, heading)

    for item in items:
        add_content_item(item, show_type_label=True)

    _add_page_controls("search_execute", page, total_pages, q=query)

    xbmcplugin.setContent(HANDLE, _listing_content(items))
    # Server-paginated: client-side sorts would only reorder this 24-item
    # page, which reads as broken — offer the natural order only.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)
    return True


def do_remove_search(query):
    """Remove a query from search history and refresh the listing."""
    SearchHistory().remove(query)
    _refresh_search_history()
    xbmc.executebuiltin("Container.Refresh")


# ── Browse home (paginated) ──────────────────────────────────────────

def do_home(filter_type=None, action="home", page=0, quiet=False, paged_widget=False):
    client = get_client(quiet=quiet, defer_login=skin_owns_home(xbmc.getSkinDir()))
    if not client:
        if quiet:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if not quiet:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        all_items = client.browse_home(filter_type=filter_type)
        # Paginate, then resolve TMDb inside the busy dialog (no dead air
        # between spinner close and list render on a cold cache).
        start = page * PAGE_SIZE
        end = start + PAGE_SIZE
        page_items = all_items[start:end]
        _prefetch_tmdb(page_items)
    finally:
        if not quiet:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not all_items:
        if not quiet:
            xbmcgui.Dialog().notification("Flixtor", "Could not load content. Try again later.",
                                           xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # Show type labels only when content is mixed (Trending All)
    show_labels = filter_type is None
    for item in page_items:
        add_content_item(item, show_type_label=show_labels)

    if not quiet or paged_widget:
        total_pages = (len(all_items) + PAGE_SIZE - 1) // PAGE_SIZE
        _add_page_controls(action, page + 1, total_pages, route_first_page=0)

    content = "movies" if filter_type == "movie" else "tvshows" if filter_type == "tv" else "videos"
    heading = "Trending Movies" if filter_type == "movie" else "Trending TV Shows" if filter_type == "tv" else "Trending"
    xbmcplugin.setPluginCategory(HANDLE, heading)
    xbmcplugin.setContent(HANDLE, content)
    # Paginated view: per-page client sorts read as broken — natural order only.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Catalog (full Flixtor library, paginated server-side) ────────────

# Each row maps to a dedicated action (action=<route>) rather than a sort=<key>
# query param, because Kodi silently strips some param names (e.g. `filter`,
# `resume_mode`) from plugin URLs. Dedicated routes are the safe pattern.
# Tuple is (kind, sort, language, label). language="all" means no language
# filter; ISO 639-1 codes like "es" filter the catalog to originals in that
# language. Spanish entries surface ~480 movies / ~80 TV shows that Flixtor
# tags as Spanish-language originals (no dub functionality \u2014 Flixtor's player
# only loads one audio track per stream, see audio investigation in v1.19.0).
_CATALOG_ROUTES = {
    "movies_latest":    ("movies",   "latest", "all", "Latest Releases"),
    "movies_new":       ("movies",   "new",    "all", "Recently Added"),
    "movies_best":      ("movies",   "best",   "all", "Best Rated"),
    "movies_name":      ("movies",   "name",   "all", "A\u2013Z"),
    "movies_spanish":   ("movies",   "latest", "es",  "Spanish (Original Audio)"),
    "tvshows_latest":   ("tvshows",  "latest", "all", "Latest Releases"),
    "tvshows_new":      ("tvshows",  "new",    "all", "Recently Added"),
    "tvshows_best":     ("tvshows",  "best",   "all", "Best Rated"),
    "tvshows_name":     ("tvshows",  "name",   "all", "A\u2013Z"),
    "tvshows_spanish":  ("tvshows",  "latest", "es",  "Spanish (Original Audio)"),
}


_CATALOG_HEADINGS = {"movies": "Movies", "tvshows": "TV Shows"}

# Mapping from kind to the dedicated genre-picker action. Dedicated routes
# (rather than action=genres&kind=...) keep us safe from Kodi's URL param
# stripping, same reasoning as _CATALOG_ROUTES above.
_GENRE_PICKER_ROUTES = {
    "movies":  "genres_movies",
    "tvshows": "genres_tvshows",
}

# Catalog action suffix → card slug. Used by the sort picker and genre picker
# to look up the right bundled card image for each route.
_CATALOG_CARD_SLUGS = {
    "latest":  "sort_latest",
    "new":     "sort_new",
    "best":    "sort_best",
    "name":    "sort_az",
    "spanish": "lang_spanish",
}


def show_catalog_sort_picker(kind):
    """First level of Movies/TV Shows: pick a sort mode (or Browse by Genre)."""
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    # Breadcrumb carries the "Movies"/"TV Shows" context so the cards don't
    # need a redundant "Movies \u2014 " prefix that gets truncated in AH2.
    xbmcplugin.setPluginCategory(HANDLE, heading)
    content_name = "movies" if kind == "movies" else "TV shows"
    descriptions = {
        "latest": "Browse the latest %s releases." % ("movie" if kind == "movies" else "TV show"),
        "new": "Find %s recently added to Flixtor." % content_name,
        "best": "Browse %s ordered by rating." % content_name,
        "name": "Browse %s in alphabetical order." % content_name,
    }
    for action, (k, _sort, lc, label) in _CATALOG_ROUTES.items():
        if k != kind or lc != "all":
            continue
        url = build_url(action, page=1)
        li = xbmcgui.ListItem(label)
        suffix = action.rsplit("_", 1)[1]
        li.setArt(_card_art(_CATALOG_CARD_SLUGS.get(suffix, "sort_latest")))
        _set_navigation_info(li, label, descriptions.get(suffix, "Browse %s." % content_name))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    genre_action = _GENRE_PICKER_ROUTES.get(kind)
    if genre_action:
        url = build_url(genre_action)
        li = xbmcgui.ListItem("Browse by Genre")
        li.setArt(_card_art("sort_genre"))
        _set_navigation_info(li, "Browse by Genre", "Choose a genre or browse Spanish-language originals.")
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


def show_genre_picker(kind):
    """Pick a genre, then jump straight to the Latest Additions catalog
    filtered to that genre."""
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        genres = client.get_genres(kind)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not genres:
        xbmcgui.Dialog().notification("Flixtor", "Could not load genres. Try again later.",
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    content_name = "movies" if kind == "movies" else "TV shows"
    xbmcplugin.setPluginCategory(HANDLE, "%s \u2014 Browse by Genre" % heading)
    # Language filters live alongside genres in this picker \u2014 they're a
    # separate dimension from genre, but to the user they're "another way to
    # browse" and belong in the same list. Listed first so they're prominent.
    for action, (k, _sort, lc, label) in _CATALOG_ROUTES.items():
        if k != kind or lc == "all":
            continue
        url = build_url(action, page=1)
        li = xbmcgui.ListItem(label)
        suffix = action.rsplit("_", 1)[1]
        li.setArt(_card_art(_CATALOG_CARD_SLUGS.get(suffix, "sort_latest")))
        _set_navigation_info(li, label, "Browse %s originally released in Spanish." % content_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    latest_action = "%s_latest" % kind
    for genre in genres:
        url = build_url(latest_action, genre=genre, page=1)
        # Genre slugs use hyphens (e.g. "Science-Fiction") \u2014 show a friendlier label.
        label = genre.replace("-", " ")
        li = xbmcgui.ListItem(label)
        li.setArt(_card_art(_GENRE_CARD_SLUGS.get(genre, "sort_genre")))
        _set_navigation_info(li, label, "Browse %s %s, starting with the latest releases." % (label, content_name))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE)


def do_catalog(action, kind, sort, page, genre="all", language="all", quiet=False, paged_widget=False):
    """Second level: one page of the paginated catalog, optionally
    constrained to a single genre and/or spoken language."""
    client = get_client(quiet=quiet, defer_login=skin_owns_home(xbmc.getSkinDir()))
    if not client:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if not quiet:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        result = client.browse_catalog(kind, sort=sort, page=page,
                                        genre=genre, language=language)
        items = result.get("items") or []
        # Inside the busy dialog so a cold TMDb cache doesn't leave dead
        # air between the spinner closing and the list appearing.
        _prefetch_tmdb(items)
    finally:
        if not quiet:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if result.get("error"):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        if not quiet:
            _listing_error_message(result, build_url(action, sort=sort, page=page, genre=genre, language=language))
        return
    if not items:
        if not quiet:
            xbmcgui.Dialog().notification("Flixtor", "No results found.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    total_pages = result.get("total_pages") or page

    # Breadcrumb always reflects where you are: sort label, filters, page \u2014
    # deep pagination otherwise leaves no orientation cues at all.
    heading = _CATALOG_HEADINGS.get(kind, kind.title())
    breadcrumb_parts = []
    route_label = _CATALOG_ROUTES.get(action, ("", "", "", ""))[3]
    if route_label:
        breadcrumb_parts.append(route_label)
    elif language and language != "all":
        breadcrumb_parts.append(language.upper())
    if genre and genre != "all":
        breadcrumb_parts.append(genre.replace("-", " "))
    crumb = "%s \u2014 %s" % (heading, " / ".join(breadcrumb_parts)) if breadcrumb_parts else heading
    if total_pages > 1:
        crumb += "  \u00b7  %d/%d" % (page, total_pages)
    xbmcplugin.setPluginCategory(HANDLE, crumb)

    for item in items:
        add_content_item(item, show_type_label=False)

    if not quiet or paged_widget:
        _add_page_controls(action, page, total_pages, sort=sort, genre=genre, language=language)

    content = "movies" if kind == "movies" else "tvshows"
    xbmcplugin.setContent(HANDLE, content)
    # Server-paginated: client-side sorts would only reorder this 24-item
    # page, which reads as broken \u2014 offer the natural order only.
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# ── TV show: seasons ──────────────────────────────────────────────────

def show_seasons(pid, slug, title, poster):
    client = get_client()
    if not client:
        return
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        seasons = client.get_seasons(pid, slug)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not seasons:
        xbmcgui.Dialog().notification("Flixtor", "No episodes found.", xbmcgui.NOTIFICATION_INFO)
        return

    # Get show info for plot — but keep the poster from the listing (Flixtor's
    # detail page sometimes returns wrong poster art, e.g. ER for The Pitt)
    info = client.get_show_info(pid, slug)
    show_poster = poster or info.get("poster", "")
    plot = info.get("plot", "")
    trailer = info.get("trailer", "")
    year = info.get("year", "")

    tmdb_client = _get_tmdb()
    show_tmdb_id = None
    show_fanart = show_poster
    if tmdb_client:
        tinfo = tmdb_client.lookup_cached_info(title, year, "tv")
        show_tmdb_id = tinfo["tmdb_id"]
        plot = plot or tinfo["plot"]
        show_fanart = tinfo["fanart"] or show_poster

    WatchHistory().remember_inventory(pid, seasons, {
        "title": title, "slug": slug, "poster": show_poster, "year": year,
        "tmdb_id": show_tmdb_id or ""})
    global _watch_inventory_cache
    _watch_inventory_cache = None
    for s_num in sorted(seasons.keys()):
        ep_count = len(seasons[s_num])
        episode_count = "%d %s" % (ep_count, "episode" if ep_count == 1 else "episodes")
        label = "Season %s (%s)" % (s_num, episode_count)
        url = build_url("episodes", pid=pid, slug=slug, season=s_num, title=title, poster=show_poster)
        li = xbmcgui.ListItem(label)
        li.setArt({"poster": show_poster, "thumb": show_poster,
                   "fanart": show_fanart, "landscape": show_fanart,
                   "tvshow.poster": show_poster, "tvshow.fanart": show_fanart})
        # Keep these as season navigation folders. Native season/TV-show
        # metadata also activates AH2's library panel; the Flixtor view reads
        # explicit context properties without changing the folder behavior.
        season_info = {"title": label, "plot": plot, "season": int(s_num)}
        _apply_watch_state(li, season_info, pid, season=int(s_num), media_type="tv")
        li.setInfo("video", season_info)
        season_item = dict(info, pid=pid, slug=slug, title=title, poster=show_poster, media_type="tv")
        _attach_flixtor_context(li, _media_actions(li, season_item, scope="season", season=int(s_num)))
        li.setProperty("Flixtor.ShowTitle", title)
        li.setProperty("Flixtor.SeasonLabel", "Season %s" % s_num)
        li.setProperty("Flixtor.ItemKind", "navigation")
        li.setProperty("Flixtor.EpisodeCount", episode_count)
        if info.get("rating"):
            li.setRating(info.get("rating_provider", "flixtor"), float(info["rating"]), 0, True)
        _attach_tmdb_id(li, show_tmdb_id, "tv")
        if trailer:
            li.setProperty("trailer", trailer)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


# ── TV show: episodes (rich) ─────────────────────────────────────────

def show_episodes(pid, slug, season, title, poster):
    client = get_client()
    if not client:
        return

    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        # Get show info for plot
        show_info = client.get_show_info(pid, slug)
        poster = poster or show_info.get("poster", "")
        show_plot = show_info.get("plot", "")
        episodes = client.get_episodes(pid, slug, int(season))
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

    if not episodes:
        # Fallback to basic listing
        seasons = client.get_seasons(pid, slug)
        ep_nums = seasons.get(int(season), [])
        episodes = [{"episode": e, "title": "", "air_date": "", "thumb": ""} for e in ep_nums]

    tmdb_client = _get_tmdb()
    show_tmdb_id = None
    show_fanart = poster
    if tmdb_client:
        tinfo = tmdb_client.lookup_cached_info(title, show_info.get("year", ""), "tv")
        show_tmdb_id = tinfo["tmdb_id"]
        show_plot = show_plot or tinfo["plot"]
        show_fanart = tinfo["fanart"] or poster

    for ep in episodes:
        ep_num = ep["episode"]
        ep_title = ep.get("title", "")
        air_date = ep.get("air_date", "")
        thumb = ep.get("thumb", "") or poster

        if ep_title:
            label = f"{ep_num}. {ep_title}"
        else:
            label = f"Episode {ep_num}"

        url = build_url(
            "play_episode", pid=pid, slug=slug,
            season=season, episode=ep_num, title=title, poster=poster,
            episode_title=ep_title,
        )
        li = xbmcgui.ListItem(label)
        li.setArt({"poster": poster, "thumb": thumb, "fanart": show_fanart,
                   "icon": thumb, "landscape": ep.get("thumb") or show_fanart,
                   "tvshow.poster": poster, "tvshow.fanart": show_fanart})
        info = {
            "title": ep_title or label,
            "tvshowtitle": title,
            "season": int(season),
            "episode": ep_num,
            "plot": ep.get("plot") or _episode_plot(show_tmdb_id, season, ep_num) or show_plot,
            "mediatype": "episode",
        }
        if air_date:
            info["aired"] = air_date
        # Watched tick / progress per episode — answers "which one was I on"
        # right in the list.
        _apply_watch_state(li, info, pid, season=int(season), episode=ep_num)
        li.setInfo("video", info)
        li.setProperty("Flixtor.ItemKind", "episode")
        li.setProperty("Flixtor.ShowTitle", title)
        li.setProperty("Flixtor.SeasonLabel", "Season %s" % int(season))
        li.setProperty("Flixtor.EpisodeLabel", "Episode %s" % ep_num)
        if show_plot and info["plot"] == show_plot:
            li.setProperty("Flixtor.PlotIsSeries", "true")
        _attach_tmdb_id(li, show_tmdb_id, "tv")
        li.setProperty("IsPlayable", "true")
        episode_item = dict(show_info, pid=pid, slug=slug, title=title, poster=poster,
                            media_type="tv", episode_title=ep_title)
        _attach_flixtor_context(li, _media_actions(li, episode_item, scope="episode",
                                                season=int(season), episode=ep_num))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.setPluginCategory(HANDLE, "%s - Season %s" % (title, int(season)))
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


# ── Play ──────────────────────────────────────────────────────────────

def _format_time(seconds):
    h, m, s = int(seconds // 3600), int((seconds % 3600) // 60), int(seconds % 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _ask_resume(resume_seconds):
    """Show resume dialog. Returns seek position (0 = from start, >0 = resume, -1 = cancelled)."""
    label = _format_time(resume_seconds)
    choice = xbmcgui.Dialog().contextmenu([
        f"Resume from {label}",
        "Play from beginning",
    ])
    if choice < 0:
        return -1
    return resume_seconds if choice == 0 else 0


def _error_message(error_type):
    """Return a user-friendly error message for a given error type."""
    if error_type == "network":
        return "Network error. Check your connection."
    if error_type == "empty":
        return "Server returned an empty response."
    return "Could not load stream. Try again later."


def _resolve_with_retry(resolve_func):
    """Call resolve_func with progress dialog and one retry on failure."""
    progress = xbmcgui.DialogProgress()
    progress.create("Flixtor", "Loading stream...")
    try:
        stream = resolve_func()
    finally:
        progress.close()

    for attempt in range(2):
        if stream and "error" not in stream:
            return stream
        if stream and "error" in stream:
            msg = _error_message(stream["error"])
            _log("resolve error (attempt %d): %s — %s" % (attempt + 1, stream["error"], stream.get("detail", "")))
            if attempt == 0:
                if not xbmcgui.Dialog().yesno("Flixtor", msg, yeslabel="Retry", nolabel="Cancel"):
                    return None
                progress = xbmcgui.DialogProgress()
                progress.create("Flixtor", "Retrying...")
                try:
                    stream = resolve_func()
                finally:
                    progress.close()
            else:
                xbmcgui.Dialog().ok("Flixtor", msg)
                return None
        else:
            xbmcgui.Dialog().notification("Flixtor", "Could not resolve stream.", xbmcgui.NOTIFICATION_ERROR)
            return None
    return stream


def play_movie(pid, title, poster, slug="", resume_mode="", return_url=""):
    """resume_mode: '' = check history and ask, 'resume' = auto-resume, 'start' = play from beginning."""
    history = WatchHistory()
    seek_on_start = 0.0
    quality = ""

    if resume_mode == "resume":
        seek_on_start = history.get_resume_position(pid)
        quality = history.get_quality(pid)
    elif resume_mode == "start":
        pass  # seek_on_start = 0, quality = "" (ask)
    else:
        resume = history.get_resume_position(pid)
        if resume > 0:
            pref = ADDON.getSetting("resume_mode_default") or "0"
            if pref == "1":
                seek_on_start = resume
                quality = history.get_quality(pid)
            elif pref == "2":
                pass  # always start from beginning
            else:
                result = _ask_resume(resume)
                if result < 0:
                    return
                if result > 0:
                    seek_on_start = result
                    quality = history.get_quality(pid)

    client = get_client()
    if not client:
        return
    _log("play_movie: pid=%s slug=%s" % (pid, slug))
    stream = _resolve_with_retry(lambda: client.resolve_movie(pid, slug=slug))
    if not stream:
        return
    _play_stream(stream, title, poster, pid=pid, slug=slug,
                 media_type="movie", seek_on_start=seek_on_start, quality=quality,
                 return_url=return_url)


def play_episode(pid, season, episode, title, poster, slug="", resume_mode="",
                 return_url="", episode_title=""):
    """resume_mode: '' = check history and ask, 'resume' = auto-resume, 'start' = play from beginning."""
    history = WatchHistory()
    seek_on_start = 0.0
    quality = ""
    try:
        s, e = int(season), int(episode)
    except (ValueError, TypeError):
        xbmcgui.Dialog().notification("Flixtor", "Invalid episode.", xbmcgui.NOTIFICATION_ERROR)
        return

    if resume_mode == "resume":
        seek_on_start = history.get_resume_position(pid, season=s, episode=e)
        quality = history.get_quality(pid, season=s, episode=e)
    elif resume_mode == "start":
        pass
    else:
        resume = history.get_resume_position(pid, season=s, episode=e)
        if resume > 0:
            pref = ADDON.getSetting("resume_mode_default") or "0"
            if pref == "1":
                seek_on_start = resume
                quality = history.get_quality(pid, season=s, episode=e)
            elif pref == "2":
                pass  # always start from beginning
            else:
                result = _ask_resume(resume)
                if result < 0:
                    return
                if result > 0:
                    seek_on_start = result
                    quality = history.get_quality(pid, season=s, episode=e)

    client = get_client()
    if not client:
        return
    _log("play_episode: pid=%s s=%d e=%d" % (pid, s, e))
    stream = _resolve_with_retry(lambda: client.resolve_episode(pid, s, e, slug=slug))
    if not stream:
        return
    label = episode_title or f"Episode {e}"
    next_ep = _compute_next_episode(
        client, pid, slug, s, e, title, poster, return_url=return_url
    )
    _play_stream(stream, label, poster, pid=pid, slug=slug,
                 media_type="tv", season=s, episode=e,
                 seek_on_start=seek_on_start, quality=quality,
                 next_episode=next_ep, history_title=title,
                 return_url=return_url)


def _compute_next_episode(
        client, pid, slug, season, episode, show_title, poster,
        return_url=""):
    """Find the next episode after (season, episode). Returns a dict or None."""
    try:
        seasons = client.get_seasons(pid, slug)
    except Exception as exc:
        _log("next_episode: get_seasons failed: %s" % exc)
        return None
    if not seasons:
        return None
    WatchHistory().remember_inventory(pid, seasons, {
        "title": show_title, "slug": slug, "poster": poster})
    current_eps = [number for number in seasons.get(season, []) if number > episode]
    if current_eps:
        next_s, next_e = season, min(current_eps)
    else:
        higher = [s for s in seasons if s > season and seasons[s]]
        if not higher:
            return None
        next_s = min(higher)
        next_e = min(seasons[next_s])
    result = {
        "pid": str(pid),
        "slug": slug,
        "season": next_s,
        "episode": next_e,
        "title": show_title,
        "poster": poster,
    }
    if return_url:
        # Keep a TMDb-recommendation landing target across auto-played episodes
        # so stopping anywhere in the chain still returns to the selected show.
        result["return_url"] = return_url
    return result


def _play_stream(stream, title, poster, pid="", slug="", media_type="movie",
                 season=None, episode=None, seek_on_start=0.0, quality="",
                 next_episode=None, history_title="", return_url=""):
    if not stream or "error" in stream or "file" not in stream:
        xbmcgui.Dialog().notification("Flixtor", "Could not resolve stream.", xbmcgui.NOTIFICATION_ERROR)
        return

    master_url = stream["file"]
    policy = adaptive_policy(ADDON.getSetting("default_quality"), preferred=quality)
    inputstream_addon = _inputstream_adaptive_addon()

    if inputstream_addon:
        # Keep the multi-bitrate master URL intact.  InputStream Adaptive can
        # then lower quality during a temporary Wi-Fi/CDN slowdown instead of
        # pausing a fixed representation while its small player cache drains.
        stream_url = master_url
        selected_quality = policy["label"]
    else:
        # Kodi's native HLS path cannot honor ISA's quality ceilings.  Preserve
        # a compatible fixed-quality/ask fallback for installations where the
        # binary add-on is unavailable.
        stream_url, selected_quality = _pick_quality(
            master_url, _LEGACY_STREAM_HEADERS, preferred=policy["label"])
        if not stream_url:
            return
    _log("play_stream: quality=%s adaptive=%s" % (
        selected_quality, "yes" if inputstream_addon else "no"))

    li = xbmcgui.ListItem(title, path=stream_url)
    li.setArt({"poster": poster, "thumb": poster})
    info = {"title": title, "mediatype": "movie"}
    if media_type == "tv":
        info.update({
            "mediatype": "episode", "tvshowtitle": history_title,
            "season": int(season), "episode": int(episode),
        })
    li.setInfo("video", info)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)

    if inputstream_addon:
        li.setProperty("inputstream", inputstream_addon)
        # Required by the Kodi 20 compatibility floor; deprecated but still
        # supported on Kodi 21, where manifest type is also auto-detected.
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        # Kodi 21 applies stream_headers to media segments only.  Set both
        # documented properties and keep headers out of the URL itself.
        li.setProperty("inputstream.adaptive.manifest_headers", _INPUTSTREAM_HEADERS)
        li.setProperty("inputstream.adaptive.stream_headers", _INPUTSTREAM_HEADERS)
        li.setProperty(
            "inputstream.adaptive.stream_selection_type",
            policy["selection_type"],
        )
        if policy["resolution_max"]:
            li.setProperty(
                "inputstream.adaptive.chooser_resolution_max",
                policy["resolution_max"],
            )
        if policy["bandwidth_height"]:
            cap = _master_bandwidth_ceiling(
                master_url, policy["bandwidth_height"])
            if cap:
                li.setProperty(
                    "inputstream.adaptive.chooser_bandwidth_max", str(cap))

    # Localize subtitles to clean filenames (preferred-language first) so Kodi
    # displays readable labels and the service can deterministically pick the
    # right stream by ISO code.
    pref_label, pref_iso, _ = _preferred_subtitle_pref()
    subs = _localize_subtitles(stream.get("tracks", []), pref_label)
    if subs:
        li.setSubtitles(subs)

    # Write now_playing marker for the background service to pick up
    history = WatchHistory()
    auto_play_next = ADDON.getSetting("auto_play_next") != "false"
    subtitles_default = ADDON.getSetting("subtitles_default") == "true"
    history.set_now_playing({
        **_history_identity(history_title or title, media_type),
        "pid": str(pid),
        "slug": slug,
        "media_type": media_type,
        "title": history_title or title,
        "episode_title": title if media_type == "tv" else "",
        "poster": poster,
        "season": season,
        "episode": episode,
        "resume_seconds": 0.0,
        "total_seconds": 0.0,
        "quality": selected_quality,
        "timestamp": time.time(),
        "seek_on_start": seek_on_start,
        "next_episode": next_episode,
        "auto_play_next": auto_play_next,
        "subtitles_default": subtitles_default,
        "preferred_subtitle_iso": pref_iso,
        "preferred_subtitle_label": pref_label,
        # Only TMDb Helper recommendation playback supplies this. The resident
        # service consumes it after Stop/End to make the selected recommendation
        # the active Flixtor title instead of revealing the original movie.
        "return_url": return_url,
    })

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _inputstream_adaptive_addon():
    """Return the installed HLS inputstream add-on id, or an empty string."""
    try:
        import inputstreamhelper
        helper = inputstreamhelper.Helper("hls")
        if helper.check_inputstream():
            return helper.inputstream_addon
        # A false result can represent a user declining Kodi's normal
        # install/enable flow. Honor that choice rather than bypassing it.
        return ""
    except ImportError:
        # Older installations can briefly run the updated plug-in before Kodi
        # finishes resolving its newly declared helper dependency.
        pass
    except Exception as exc:
        _log("inputstream helper unavailable: %s" % exc)
    try:
        if xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
            return "inputstream.adaptive"
    except Exception as exc:
        _log("inputstream.adaptive check failed: %s" % exc)
    return ""


def _fetch_master_manifest(master_url):
    """Fetch a current HLS master using the same headers as playback."""
    try:
        req = urllib.request.Request(master_url)
        req.add_header("User-Agent", "Mozilla/5.0")
        req.add_header("Referer", "https://flixtor.to/")
        req.add_header("Origin", "https://flixtor.to")
        resp = urllib.request.urlopen(req, timeout=8)
        return resp.read().decode("utf-8", "replace")
    except Exception as exc:
        _log("quality: master fetch failed: %s" % exc)
        return ""


def _master_bandwidth_ceiling(master_url, max_height):
    manifest = _fetch_master_manifest(master_url)
    if not manifest:
        return 0
    return bandwidth_ceiling(parse_hls_variants(master_url, manifest), max_height)


def _pick_quality(master_url, headers, preferred=""):
    """Native-player fallback for installations without InputStream Adaptive."""
    policy = adaptive_policy(ADDON.getSetting("default_quality"), preferred=preferred)
    if policy["label"] == "Auto":
        return "%s|%s" % (master_url, headers), "Auto"

    manifest = _fetch_master_manifest(master_url)
    if not manifest:
        return "%s|%s" % (master_url, headers), policy["label"]
    variants = parse_hls_variants(master_url, manifest)

    if not variants:
        return "%s|%s" % (master_url, headers), policy["label"]

    if len(variants) == 1:
        return "%s|%s" % (variants[0]["url"], headers), variants[0]["label"]

    variants.sort(key=lambda variant: variant["height"], reverse=True)
    if policy["label"] != "Ask":
        target_height = int(policy["label"][:-1])
        closest = min(
            variants,
            key=lambda variant: abs(variant["height"] - target_height),
        )
        if closest["height"] != target_height:
            _log("quality: %s unavailable, picked %s (%s)" % (
                policy["label"], closest["label"], closest["resolution"]))
        return "%s|%s" % (closest["url"], headers), closest["label"]

    labels = ["%s (%s)" % (variant["label"], variant["resolution"])
              for variant in variants]
    choice = xbmcgui.Dialog().select("Select Quality", labels)
    if choice < 0:
        return None, ""

    selected = variants[choice]
    return "%s|%s" % (selected["url"], headers), selected["label"]


# (label, iso-639-2/B 3-letter, iso-639-1 2-letter). Order matches the
# subtitles_language enum in settings.xml — index = setting value.
_SUBTITLE_LANGUAGES = [
    ("English",    "eng", "en"),
    ("Spanish",    "spa", "es"),
    ("French",     "fre", "fr"),
    ("German",     "ger", "de"),
    ("Portuguese", "por", "pt"),
    ("Italian",    "ita", "it"),
    ("Arabic",     "ara", "ar"),
    ("Russian",    "rus", "ru"),
    ("Japanese",   "jpn", "ja"),
    ("Korean",     "kor", "ko"),
    ("Chinese",    "chi", "zh"),
]

# Wider Flixtor → ISO 639-2/B map. Only used to put ISO codes in downloaded
# filenames so Kodi displays clean labels in its subtitle picker.
_LABEL_TO_ISO = [
    ("english",    "eng"), ("spanish",    "spa"), ("french",     "fre"),
    ("german",     "ger"), ("portuguese", "por"), ("italian",    "ita"),
    ("arabic",     "ara"), ("russian",    "rus"), ("japanese",   "jpn"),
    ("korean",     "kor"), ("chinese",    "chi"), ("dutch",      "dut"),
    ("polish",     "pol"), ("greek",      "gre"), ("turkish",    "tur"),
    ("czech",      "cze"), ("danish",     "dan"), ("finnish",    "fin"),
    ("swedish",    "swe"), ("norwegian",  "nor"), ("hebrew",     "heb"),
    ("vietnamese", "vie"), ("thai",       "tha"), ("hungarian",  "hun"),
    ("romanian",   "rum"), ("bulgarian",  "bul"), ("croatian",   "hrv"),
    ("serbian",    "srp"), ("slovenian",  "slv"), ("slovak",     "slo"),
    ("ukrainian",  "ukr"), ("estonian",   "est"), ("latvian",    "lav"),
    ("lithuanian", "lit"), ("indonesian", "ind"), ("malay",      "may"),
    ("persian",    "per"), ("hindi",      "hin"), ("bengali",    "ben"),
    ("urdu",       "urd"), ("tamil",      "tam"), ("telugu",     "tel"),
]


def _preferred_subtitle_pref():
    """Return (label, iso-639-2, iso-639-1) for the user's preferred language."""
    idx = ADDON.getSetting("subtitles_language") or "0"
    try:
        return _SUBTITLE_LANGUAGES[int(idx)]
    except (ValueError, IndexError):
        return _SUBTITLE_LANGUAGES[0]


def _label_to_iso(label):
    """Map a Flixtor subtitle label (e.g. 'Chinese (traditional)') to an
    ISO 639-2/B 3-letter code. Falls back to 'und' for unknown languages."""
    if not label:
        return "und"
    label_low = label.lower()
    for name, iso in _LABEL_TO_ISO:
        if name in label_low:
            return iso
    return "und"


def _safe_subtitle_url(url):
    """URL-encode a Flixtor subtitle URL so spaces in labels don't make
    urllib reject it. Flixtor labels like 'Portuguese (BR)' end up in the
    path component and break a naked Request() otherwise."""
    parts = urllib.parse.urlsplit(url)
    encoded_path = urllib.parse.quote(parts.path, safe="/.")
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, encoded_path, parts.query, parts.fragment)
    )


def _localize_subtitles(tracks, preferred_label):
    """Return subtitle paths/URLs to feed into ListItem.setSubtitles().

    The preferred-language track is downloaded to a local file with a clean,
    language-coded name (e.g. ``English_8e45dea82d.eng.srt``). Everything
    else is passed through as a URL-encoded URL so Kodi can lazily fetch on
    demand if the user switches.

    Two reasons we localize at all:
      1. Flixtor URLs bury the language name behind a long hash
         (``…01e54e2ad0937b7a.bc37a136ff…English.vtt``), which Kodi shows
         in its subtitle picker — surfacing as garbage like
         ``ENG 01e54e2ad0937b7a.bc37…``.
      2. Without a recognizable ISO code in the filename, Kodi can't
         match the user's preferred language and may pick the wrong track.

    Eagerly downloading every track adds ~3-6s to playback start (which is
    a noticeable regression for users who don't use subtitles) so we only
    fetch the one Kodi will auto-select. Returns the preferred path first
    (so it's stream index 0) followed by the rest — preserves switchability.
    """
    captions = [t for t in (tracks or []) if t.get("kind") == "captions" and t.get("file")]
    if not captions:
        return []

    pref_low = (preferred_label or "").lower()

    # Find the preferred track (substring match handles "Chinese (traditional)" etc.)
    preferred_track = None
    if pref_low:
        for t in captions:
            if pref_low in (t.get("label") or "").lower():
                preferred_track = t
                break

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    subs_dir = os.path.join(profile, "subtitles")
    local_path = None
    if preferred_track:
        try:
            os.makedirs(subs_dir, exist_ok=True)
            # Prune old cached subs (>7 days) to keep the dir small.
            cutoff = time.time() - 7 * 86400
            for f in os.listdir(subs_dir):
                p = os.path.join(subs_dir, f)
                try:
                    if os.path.getmtime(p) < cutoff:
                        os.remove(p)
                except OSError:
                    pass
            local_path = _download_subtitle(preferred_track, subs_dir)
        except OSError as e:
            _log("subs: profile dir error: %s" % e)

    out = []
    if local_path:
        out.append(local_path)
    for t in captions:
        if t is preferred_track and local_path:
            continue
        out.append(_safe_subtitle_url(t["file"]))
    return out


def _download_subtitle(track, subs_dir):
    """Cache one preferred subtitle track locally.

    Flixtor currently serves WebVTT. Convert complete documents to SRT because
    Kodi's external SRT path has simpler timing state across pause/resume and
    seeks. If a future response cannot be converted, retain it as VTT rather
    than dropping subtitles entirely.
    """
    url = track["file"]
    label = track.get("label", "") or "Subtitle"
    iso = _label_to_iso(label)
    url_tag = hashlib.md5(url.encode("utf-8")).hexdigest()[:10]
    safe_label = re.sub(r'[^A-Za-z0-9 -]', "_", label).strip()[:40] or "Subtitle"
    stem = "%s_%s.%s" % (safe_label, url_tag, iso)
    srt_path = os.path.join(subs_dir, stem + ".srt")
    vtt_path = os.path.join(subs_dir, stem + ".vtt")
    if os.path.exists(srt_path) and os.path.getsize(srt_path) > 0:
        return srt_path

    data = None
    # Upgrade an existing v1.26.1 VTT cache entry without another request.
    if os.path.exists(vtt_path) and os.path.getsize(vtt_path) > 0:
        try:
            with open(vtt_path, "rb") as f:
                data = f.read()
        except OSError:
            data = None

    safe_url = _safe_subtitle_url(url)
    try:
        if data is None:
            req = urllib.request.Request(safe_url, headers={
                "User-Agent": "Mozilla/5.0",
                "Referer": "https://flixtor.to/",
            })
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = resp.read()

        srt_text = webvtt_to_srt(data)
        if srt_text:
            tmp = srt_path + ".tmp"
            with open(tmp, "wb") as f:
                f.write(srt_text.encode("utf-8"))
            os.replace(tmp, srt_path)
            _log("subs: cached %s as SRT" % label)
            return srt_path

        tmp = vtt_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, vtt_path)
        _log("subs: response was not convertible; retained VTT for %s" % label)
        return vtt_path
    except Exception as e:
        _log("subs: download failed (%s): %s" % (label, e))
        return None


# ── Recently Watched ──────────────────────────────────────────────────

def _build_resume_item(rec):
    """Build a (url, ListItem) pair for a watch-history record. Used by
    show_recent() and main_menu()'s Continue Watching band (the latter
    re-labels with a Resume prefix)."""
    title = rec.get("title", "")
    pid = rec.get("pid", "")
    slug = rec.get("slug", "")
    poster = rec.get("poster", "")
    media_type = rec.get("media_type", "movie")
    if media_type == "tv":
        title = canonical_show_title(title)
    resume = 0 if is_completed(rec) else rec.get("resume_seconds", 0)
    total = rec.get("total_seconds", 0)
    season = int(rec["season"]) if rec.get("season") is not None else None
    episode = int(rec["episode"]) if rec.get("episode") is not None else None

    if media_type == "tv" and season is not None:
        label = f"{title} S{season:02d}E{episode:02d}"
    else:
        label = title

    if resume > 0 and total > 0:
        remaining = total - resume
        label += f"  [COLOR grey]({_format_time(remaining)} left)[/COLOR]"

    if media_type == "movie":
        action = "resume_movie" if resume > 0 else "play_movie"
        url = build_url(action, pid=pid, slug=slug, title=title, poster=poster)
    else:
        action = "resume_episode" if resume > 0 else "play_episode"
        url = build_url(action, pid=pid, slug=slug, season=season,
                        episode=episode, title=title, poster=poster,
                        episode_title=rec.get("episode_title", ""))

    li = xbmcgui.ListItem(label)
    li.setProperty("IsPlayable", "true")

    tmdb_id = rec.get("tmdb_id")
    plot = ""
    fanart = poster
    tmdb_client = _get_tmdb()
    if tmdb_client:
        mtype = "movie" if media_type == "movie" else "tv"
        tinfo = tmdb_client.lookup_cached_info(title, rec.get("year", ""), mtype)
        tmdb_id = tmdb_id or tinfo["tmdb_id"]
        plot = tinfo["plot"]
        fanart = tinfo["fanart"] or poster
        if media_type == "tv":
            episode_plot = _episode_plot(tmdb_id, season, episode)
            if episode_plot:
                plot = episode_plot
            elif plot:
                li.setProperty("Flixtor.PlotIsSeries", "true")
    art = {"poster": poster, "thumb": poster, "fanart": fanart}
    if media_type == "tv":
        art.update({"tvshow.poster": poster, "tvshow.fanart": fanart})
        li.setProperty("Flixtor.ShowTitle", title)
        li.setProperty("Flixtor.SeasonLabel", "Season %s" % int(season))
        li.setProperty("Flixtor.EpisodeLabel", "Episode %s" % int(episode))
    li.setArt(art)
    if media_type == "movie":
        info = {"title": title, "mediatype": "movie"}
    else:
        info = {
            "title": rec.get("episode_title") or "Episode %d" % int(episode),
            "tvshowtitle": title,
            "season": int(season),
            "episode": int(episode),
            "mediatype": "episode",
        }
    if plot:
        info["plot"] = plot
    _apply_watch_state(li, info, pid, season, episode)
    li.setInfo("video", info)
    li.setProperty("Flixtor.ItemKind", info["mediatype"])
    _attach_tmdb_id(li, tmdb_id, media_type)

    if resume > 0 and total > 0:
        li.setProperty("ResumeTime", str(resume))
        li.setProperty("TotalTime", str(total))

    ctx = [
        _favorites_context_item(pid, {
            "slug": slug, "media_type": media_type,
            "title": title, "poster": poster,
            "year": rec.get("year", ""), "rating": rec.get("rating", ""),
            "genres": rec.get("genres", ""), "tmdb_id": tmdb_id or "",
        }),
        (
            "Remove from History",
            "RunPlugin(%s)" % build_url("ctx_remove_history", pid=pid,
                                         season=season if season is not None else "",
                                         episode=episode if episode is not None else ""),
        ),
    ]
    if resume > 0:
        if media_type == "movie":
            ctx.append((
                "Play from Beginning",
                "RunPlugin(%s)" % build_url("start_movie", pid=pid, slug=slug,
                                             title=title, poster=poster),
            ))
        else:
            ctx.append((
                "Play from Beginning",
                "RunPlugin(%s)" % build_url("start_episode", pid=pid, slug=slug,
                                             season=season, episode=episode,
                                             title=title, poster=poster,
                                             episode_title=rec.get("episode_title", "")),
            ))
    if media_type == "tv":
        # History cards are single episodes; this reaches the rest of the show.
        show_command = _open_listing_command(
            build_url("seasons", pid=pid, slug=slug, title=title, poster=poster))
        li.setProperty("Flixtor.ShowAction", show_command)
        ctx.append(("Go to Show", show_command))
    ctx.extend(_media_actions(li, rec, season=season, episode=episode))
    ctx.extend(_title_discovery_context_items(pid, slug, media_type, li))
    # Kodi's generic queue/library/resume actions do not update Flixtor's own
    # history and duplicate several entries above. Replace them with this short,
    # working set instead of appending to the system menu.
    _attach_flixtor_context(li, ctx)
    return url, li


def _build_recent_tv_show_item(rec):
    """Build a show-level Recently Watched card from its latest episode.

    Select opens the show's seasons so the user can continue naturally. Resume
    of the latest partial episode remains available as a clear context action.
    """
    title = canonical_show_title(rec.get("title", ""))
    pid = rec.get("pid", "")
    slug = rec.get("slug", "")
    poster = rec.get("poster", "")
    season = int(rec.get("season") or 0)
    episode = int(rec.get("episode") or 0)
    resume = 0 if is_completed(rec) else rec.get("resume_seconds") or 0
    episode_code = "S%02dE%02d" % (season, episode)
    status = "Resume %s" % episode_code if resume > 0 else "Last watched %s" % episode_code
    label = "%s  [COLOR grey](%s)[/COLOR]" % (title, status)

    li = xbmcgui.ListItem(label)
    url = build_url("seasons", pid=pid, slug=slug, title=title, poster=poster)

    tmdb_id = rec.get("tmdb_id")
    plot = ""
    fanart = poster
    tmdb_client = _get_tmdb()
    if tmdb_client:
        tinfo = tmdb_client.lookup_cached_info(title, rec.get("year", ""), "tv")
        tmdb_id = tmdb_id or tinfo["tmdb_id"]
        plot = tinfo["plot"]
        fanart = tinfo["fanart"] or poster
    info = {"title": title, "tvshowtitle": title, "mediatype": "tvshow"}
    if plot:
        info["plot"] = plot
    year = rec.get("year")
    if str(year or "").isdigit():
        info["year"] = int(year)
    _apply_watch_state(li, info, pid, media_type="tv")
    li.setInfo("video", info)
    li.setProperty("Flixtor.ItemKind", "tvshow")
    li.setProperty("Flixtor.ShowTitle", title)
    _attach_tmdb_id(li, tmdb_id, "tv")
    li.setArt({"poster": poster, "thumb": poster, "fanart": fanart,
               "tvshow.poster": poster, "tvshow.fanart": fanart})
    li.setContentLookup(False)

    ctx = []
    if resume > 0:
        ctx.append((
            "Resume %s" % episode_code,
            "RunPlugin(%s)" % build_url(
                "resume_episode", pid=pid, slug=slug, season=season,
                episode=episode, title=title, poster=poster,
                episode_title=rec.get("episode_title", ""),
            ),
        ))
    ctx.append(_favorites_context_item(pid, {
        "slug": slug, "media_type": "tv", "title": title, "poster": poster,
        "year": rec.get("year", ""), "rating": rec.get("rating", ""),
        "genres": rec.get("genres", ""), "tmdb_id": tmdb_id or "",
    }))
    ctx.append((
        "Remove Show from History",
        "RunPlugin(%s)" % build_url("ctx_remove_show_history", pid=pid),
    ))
    ctx.extend(_media_actions(li, rec, scope="show"))
    ctx.extend(_title_discovery_context_items(pid, slug, "tv", li))
    _attach_flixtor_context(li, ctx)
    return url, li


def _continue_records(records, limit=20):
    """Latest unfinished item per title, including explicitly queued next episodes."""
    selected, seen = [], set()
    for record in sorted(records, key=lambda item: item.get("timestamp", 0), reverse=True):
        if is_completed(record) or not (float(record.get("resume_seconds") or 0) > 0 or record.get("up_next")):
            continue
        key = (record.get("media_type", "movie"), str(record.get("pid", "")))
        if not key[1] or key in seen:
            continue
        if key[0] == "tv" and (record.get("season") is None or record.get("episode") is None):
            continue
        seen.add(key)
        selected.append(record)
        if limit is not None and len(selected) >= limit:
            break
    return selected


def show_continue_watching(quiet=False, page=1, paged_widget=False):
    """Only unfinished playback and explicit Up Next; no completed history cards."""
    items = _continue_records(WatchHistory().get_all(), limit=20 if quiet and not paged_widget else None)
    _show_watch_feed(items, "Continue Watching", quiet,
                     "Nothing to continue", "Movies and episodes you start will appear here until completed.",
                     action="continue_watching", page=page, paged_widget=paged_widget)


def show_watched(quiet=False, page=1, paged_widget=False):
    """Completed movies and explicit completed episodes, never an implied whole show."""
    items = [record for record in WatchHistory().get_all() if is_completed(record)
             and (record.get("media_type", "movie") == "movie" or
                  (record.get("season") is not None and record.get("episode") is not None))]
    items.sort(key=lambda record: record.get("timestamp", 0), reverse=True)
    _show_watch_feed(items[:50] if quiet and not paged_widget else items, "Watched", quiet,
                     "Nothing watched yet", "Completed movies and episodes appear here. Marking an item unwatched removes it.",
                     action="watched", page=page, paged_widget=paged_widget)


def _show_watch_feed(items, heading, quiet, empty_title, empty_plot, action, page=1, paged_widget=False):
    total_pages = max(1, (len(items) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = min(max(1, int(page)), total_pages)
    if not quiet or paged_widget:
        items = items[(page - 1) * PAGE_SIZE:page * PAGE_SIZE]
        if total_pages > 1:
            heading += " (page %d/%d)" % (page, total_pages)
    xbmcplugin.setPluginCategory(HANDLE, heading)
    if not items and not quiet:
        _add_empty_hint(empty_title, empty_plot)
    else:
        for record in items:
            url, li = _build_resume_item(record)
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
        content = "movies" if items and all(record.get("media_type") == "movie" for record in items) else "videos"
        xbmcplugin.setContent(HANDLE, content)
        if not quiet or paged_widget:
            _add_page_controls(action, page, total_pages)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def show_recent():
    xbmcplugin.setPluginCategory(HANDLE, "Recently Watched")
    history = WatchHistory()
    # Movies stay individual. TV episodes collapse to one latest card per show;
    # queued Up Next placeholders remain exclusive to Continue Watching.
    items = collapse_recent_items(history.get_recent(limit=50), limit=20)
    if not items:
        _add_empty_hint("Nothing watched yet", "Browse Movies to find something to watch. Your viewing progress will appear here.")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for rec in items:
        if rec.get("media_type") == "tv":
            url, li = _build_recent_tv_show_item(rec)
            is_folder = True
        else:
            url, li = _build_resume_item(rec)
            is_folder = False
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

    xbmcplugin.setContent(HANDLE, _listing_content(items))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Helpers ───────────────────────────────────────────────────────────

def add_content_item(item, show_type_label=False, ctx_override=None):
    """Add a movie or TV show item to the directory listing.

    ``ctx_override`` replaces the default favorites-toggle context entry
    (used by show_favorites, where the item is always removable); trailer
    and Similar Titles entries are appended either way.
    """
    title = item["title"]
    pid = item["pid"]
    slug = item["slug"]
    media_type = item["media_type"]
    poster = item.get("poster", "")
    year = item.get("year", "")
    rating = item.get("rating", "")
    genres = item.get("genres", "")

    # Resolve TMDb info (cache hit in steady state; a callsite may also have
    # prefetched via _prefetch_tmdb). The id feeds AH2's rating badges via
    # TMDb Helper / container 99950; plot/backdrop/vote fill in metadata
    # Flixtor's cards don't carry.
    tmdb_id = item.get("tmdb_id")
    if tmdb_id is None and "tmdb_plot" not in item:
        client = _get_tmdb()
        if client:
            tinfo = client.lookup_cached_info(title, year,
                                       "movie" if media_type == "movie" else "tv")
            tmdb_id = tinfo["tmdb_id"]
            item["tmdb_id"] = tmdb_id
            item["tmdb_plot"] = tinfo["plot"]
            item["tmdb_fanart"] = tinfo["fanart"]
            item["tmdb_vote"] = tinfo["vote"]

    # Build label
    label = title
    if year:
        label = f"{title} ({year})"
    if show_type_label:
        tag = "[COLOR dodgerblue]MOVIE[/COLOR]" if media_type == "movie" else "[COLOR orange]TV[/COLOR]"
        label = f"{tag}  {label}"

    if media_type == "movie":
        url = build_url("play_movie", pid=pid, slug=slug, title=title, poster=poster)
        li = xbmcgui.ListItem(label)
        li.setProperty("IsPlayable", "true")
        is_folder = False
        info = {"title": title, "mediatype": "movie"}
    else:
        url = build_url("seasons", pid=pid, slug=slug, title=title, poster=poster)
        li = xbmcgui.ListItem(label)
        is_folder = True
        info = {"title": title, "mediatype": "tvshow"}

    if year:
        info["year"] = int(year)
    if genres:
        info["genre"] = genres
    plot = item.get("tmdb_plot") or ""
    if plot:
        info["plot"] = plot

    _apply_watch_state(li, info, pid, media_type=media_type)

    li.setInfo("video", info)
    li.setProperty("Flixtor.ItemKind", info["mediatype"])
    if item.get("saved_catalog"):
        li.setProperty("Flixtor.CatalogStatus", "Saved catalog")
    # Use setRating for proper display in Arctic Horizon. Flixtor's own
    # rating wins; TMDb's vote fills the gap for items served without one
    # (recommendation cards, some catalog entries).
    provider = item.get("rating_provider") or "flixtor"
    if rating:
        li.setRating(provider, float(rating), 0, True)
    if item.get("tmdb_vote") and (not rating or provider != "tmdb"):
        li.setRating("tmdb", float(item["tmdb_vote"]), 0, not bool(rating))
    _attach_tmdb_id(li, tmdb_id, media_type)
    fanart = item.get("tmdb_fanart") or poster
    li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    li.setContentLookup(False)

    # Context menus — favorites toggle (Add or Remove) computed against the
    # current Favorites state, so the same long-press always Does The Right
    # Thing instead of duplicating an entry the user already saved.
    if ctx_override is not None:
        ctx = list(ctx_override)
    else:
        ctx = [
            _favorites_context_item(pid, {
                "slug": slug, "media_type": media_type,
                "title": title, "poster": poster, "year": year,
                "rating": rating, "genres": genres,
                "tmdb_id": tmdb_id or "",
            })
        ]
    ctx.extend(_media_actions(li, item))
    ctx.extend(_title_discovery_context_items(pid, slug, media_type, li))
    # Replace Kodi's generic queue/library menu. Those actions operate on the
    # transient plugin ListItem, not Flixtor favorites/history, and create a
    # long list of repeated or ineffective entries on Fire TV.
    _attach_flixtor_context(li, ctx)

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# ── Favorites ────────────────────────────────────────────────────

def show_favorites(quiet=False):
    xbmcplugin.setPluginCategory(HANDLE, "Favorites")
    fav = FavoritesHistory()
    items = fav.get_all()
    if not items:
        _add_empty_hint("No favorites yet", "Browse Movies, then open a title's context menu and choose Add to Flixtor Favorites.")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if not quiet:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        _prefetch_tmdb(items)
    finally:
        if not quiet:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    for item in items:
        # Same builder as every other listing (type tags, plot, fanart,
        # watched state) — only the favorites toggle differs: here the item
        # is always removable.
        item.setdefault("title", "")
        item.setdefault("slug", "")
        item.setdefault("media_type", "movie")
        if not item.get("tmdb_id"):
            item["tmdb_id"] = None
        add_content_item(item, show_type_label=True, ctx_override=[(
            "Remove from Flixtor Favorites",
            "RunPlugin(%s)" % build_url("ctx_remove_favorite", pid=item.get("pid", "")),
        )])

    xbmcplugin.setContent(HANDLE, _listing_content(items))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Recommendations ──────────────────────────────────────────────

def show_recommendations(pid, slug, media_type):
    client = get_client()
    if not client:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Similar Titles")
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        items = client.get_recommendations(pid, slug, media_type)
        _prefetch_tmdb(items)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not items:
        xbmcgui.Dialog().notification("Flixtor", "No recommendations found.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for item in items:
        add_content_item(item)
    xbmcplugin.setContent(HANDLE, _listing_content(items))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


def show_title_context(pid, slug, media_type, title, poster="", year="",
                       rating="", genres=""):
    """Show the exact title selected from AH2's recommendations.

    TMDb Helper normally resolves recommendation playback without changing the
    underlying Kodi container, which makes Stop reveal the original movie.
    This one-item Flixtor directory becomes the post-playback landing page so
    the selected title remains focused and its cast/recommendations are still
    available through the normal view-aware controls.
    """
    item = {
        "pid": str(pid or ""),
        "slug": slug or "",
        "media_type": "movie" if media_type == "movie" else "tv",
        "title": title or "",
        "poster": poster or "",
        "year": year or "",
        "rating": rating or "",
        "genres": genres or "",
    }
    add_content_item(item)
    xbmcplugin.setPluginCategory(HANDLE, title or "Flixtor")
    xbmcplugin.setContent(HANDLE, _listing_content([item]))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Trailers ─────────────────────────────────────────────────────

def _youtube_video_id(value):
    """Accept a video ID or a normal YouTube link without resolving a stream."""
    value = str(value or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", value):
        return value
    try:
        parsed = urllib.parse.urlsplit(value)
        if (parsed.scheme not in ("http", "https") or parsed.username
                or parsed.password or parsed.port is not None):
            return ""
        host = (parsed.hostname or "").lower()
        path = parsed.path.strip("/").split("/")
        if host in ("youtu.be", "www.youtu.be") and len(path) == 1:
            candidate = path[0]
        elif host in ("youtube.com", "www.youtube.com", "m.youtube.com",
                      "youtube-nocookie.com", "www.youtube-nocookie.com"):
            if path == ["watch"]:
                ids = urllib.parse.parse_qs(parsed.query).get("v", [])
                candidate = ids[0] if len(ids) == 1 else ""
            elif len(path) == 2 and path[0] in ("embed", "shorts", "v"):
                candidate = path[1]
            else:
                return ""
        else:
            return ""
    except (TypeError, ValueError):
        return ""
    return candidate if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate) else ""


def _canonical_trailer_url(value):
    """Only hand a single validated video ID to the YouTube add-on."""
    value = str(value or "").strip()
    if any(ord(char) < 32 for char in value):
        return ""
    try:
        parsed = urllib.parse.urlsplit(value)
        if parsed.scheme == "plugin":
            if (parsed.netloc != "plugin.video.youtube"
                    or parsed.path not in ("", "/", "/play", "/play/")):
                return ""
            ids = urllib.parse.parse_qs(parsed.query).get("video_id", [])
            video_id = _youtube_video_id(ids[0]) if len(ids) == 1 else ""
        else:
            video_id = _youtube_video_id(value)
    except (TypeError, ValueError):
        return ""
    return ("plugin://plugin.video.youtube/play/?video_id=" + video_id
            if video_id else "")


def play_trailer(pid, slug, media_type, video_id="", tmdb_id=""):
    if not _has_youtube():
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            _log("trailer: YouTube is disabled")
            if xbmcgui.Dialog().yesno(
                "Flixtor", "YouTube is installed but disabled. Enable it now?"
            ):
                xbmc.executebuiltin("EnableAddon(plugin.video.youtube)")
            return
        _log("trailer: YouTube is not installed")
        if xbmcgui.Dialog().yesno(
            "Flixtor",
            "Trailers require the YouTube addon. Install it now?",
        ):
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
        return
    _log("trailer: lookup started")
    started = time.monotonic()
    try:
        value = _youtube_video_id(video_id)
        if not value and tmdb_id:
            metadata = _get_tmdb()
            if metadata:
                value = metadata.trailer_id(tmdb_id, media_type)
        if not value:
            client = get_client()
            if not client:
                return
            value = client.get_trailer(pid, slug, media_type)
    except Exception as exc:
        _log("trailer: lookup failed (%s)" % type(exc).__name__)
        xbmcgui.Dialog().notification(
            "Flixtor", "Couldn't load this trailer. Please try again.",
            xbmcgui.NOTIFICATION_ERROR)
        return
    _log("trailer: lookup completed in %dms" % ((time.monotonic() - started) * 1000))
    if not value:
        xbmcgui.Dialog().notification("Flixtor", "No trailer available.", xbmcgui.NOTIFICATION_INFO)
        return
    trailer_url = _canonical_trailer_url(value)
    if not trailer_url:
        _log("trailer: invalid YouTube video reference")
        xbmcgui.Dialog().notification(
            "Flixtor", "This trailer link is unavailable. Try another title.",
            xbmcgui.NOTIFICATION_INFO)
        return
    try:
        version = xbmcaddon.Addon("plugin.video.youtube").getAddonInfo("version")
    except Exception:
        version = "unknown"
    _log("trailer: handing video to YouTube %s" % version)
    try:
        xbmc.Player().play(trailer_url)
    except Exception as exc:
        _log("trailer: handoff failed (%s)" % type(exc).__name__)
        xbmcgui.Dialog().notification(
            "Flixtor", "Couldn't start the trailer. Open YouTube to check its setup.",
            xbmcgui.NOTIFICATION_ERROR)


# ── TMDb Helper: search and play ─────────────────────────────────

def search_and_play(title, year="", media_type="movie", season=None, episode=None):
    """Play a TMDb recommendation only when the exact title exists on Flixtor."""
    _log("search_and_play: title=%s year=%s type=%s season=%s episode=%s" %
         (title, year, media_type, season, episode))
    client = get_client()
    if not client:
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except RuntimeError:
            pass
        return
    result = client.search(title) or {}
    if result.get("error"):
        _listing_error_message(result)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    results = result.get("items") or []
    best = select_flixtor_match(results, title, year, media_type)
    if not best:
        candidates = flixtor_match_candidates(results, title, media_type)
        if candidates:
            choice = xbmcgui.Dialog().select("Choose the release year", [
                "%s (%s)" % (item["title"], item.get("year") or "year unknown")
                for item in candidates])
            if choice < 0:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
            best = candidates[choice]
    if not best:
        xbmcgui.Dialog().notification(
            "Flixtor", "This title is not available on Flixtor.",
            xbmcgui.NOTIFICATION_INFO,
        )
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except RuntimeError:
            pass
        return
    return_url = build_url(
        "title_context",
        pid=best["pid"],
        slug=best.get("slug", ""),
        media_type=best.get("media_type", media_type),
        title=best.get("title", title),
        poster=best.get("poster", ""),
        year=best.get("year", year),
        rating=best.get("rating", ""),
        genres=best.get("genres", ""),
    )
    if best["media_type"] == "movie":
        play_movie(
            best["pid"], best["title"], best.get("poster", ""), best["slug"],
            return_url=return_url,
        )
    elif season is not None and episode is not None:
        play_episode(
            best["pid"], int(season), int(episode), best["title"],
            best.get("poster", ""), slug=best["slug"],
            return_url=return_url,
        )
    else:
        # A show-level recommendation opens the show. TMDb Helper supplies
        # season/episode when its episode picker asks us to play a specific one.
        xbmc.executebuiltin(
            "Container.Update(%s)" % build_url("seasons", pid=best["pid"], slug=best["slug"],
                                                 title=best["title"], poster=best.get("poster", ""))
        )


def handle_remote_direction(direction):
    """Legacy route for one-press details; the keymap now uses the service."""
    direction = str(direction or "").casefold()
    native_action = {"down": "Down", "left": "Left"}.get(direction)
    if not native_action:
        return
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    db_type = xbmc.getInfoLabel("ListItem.DBType")
    skin_dir = xbmc.getSkinDir()
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    focused_control_id = next(
        (
            control_id
            for control_id in AH2_DETAILS_CONTROL_IDS
            if xbmc.getCondVisibility("Control.HasFocus(%d)" % control_id)
        ),
        0,
    )
    if should_open_one_press_details(
            folder_path, db_type, skin_dir, direction,
            dialog_id, focused_control_id):
        # The AH2 YouTube recommendation row performs an API search as soon as
        # it loads. Hide it on this Fire TV because no YouTube API key is
        # configured; cast, Flixtor playback and recommendations remain intact.
        xbmc.executebuiltin("Skin.SetBool(Info.DisableYoutube)")
        xbmc.executebuiltin("SetFocus(99996)")
        return
    # Action() dispatches the native UI action directly; it does not synthesize
    # another remote key, so the custom keymap does not recurse.
    xbmc.executebuiltin("Action(%s)" % native_action)


def handle_remote_back(long_press=False):
    """Legacy plug-in route; the resident service handles the keymap."""
    folder_path = xbmc.getInfoLabel("Container.FolderPath")
    dialog_id = xbmcgui.getCurrentWindowDialogId()
    options_menu_open = (
        is_supported_skin(xbmc.getSkinDir())
        and (
            xbmc.getCondVisibility("ControlGroup(9000).HasFocus()")
            or xbmc.getCondVisibility("Control.HasFocus(89000)")
        )
    )
    if should_guard_flixtor_root_back(
            folder_path, dialog_id, options_menu_open=options_menu_open,
            skin_dir=xbmc.getSkinDir()):
        if long_press:
            exit_flixtor()
        else:
            xbmcgui.Dialog().notification(
                "Flixtor",
                "Home screen — hold Back to exit",
                xbmcgui.NOTIFICATION_INFO,
                1800,
            )
        return
    xbmc.executebuiltin("Action(Back)")


def handle_remote_context():
    """Show only the working, add-on-owned actions for a Flixtor title."""
    window = xbmcgui.Window(10000)
    if window.getProperty("Flixtor.ContextActive") == "true":
        return  # An existing dialog owns its snapshot until it closes.
    # Home widgets do not necessarily expose their plug-in as the active
    # container. Only the selected item's explicit ownership marker applies.
    if (xbmcgui.getCurrentWindowId() not in (10000, 10025)
            or is_dialog_open(xbmcgui.getCurrentWindowDialogId())
            or xbmc.getInfoLabel("ListItem.Property(Flixtor.IsMedia)") != "true"):
        # Action() dispatches directly, rather than synthesizing a keypress,
        # so this cannot recurse through the Home/Videos keymap.
        xbmc.executebuiltin("Action(ContextMenu)")
        return
    raw_entries = xbmc.getInfoLabel("ListItem.Property(Flixtor.Context)")
    entries = []
    if raw_entries:
        try:
            payload = json.loads(raw_entries)
            if not isinstance(payload, list):
                raise ValueError("Expected an action list")
            for entry in payload:
                if not isinstance(entry, (list, tuple)) or len(entry) != 2:
                    raise ValueError("Invalid action entry")
                label, command = entry
                if isinstance(label, str) and isinstance(command, str) and label and command:
                    entries.append((label, command))
        except (TypeError, ValueError) as exc:
            _log("remote_context: invalid item actions: %s" % exc)
            entries = []

    # Capture the item's own presentation before the modal takes focus.
    # Delayed helper/container details must never label another title's actions.
    icon = (xbmc.getInfoLabel("ListItem.Art(thumb)")
            or xbmc.getInfoLabel("ListItem.Art(icon)") or xbmc.getInfoLabel("ListItem.Icon"))
    poster = (xbmc.getInfoLabel("ListItem.Art(poster)")
              or xbmc.getInfoLabel("ListItem.Art(tvshow.poster)"))
    snapshot = {
        "Title": xbmc.getInfoLabel("ListItem.Title") or xbmc.getInfoLabel("ListItem.Label"),
        "Poster": poster,
        "Fanart": xbmc.getInfoLabel("ListItem.Art(fanart)") or xbmc.getInfoLabel("ListItem.Art(tvshow.fanart)"),
        "Icon": icon,
        "Plot": xbmc.getInfoLabel("ListItem.Plot"),
    }
    if (xbmc.getInfoLabel("ListItem.Property(Flixtor.IsMedia)") != "true"
            or xbmc.getInfoLabel("ListItem.Property(Flixtor.Context)") != raw_entries):
        return  # Selection changed during capture; never mix identities.
    entries.extend([
        ("Exit Flixtor", "RunPlugin(%s)" % build_url("exit_flixtor")),
        ("Exit Kodi", "RunPlugin(%s)" % build_url("exit_kodi")),
    ])
    choice = -1
    try:
        for name, value in snapshot.items():
            window.setProperty("Flixtor.Context" + name, value)
        window.setProperty("Flixtor.ContextActive", "true")
        choice = xbmcgui.Dialog().contextmenu([label for label, _ in entries])
    finally:
        window.clearProperty("Flixtor.ContextActive")
        for name in snapshot:
            window.clearProperty("Flixtor.Context" + name)
    if 0 <= choice < len(entries):
        label, command = entries[choice]
        _log("remote_context: selected %s" % label)
        xbmc.executebuiltin(command)


# ── Router ────────────────────────────────────────────────────────────

def _title_or_slug(params):
    """Return a non-empty display title: the URL title, or a title-cased slug fallback."""
    title = params.get("title") or ""
    if title:
        return title
    slug = params.get("slug", "")
    if slug:
        return slug.replace("-", " ").replace("_", " ").title()
    return "Flixtor"


def render_widget(base_route, paged_widget=False):
    """Quiet Home-screen listing: no dialogs, prompts, or route state."""
    if base_route is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if base_route == "continue_watching":
        show_continue_watching(quiet=True, paged_widget=paged_widget)
    elif base_route == "watched":
        show_watched(quiet=True, paged_widget=paged_widget)
    elif base_route == "search_history":
        show_search_history()
    elif base_route == "recent":
        show_recent()
    elif base_route == "favorites":
        show_favorites(quiet=True)
    elif base_route == "home":
        do_home(quiet=True, paged_widget=paged_widget)
    else:
        kind, sort, language, _label = _CATALOG_ROUTES[base_route]
        do_catalog(base_route, kind, sort, 1, language=language, quiet=True, paged_widget=paged_widget)


def router():
    # keep_blank_values=True so empty values (e.g. title=) survive as "" instead of
    # being silently dropped, which otherwise causes KeyError on params["title"].
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?"), keep_blank_values=True))
    action = params.get("action")
    if action == "search_account":
        ADDON.openSettings()
        return
    if action == "search_input":
        # RunPlugin input is not a directory. Cancellation must leave Home
        # and its focus, route marker, and parent-folder preference untouched.
        do_search_input(initial_query=params.get("q", ""))
        return
    if action == "set_watched":
        do_set_watched(params)
        return
    if action == "play_next_episode":
        do_play_next_episode(params)
        return
    if action == "remote_context":
        handle_remote_context()
        return
    if is_widget_action(action):
        # Widgets load in the background on Kodi Home: never touch Flixtor's
        # route marker, parent-folder preference, notices, or dialogs.
        render_widget(widget_base_route(action), paged_widget=params.get("paging") == "true")
        return
    # The resident service cannot rely on Container.FolderPath under every
    # Fire TV skin/launch path. Record the plug-in route explicitly instead.
    route_window = xbmcgui.Window(10000)
    if action in (None, "search", "new_search") and skin_owns_home(xbmc.getSkinDir()):
        # This skin owns the appliance Home. Never rebuild the legacy root
        # over it, including an old root/Search bookmark or folder parent.
        # Compatibility Search folders return quietly: Back must never prompt.
        route_window.setProperty(ROOT_ROUTE_PROPERTY, "child")
        set_parent_folder_items(True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("ActivateWindow(Home)")
        return
    utility_action = action == "show_update_notice"
    utility_action = utility_action or action == "playback_setup"
    if action is None:
        # Kodi has no per-directory flag for its automatic ``..`` item. Toggle
        # the global preference only while building this appliance-style root;
        # every child route and explicit exit restores normal Kodi lists.
        route_window.setProperty(ROOT_ROUTE_PROPERTY, "root")
        set_parent_folder_items(False)
    elif not utility_action:
        set_parent_folder_items(True)
    if (
        action is not None
        and action not in {
            "exit_flixtor", "exit_kodi", "show_update_notice", "playback_setup"
        }
    ):
        # Exit actions are launched from the add-on-owned long-press menu.
        # Preserve the underlying route while its confirmation dialog is open.
        route_window.setProperty(ROOT_ROUTE_PROPERTY, "child")
    _log("router: action=%s" % action)

    if action is None:
        main_menu()
    elif action == "show_update_notice":
        _show_update_notice(params.get("version", ""))
    elif action == "playback_setup":
        do_optimize_playback(automatic=True)
    elif action == "exit_flixtor":
        exit_flixtor()
    elif action == "exit_kodi":
        exit_kodi()
    elif action == "continue_watching":
        show_continue_watching(page=int(params.get("page", 1)))
    elif action == "watched":
        show_watched(page=int(params.get("page", 1)))
    elif action == "recent":
        show_recent()
    elif action == "search":
        do_search()
    elif action == "search_history":
        show_search_history()
    elif action == "new_search":
        do_new_search(initial_query=params.get("q", ""))
    elif action == "setup_voice_keyboard":
        do_setup_voice_keyboard()
    elif action == "test_voice_keyboard":
        do_test_voice_keyboard()
    elif action == "search_execute":
        do_search_execute(params["q"], page=int(params.get("page", 1)))
    elif action == "remove_search":
        do_remove_search(params["q"])
    elif action == "home":
        do_home(page=int(params.get("page", 0)))
    elif action == "movies":
        show_catalog_sort_picker("movies")
    elif action == "tvshows":
        show_catalog_sort_picker("tvshows")
    elif action == "genres_movies":
        show_genre_picker("movies")
    elif action == "genres_tvshows":
        show_genre_picker("tvshows")
    elif action in _CATALOG_ROUTES:
        kind, sort, language, _label = _CATALOG_ROUTES[action]
        do_catalog(action, kind, sort, int(params.get("page", 1)),
                   genre=params.get("genre", "all"),
                   language=params.get("language", language))
    elif action == "seasons":
        show_seasons(params["pid"], params.get("slug", ""), _title_or_slug(params),
                     params.get("poster", ""))
    elif action == "title_context":
        show_title_context(
            params["pid"], params.get("slug", ""),
            params.get("media_type", "movie"), _title_or_slug(params),
            params.get("poster", ""), params.get("year", ""),
            params.get("rating", ""), params.get("genres", ""),
        )
    elif action == "episodes":
        show_episodes(
            params["pid"], params.get("slug", ""), params["season"],
            _title_or_slug(params), params.get("poster", ""),
        )
    elif action == "play_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""))
    elif action == "resume_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""), resume_mode="resume")
    elif action == "start_movie":
        play_movie(params["pid"], _title_or_slug(params), params.get("poster", ""),
                   params.get("slug", ""), resume_mode="start")
    elif action == "play_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            return_url=params.get("return_url", ""),
            episode_title=params.get("episode_title", ""),
        )
    elif action == "resume_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            resume_mode="resume",
            return_url=params.get("return_url", ""),
            episode_title=params.get("episode_title", ""),
        )
    elif action == "start_episode":
        play_episode(
            params["pid"], params["season"], params["episode"],
            _title_or_slug(params), params.get("poster", ""), slug=params.get("slug", ""),
            resume_mode="start",
            return_url=params.get("return_url", ""),
            episode_title=params.get("episode_title", ""),
        )
    elif action == "ctx_remove_history":
        season = params.get("season") or None
        episode = params.get("episode") or None
        WatchHistory().remove_item(params["pid"], season=season, episode=episode)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_remove_show_history":
        WatchHistory().remove_show(params["pid"])
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_clear_resume":
        season = params.get("season") or None
        episode = params.get("episode") or None
        WatchHistory().clear_resume(params["pid"], season=season, episode=episode)
        xbmc.executebuiltin("Container.Refresh")
    elif action == "favorites":
        show_favorites()
    elif action == "ctx_add_favorite":
        FavoritesHistory().add({
            "pid": params["pid"], "slug": params.get("slug", ""),
            "media_type": params.get("media_type", "movie"),
            "title": params.get("title", ""), "poster": params.get("poster", ""),
            "year": params.get("year", ""), "rating": params.get("rating", ""),
            "genres": params.get("genres", ""),
            "tmdb_id": params.get("tmdb_id") or "",
        })
        xbmcgui.Dialog().notification("Flixtor", "Added to Favorites", xbmcgui.NOTIFICATION_INFO, 1500)
        xbmcgui.Window(10000).setProperty("Flixtor.FavoritesVersion", str(time.time_ns()))
        # Refresh so the long-press toggle flips from "Add" to "Remove" without
        # the user navigating away and back.
        xbmc.executebuiltin("Container.Refresh")
    elif action == "ctx_remove_favorite":
        FavoritesHistory().remove(params["pid"])
        xbmcgui.Window(10000).setProperty("Flixtor.FavoritesVersion", str(time.time_ns()))
        xbmc.executebuiltin("Container.Refresh")
    elif action == "recommendations":
        show_recommendations(params["pid"], params.get("slug", ""), params.get("media_type", "movie"))
    elif action == "play_trailer":
        play_trailer(params["pid"], params.get("slug", ""), params.get("media_type", "movie"),
                     video_id=params.get("video_id", ""), tmdb_id=params.get("tmdb_id", ""))
    elif action == "search_and_play":
        search_and_play(params.get("title", ""), params.get("year", ""),
                        params.get("media_type", "movie"),
                        params.get("season"), params.get("episode"))
    elif action == "remote_down":
        handle_remote_direction("down")
    elif action == "remote_left":
        handle_remote_direction("left")
    elif action == "remote_back":
        handle_remote_back(long_press=False)
    elif action == "remote_back_long":
        handle_remote_back(long_press=True)
    elif action == "sign_out":
        do_sign_out()
    elif action == "backup_library":
        do_backup_library()
    elif action == "restore_library":
        do_restore_library()
    elif action == "health_check":
        do_health_check()
    elif action == "clear_watch_history":
        do_clear_watch_history()
    elif action == "clear_favorites":
        do_clear_favorites()
    elif action == "clear_searches":
        do_clear_searches()
    elif action == "clear_tmdb_cache":
        do_clear_tmdb_cache()
    elif action == "clear_image_cache":
        do_clear_image_cache()
    elif action == "cache_usage":
        do_show_cache_usage()
    elif action == "check_updates":
        do_check_updates()
    elif action == "optimize_playback":
        do_optimize_playback()
    elif action == "restore_playback":
        do_restore_playback()
    elif action == "clear_subtitles":
        do_clear_subtitles()
    elif action == "clear_update_zips":
        do_clear_update_zips()


if __name__ == "__main__":
    router()
