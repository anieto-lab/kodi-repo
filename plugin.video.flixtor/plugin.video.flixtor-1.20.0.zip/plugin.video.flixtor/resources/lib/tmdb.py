"""TMDb v3 search client — resolves Flixtor (title, year, media_type) → TMDb ID.

The addon attaches the resulting ID to every ListItem via ``setUniqueIDs``. Arctic
Horizon 2's rating strip (IMDb / TMDb / Metacritic / RT / Popcorn / Letterboxd)
is populated by TMDb Helper's service monitor reading ``Container(99950)``, and
TMDb Helper needs a ``uniqueid.tmdb`` or ``uniqueid.imdb`` on the focused item to
enrich it. Flixtor's HTML exposes neither, so this module looks them up and
caches indefinitely to disk.

Zero external dependencies — urllib + concurrent.futures from stdlib only.
"""

import concurrent.futures
import json
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon

    def _log(msg):
        xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)

    def _cache_path():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        d = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return os.path.join(d, "tmdb_cache.json")

    def _get_user_api_key():
        try:
            return (xbmcaddon.Addon("plugin.video.flixtor").getSetting("tmdb_api_key") or "").strip()
        except Exception:
            return ""
except ImportError:
    def _log(msg):
        print("FLIXTOR: " + msg)

    def _cache_path():
        d = os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata")
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return os.path.join(d, "tmdb_cache.json")

    def _get_user_api_key():
        return ""


TMDB_API = "https://api.themoviedb.org/3"

# Widely-known public TMDb v3 read key shipped with TMDb Helper. Read-only usage
# (search + metadata fetch) is covered by TMDb's API terms for free tier. If
# revoked, the addon silently degrades — lookups return None and the rating strip
# stays empty (today's behavior). Users can override via the settings key
# `tmdb_api_key` in Settings > Account.
_DEFAULT_TMDB_KEY = "a07324c669cac4d96789197134ce272b"

_SEARCH_TIMEOUT = 5
_UA = "plugin.video.flixtor/1 (Kodi)"

# Non-identifying punctuation stripped when normalizing titles for the cache
# key. Keeps unicode letters (é, ñ, ö, etc.) so cache keys round-trip cleanly.
_NORMALIZE_STRIP = re.compile(r"[^\w\s]", re.UNICODE)


def _normalize_title(title):
    if not title:
        return ""
    return _NORMALIZE_STRIP.sub("", title).lower().strip()


def _cache_key(title, year, media_type):
    return "|".join((_normalize_title(title), str(year or ""), media_type or ""))


class TmdbClient:
    def __init__(self):
        self._mem_cache = None
        self._loaded = False
        self._api_key = _get_user_api_key() or _DEFAULT_TMDB_KEY

    # ── Cache I/O ────────────────────────────────────────────────────

    def _ensure_loaded(self):
        if self._loaded:
            return
        self._loaded = True
        try:
            with open(_cache_path(), "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                self._mem_cache = data
                return
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        self._mem_cache = {}

    def _save(self):
        if self._mem_cache is None:
            return
        path = _cache_path()
        tmp = path + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(self._mem_cache, f)
            os.replace(tmp, path)
        except OSError as exc:
            _log("tmdb: cache write failed: %s" % exc)

    def clear_cache(self):
        self._mem_cache = {}
        self._loaded = True
        self._save()

    # ── Public lookup API ────────────────────────────────────────────

    def lookup(self, title, year, media_type):
        """Return the TMDb integer id for (title, year, media_type) or None.

        Caches both positive and negative results so the same call is cheap
        forever. media_type must be "movie" or "tv". Year may be "" or None.
        """
        if not title or media_type not in ("movie", "tv") or not self._api_key:
            return None
        key = _cache_key(title, year, media_type)
        self._ensure_loaded()
        cached = self._mem_cache.get(key)
        if cached is not None:
            # Negative hits are stored as {"miss": true} so we never re-query.
            if cached.get("miss"):
                return None
            return cached.get("tmdb_id") or None

        tmdb_id = self._search_online(title, year, media_type)
        if tmdb_id:
            self._mem_cache[key] = {"tmdb_id": tmdb_id}
        else:
            self._mem_cache[key] = {"miss": True}
        self._save()
        return tmdb_id

    def lookup_many(self, items):
        """Resolve TMDb IDs for a batch of items in parallel.

        Each ``item`` is expected to have ``title``, ``year``, ``media_type``
        keys. Mutates each dict in place, setting ``item["tmdb_id"]`` to the
        resolved id (or None if no match). Cached items skip the thread pool.
        Returns the list for chaining.
        """
        if not items or not self._api_key:
            return items
        self._ensure_loaded()

        # Split into cached vs. needs-network.
        pending = []
        for item in items:
            title = item.get("title", "")
            year = item.get("year", "")
            mtype = "movie" if item.get("media_type") == "movie" else "tv"
            if not title:
                item["tmdb_id"] = None
                continue
            key = _cache_key(title, year, mtype)
            cached = self._mem_cache.get(key)
            if cached is not None:
                item["tmdb_id"] = None if cached.get("miss") else cached.get("tmdb_id")
                continue
            pending.append((item, title, year, mtype, key))

        if not pending:
            return items

        t0 = time.time()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = {
                pool.submit(self._search_online, title, year, mtype): (item, key)
                for item, title, year, mtype, key in pending
            }
            for fut in concurrent.futures.as_completed(futures):
                item, key = futures[fut]
                try:
                    tmdb_id = fut.result()
                except Exception as exc:
                    _log("tmdb: lookup error: %s" % exc)
                    tmdb_id = None
                item["tmdb_id"] = tmdb_id
                if tmdb_id:
                    self._mem_cache[key] = {"tmdb_id": tmdb_id}
                else:
                    self._mem_cache[key] = {"miss": True}

        self._save()
        _log("tmdb: batch-looked-up %d titles in %.2fs" % (len(pending), time.time() - t0))
        return items

    # ── Network ──────────────────────────────────────────────────────

    def _search_online(self, title, year, media_type):
        params = {
            "api_key": self._api_key,
            "query": title,
            "include_adult": "false",
            "language": "en-US",
        }
        if year:
            if media_type == "movie":
                params["year"] = str(year)
            else:
                params["first_air_date_year"] = str(year)
        url = "%s/search/%s?%s" % (TMDB_API, media_type, urllib.parse.urlencode(params))
        req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=_SEARCH_TIMEOUT) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, socket.timeout, ValueError) as exc:
            _log("tmdb: search failed for %r (%s): %s" % (title, media_type, exc))
            return None
        results = payload.get("results") or []
        if not results:
            return None
        # TMDb returns results sorted by popularity; the first is the right
        # answer for well-known titles. Tiebreaker falls out naturally.
        top = results[0]
        tmdb_id = top.get("id")
        try:
            return int(tmdb_id) if tmdb_id else None
        except (TypeError, ValueError):
            return None
