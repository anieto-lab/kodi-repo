"""Flixtor API client — handles auth, browsing, search, and stream resolution."""

import base64
import codecs
import json
import os
import re
import time
import urllib.error
import urllib.request
import urllib.parse
import http.cookiejar

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    def _log(msg):
        xbmc.log("FLIXTOR: " + msg, xbmc.LOGINFO)
    def _cookie_path():
        addon = xbmcaddon.Addon("plugin.video.flixtor")
        d = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return os.path.join(d, "cookies.json")
except ImportError:
    def _log(msg):
        print("FLIXTOR: " + msg)
    def _cookie_path():
        d = os.path.join(os.path.dirname(__file__), "..", "..", "test_userdata")
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return os.path.join(d, "cookies.json")


BASE = "https://flixtor.to"
IMG_BASE = "https://img.xcdn.to/t/p"
VIDEO_AJAX = BASE + "/ajax/v4"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36"
)

# Cache TTL in seconds
HOME_CACHE_TTL = 300  # 5 minutes
SHOW_CACHE_TTL = 600  # 10 minutes

_MONTH_MAP = {
    "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04",
    "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
    "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12",
}


def _parse_flixtor_date(raw):
    """Convert Flixtor's 'Thu, Jan 8th, 2026' format to ISO 'YYYY-MM-DD'.

    Kodi's ListItem.setInfo aired field needs ISO — if given a non-ISO string,
    Arctic Horizon 2 falls back to a sentinel year (1996) for the air date.
    Returns '' if the input can't be parsed.
    """
    if not raw:
        return ""
    m = re.search(
        r'(\w{3,}),?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})',
        raw,
    )
    if not m:
        return ""
    month_num = _MONTH_MAP.get(m.group(2))
    if not month_num:
        return ""
    return "%s-%s-%02d" % (m.group(4), month_num, int(m.group(3)))


class FlixtorClient:
    def __init__(self, email, password):
        self.email = email
        self.password = password
        self._cj = http.cookiejar.CookieJar()
        self._opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self._cj)
        )
        self._logged_in = False
        self._cache = {}
        # Try to restore session from persistent cookies
        self._load_cookies()

    def _load_cookies(self):
        """Load saved cookies from disk to avoid re-login on every plugin invocation."""
        try:
            with open(_cookie_path(), "r") as f:
                data = json.load(f)
            if data.get("email") != self.email:
                return  # Different account, ignore
            if time.time() - data.get("saved_at", 0) > 86400:
                return  # Older than 24 hours, ignore
            # Reconstruct cookies
            for c in data.get("cookies", []):
                cookie = http.cookiejar.Cookie(
                    version=0, name=c["name"], value=c["value"],
                    port=None, port_specified=False,
                    domain=c["domain"], domain_specified=True, domain_initial_dot=c["domain"].startswith("."),
                    path=c.get("path", "/"), path_specified=True,
                    secure=c.get("secure", False), expires=c.get("expires"),
                    discard=c.get("expires") is None,
                    comment=None, comment_url=None, rest={}, rfc2109=False,
                )
                self._cj.set_cookie(cookie)
            if self._has_cookie("vipLogin"):
                self._logged_in = True
                _log("login: restored session from saved cookies")
        except (FileNotFoundError, json.JSONDecodeError, OSError, KeyError):
            pass

    def _save_cookies(self):
        """Persist cookies to disk so subsequent plugin processes skip login."""
        try:
            cookies = []
            for c in self._cj:
                cookies.append({
                    "name": c.name, "value": c.value,
                    "domain": c.domain, "path": c.path,
                    "secure": c.secure, "expires": c.expires,
                })
            data = {"email": self.email, "saved_at": time.time(), "cookies": cookies}
            path = _cookie_path()
            tmp = path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f)
            os.replace(tmp, path)
        except OSError as e:
            _log("save_cookies: error: %s" % e)

    def _get_cached(self, key, ttl):
        if key in self._cache:
            ts, data = self._cache[key]
            if time.time() - ts < ttl:
                return data
        return None

    def _set_cached(self, key, data, ttl):
        self._cache[key] = (time.time(), data)
        now = time.time()
        self._cache = {
            k: (t, d) for k, (t, d) in self._cache.items()
            if now - t < max(HOME_CACHE_TTL, SHOW_CACHE_TTL) * 2
        }
        return data

    # ── HTTP helpers ──────────────────────────────────────────────────

    def _get(self, url, headers=None, params=None):
        """GET request with cookie persistence."""
        if params:
            url = url + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url)
        req.add_header("User-Agent", UA)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        resp = self._opener.open(req, timeout=30)
        return resp.read().decode("utf-8", errors="replace")

    def _post_json(self, url, data, headers=None):
        """POST JSON with cookie persistence."""
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("User-Agent", UA)
        req.add_header("Content-Type", "application/json")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        resp = self._opener.open(req, timeout=30)
        return resp.read().decode("utf-8", errors="replace")

    def _has_cookie(self, name):
        for cookie in self._cj:
            if cookie.name == name:
                return True
        return False

    # ── auth ──────────────────────────────────────────────────────────

    def login(self):
        """Returns True on success, False on credential failure, or "network_error" on network failure."""
        if self._logged_in:
            return True
        _log("login: attempting for %s" % self.email)
        try:
            self._get(BASE + "/viplogin")
        except Exception as e:
            _log("login: network error loading login page: %s" % e)
            return "network_error"
        try:
            self._post_json(
                BASE + "/ajax/viplogin",
                {"uname": self.email, "passw": self.password},
                headers={
                    "Referer": BASE + "/viplogin",
                    "X-Requested-With": "XMLHttpRequest",
                },
            )
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                _log("login: credentials rejected (HTTP %d)" % e.code)
                return False
            _log("login: network error on login POST: %s" % e)
            return "network_error"
        except Exception as e:
            _log("login: network error on login POST: %s" % e)
            return "network_error"
        self._logged_in = self._has_cookie("vipLogin")
        _log("login: %s" % ("success" if self._logged_in else "FAILED"))
        if self._logged_in:
            self._save_cookies()
        return self._logged_in

    def _ensure_login(self):
        if not self._logged_in:
            self.login()

    def _relogin(self):
        """Force a fresh login (clear cookies, cache, and logged-in flag)."""
        _log("relogin: clearing session and re-authenticating")
        self._logged_in = False
        self._cj.clear()
        return self.login()

    def _looks_like_auth_failure(self, html):
        """Detect if a response indicates the session expired."""
        if not html:
            return False
        if "viplogin" in html and len(html) < 1000:
            return True
        if "<title>Login" in html or "<title>VIP Login" in html:
            return True
        return False

    # ── decoding ──────────────────────────────────────────────────────

    @staticmethod
    def _decode_video_response(encoded):
        """ROT13 -> base64 -> char-shift decode, matching flixtor's main.min.js."""
        rot13 = codecs.encode(encoded, "rot_13")
        raw = base64.b64decode(rot13).decode("utf-8")
        out = []
        for ch in raw:
            code = ord(ch)
            if 33 <= code <= 126:
                out.append(chr(33 + (code + 14) % 94))
            else:
                out.append(ch)
        return "".join(out)

    # ── search ────────────────────────────────────────────────────────

    def search(self, query, sort="relevance", page=1):
        """Full paginated search across movies + TV shows.

        Hits /ajax/show/search/{q}/from/.../{sort}/page/{N}, which returns 24
        cflip cards per page (mixed media types) and pagination markers
        (data-p="N"). Reuses the catalog shell warm-up — same /show/movies/all
        gating applies. The legacy /ajax/psearch typeahead capped at 5 results
        and missed common titles like Ghost (1990).

        Returns {"items": [...], "page": int, "total_pages": int}.
        """
        encoded = urllib.parse.quote(query.strip(), safe="")
        key = "search:%s:%s:%d" % (encoded, sort, page)
        cached = self._get_cached(key, HOME_CACHE_TTL)
        if cached:
            _log("search cache hit: %s" % key)
            return cached
        _log("search: query=%s sort=%s page=%d" % (query, sort, page))
        self._ensure_login()
        shell_url = "%s/show/movies/all" % BASE
        path = (
            "/ajax/show/search/%s/from/1800/to/2099/rating/0/votes/0"
            "/language/all/type/all/genre/all/%s/page/%d"
        ) % (encoded, sort, page)
        headers = {
            "Accept": "text/html, */*; q=0.01",
            "Referer": shell_url,
            "X-Requested-With": "XMLHttpRequest",
        }
        # Shares the catalog warm-up: search + catalog both gate on having
        # visited /show/{kind}/all in the same session, else HTTP 444.
        shell_flag = "catalog_shell:movies"
        html = None
        for attempt in range(2):
            if self._cache.get(shell_flag) is None:
                try:
                    self._get(shell_url, headers={"Referer": BASE + "/"})
                    self._cache[shell_flag] = (time.time(), True)
                except Exception as e:
                    _log("search: shell visit failed: %s" % e)
            try:
                html = self._get(BASE + path, headers=headers)
                break
            except urllib.error.HTTPError as e:
                if e.code == 444 and attempt == 0:
                    _log("search: HTTP 444, re-warming shell")
                    self._cache.pop(shell_flag, None)
                    continue
                _log("search: HTTP error: %s" % e)
                return {"items": [], "page": page, "total_pages": 0}
            except Exception as e:
                _log("search: network error: %s" % e)
                return {"items": [], "page": page, "total_pages": 0}
        if html is None:
            return {"items": [], "page": page, "total_pages": 0}
        if self._looks_like_auth_failure(html):
            _log("search: auth failure, re-logging in")
            if self._relogin():
                self._cache.pop(shell_flag, None)
                try:
                    self._get(shell_url, headers={"Referer": BASE + "/"})
                    self._cache[shell_flag] = (time.time(), True)
                    html = self._get(BASE + path, headers=headers)
                except Exception as e:
                    _log("search: network error after relogin: %s" % e)
                    return {"items": [], "page": page, "total_pages": 0}
        items = self._parse_home_html(html, None)
        total_pages = page
        for m in re.findall(r'data-p="(\d+)"', html):
            n = int(m)
            if n > total_pages:
                total_pages = n
        result = {"items": items, "page": page, "total_pages": total_pages}
        _log("search: page %d/%d, %d items" % (page, total_pages, len(items)))
        return self._set_cached(key, result, HOME_CACHE_TTL)

    # ── browse (home page, cached) ────────────────────────────────────

    def _fetch_home_html(self):
        cached = self._get_cached("home_html", HOME_CACHE_TTL)
        if cached:
            _log("browse: home cache hit")
            return cached
        _log("browse: fetching home page")
        self._ensure_login()
        try:
            html = self._get(BASE + "/home", headers={"Referer": BASE})
        except Exception as e:
            _log("browse: network error: %s" % e)
            return ""
        if self._looks_like_auth_failure(html):
            _log("browse: auth failure detected, re-logging in")
            if self._relogin():
                try:
                    html = self._get(BASE + "/home", headers={"Referer": BASE})
                except Exception as e:
                    _log("browse: network error after relogin: %s" % e)
                    return ""
        return self._set_cached("home_html", html, HOME_CACHE_TTL)

    def browse_home(self, filter_type=None):
        html = self._fetch_home_html()
        return self._parse_home_html(html, filter_type)

    def get_genres(self, kind):
        """Return alphabetized genre names for kind ('movies' | 'tvshows').

        Scraped from the catalog shell page's Genre dropdown (data-gn attrs).
        Reuses that fetch to mark the catalog session as warmed, so a follow-up
        browse_catalog() call can skip its own warm-up visit.
        """
        cache_key = "genres:" + kind
        cached = self._get_cached(cache_key, SHOW_CACHE_TTL)
        if cached is not None:
            return cached
        self._ensure_login()
        shell_url = "%s/show/%s/all" % (BASE, kind)
        try:
            html = self._get(shell_url, headers={"Referer": BASE + "/"})
        except Exception as e:
            _log("genres: fetch failed for %s: %s" % (kind, e))
            return []
        self._cache["catalog_shell:" + kind] = (time.time(), True)
        m = re.search(r'<div class="btn-group px-1 genre">(.*?)</div></div>', html, re.S)
        if not m:
            _log("genres: dropdown block not found for %s" % kind)
            return []
        names = sorted(n for n in re.findall(r'data-gn="([^"]+)"', m.group(1)) if n != "all")
        return self._set_cached(cache_key, names, SHOW_CACHE_TTL)

    # ── browse (full catalog, paginated, cached) ──────────────────────

    def browse_catalog(self, kind, sort="latest", page=1, genre="all", language="all"):
        """Fetch one page of Flixtor's full catalog.

        kind: "movies" | "tvshows" | "episodes" (matches Flixtor's /show/ path).
        sort: "latest" | "best" | "name" | "new".
        page: 1-based.
        language: ISO 639-1 code from the catalog's spoken-language filter
            (e.g. "es" → Spanish-language originals, ~480 movies). The dropdown
            on the shell page exposes 56+ language codes; "all" disables the
            filter. This is the spoken-language filter from Flixtor's nav, so
            results are originals in that language — not dubs.
        Returns {"items": [...], "page": int, "total_pages": int}.
        """
        key = "catalog:%s:%s:%s:%s:%d" % (kind, sort, language, genre, page)
        cached = self._get_cached(key, HOME_CACHE_TTL)
        if cached:
            _log("catalog cache hit: %s" % key)
            return cached
        _log("catalog: kind=%s sort=%s lang=%s page=%d" % (kind, sort, language, page))
        self._ensure_login()
        shell_url = "%s/show/%s/all" % (BASE, kind)
        path = (
            "/ajax/show/%s/all/from/1800/to/2099/rating/0/votes/0"
            "/language/%s/type/all/genre/%s/%s/page/%d"
        ) % (kind, language, genre, sort, page)
        headers = {
            "Accept": "text/html, */*; q=0.01",
            "Referer": shell_url,
            "X-Requested-With": "XMLHttpRequest",
        }
        # The AJAX endpoint returns HTTP 444 unless the browser has visited the
        # /show/{kind}/all shell page in the same session. Warm up lazily once
        # per (client, kind), and fall back to a reset-and-retry if the server
        # forgets the session state.
        shell_flag = "catalog_shell:%s" % kind
        html = None
        for attempt in range(2):
            if self._cache.get(shell_flag) is None:
                try:
                    self._get(shell_url, headers={"Referer": BASE + "/"})
                    self._cache[shell_flag] = (time.time(), True)
                except Exception as e:
                    _log("catalog: shell visit failed: %s" % e)
            try:
                html = self._get(BASE + path, headers=headers)
                break
            except urllib.error.HTTPError as e:
                if e.code == 444 and attempt == 0:
                    _log("catalog: HTTP 444, re-warming shell")
                    self._cache.pop(shell_flag, None)
                    continue
                _log("catalog: HTTP error: %s" % e)
                return {"items": [], "page": page, "total_pages": 0}
            except Exception as e:
                _log("catalog: network error: %s" % e)
                return {"items": [], "page": page, "total_pages": 0}
        if html is None:
            return {"items": [], "page": page, "total_pages": 0}
        if self._looks_like_auth_failure(html):
            _log("catalog: auth failure, re-logging in")
            if self._relogin():
                self._cache.pop(shell_flag, None)
                try:
                    self._get(shell_url, headers={"Referer": BASE + "/"})
                    self._cache[shell_flag] = (time.time(), True)
                    html = self._get(BASE + path, headers=headers)
                except Exception as e:
                    _log("catalog: network error after relogin: %s" % e)
                    return {"items": [], "page": page, "total_pages": 0}
        items = self._parse_home_html(html, None)
        total_pages = page
        for m in re.findall(r'data-p="(\d+)"', html):
            n = int(m)
            if n > total_pages:
                total_pages = n
        result = {"items": items, "page": page, "total_pages": total_pages}
        return self._set_cached(key, result, HOME_CACHE_TTL)

    @staticmethod
    def _parse_home_html(html, filter_type):
        results = []
        seen = set()
        cards = re.findall(
            r'<div\s+class="cflip[^"]*"\s+data-href="(/watch/(movie|tv)/(\d+)/([^"]+))"(.*?)</div>\s*</div>\s*</div>\s*</div>\s*</div>',
            html, re.DOTALL,
        )
        for path, media_type, pid, slug, card_html in cards:
            if filter_type and media_type != filter_type:
                continue
            if pid in seen:
                continue
            seen.add(pid)
            title = slug.replace("-", " ").title()
            tm = re.search(r'card-footer[^>]*>([^<]+)<', card_html)
            if tm:
                title = tm.group(1).strip()
            else:
                tm2 = re.search(r'class="[^"]*title[^"]*"[^>]*>([^<]+)<', card_html)
                if tm2:
                    title = tm2.group(1).strip()
            img_m = re.search(r'src="(https://img\.xcdn\.to/t/p/w342[^"]+)"', card_html)
            poster = img_m.group(1).replace("/w342/", "/w500/") if img_m else ""
            year_m = re.search(r'badge[^>]*>(\d{4})<', card_html)
            year = year_m.group(1) if year_m else ""
            rating_m = re.search(r'fa-star[^>]*></span>([\d.]+)', card_html)
            rating = rating_m.group(1) if rating_m else ""
            genre_m = re.search(r'genres[^>]*>([^<]+)<', card_html)
            genres = genre_m.group(1).strip() if genre_m else ""
            results.append({
                "title": title, "pid": pid, "slug": slug,
                "media_type": media_type, "poster": poster,
                "year": year, "rating": rating, "genres": genres,
            })
        return results

    # ── TV show seasons & episodes (cached) ───────────────────────────

    def _fetch_show_html(self, pid, slug):
        key = "show_%s" % pid
        cached = self._get_cached(key, SHOW_CACHE_TTL)
        if cached:
            return cached
        _log("fetch show: pid=%s" % pid)
        self._ensure_login()
        try:
            html = self._get(
                "%s/watch/tv/%s/%s" % (BASE, pid, slug),
                headers={"Referer": BASE + "/home"},
            )
        except Exception as e:
            _log("fetch show: network error: %s" % e)
            return ""
        if self._looks_like_auth_failure(html):
            _log("fetch show: auth failure detected, re-logging in")
            if self._relogin():
                try:
                    html = self._get(
                        "%s/watch/tv/%s/%s" % (BASE, pid, slug),
                        headers={"Referer": BASE + "/home"},
                    )
                except Exception as e:
                    _log("fetch show: network error after relogin: %s" % e)
                    return ""
        return self._set_cached(key, html, SHOW_CACHE_TTL)

    def get_seasons(self, pid, slug):
        html = self._fetch_show_html(pid, slug)
        seasons = {}
        show_pid = str(pid)
        # The show page mixes two kinds of episode cards with identical data-pes/
        # data-pep markup: (1) this show's own episodes, and (2) "similar shows"
        # episode cards pointing to unrelated titles. The distinguishing signal is
        # that similar-show cards contain a /watch/tv/OTHERPID/ link to a different
        # show. Legit episode cards have no such link (you're already on the show
        # page) — so a match whose trailing context contains a /watch/tv/ link to
        # a pid != show_pid is filtered out.
        matches = list(re.finditer(
            r'data-pes="(\d+)"[^>]*data-pep="(\d+)"', html
        ))
        for i, match in enumerate(matches):
            next_start = matches[i + 1].start() if i + 1 < len(matches) else len(html)
            suffix = html[match.end():min(next_start, match.end() + 600)]
            link_m = re.search(r'/watch/tv/(\d+)/', suffix)
            if link_m and link_m.group(1) != show_pid:
                continue
            s, e = int(match.group(1)), int(match.group(2))
            seasons.setdefault(s, set()).add(e)
        return {s: sorted(eps) for s, eps in sorted(seasons.items())}

    def get_episodes(self, pid, slug, season):
        html = self._fetch_show_html(pid, slug)
        episodes = []
        seen = set()
        for row_match in re.finditer(
            r'<tr[^>]*data-pes="' + str(season) + r'"[^>]*data-pep="(\d+)"[^>]*>(.*?)</tr>',
            html, re.DOTALL,
        ):
            ep_num = int(row_match.group(1))
            if ep_num in seen:
                continue
            seen.add(ep_num)
            row_html = row_match.group(2)
            title_m = re.search(r'class="epTitle"[^>]*>([^<]+)<', row_html)
            ep_title = title_m.group(1).strip() if title_m else ""
            date_m = re.search(r'content="([^"]+)"[^>]*class="middle nowrap"', row_html)
            if not date_m:
                date_m = re.search(r'class="middle nowrap".*?content="([^"]+)"', row_html, re.DOTALL)
            air_date = date_m.group(1).strip() if date_m else ""
            if not air_date:
                date_m2 = re.search(r'hidden-lg-down">([^<]+)<', row_html)
                air_date = date_m2.group(1).strip() if date_m2 else ""
            thumb_m = re.search(r'data-img="([^"]+)"', row_html)
            thumb = IMG_BASE + "/w300" + thumb_m.group(1) if thumb_m else ""
            episodes.append({
                "episode": ep_num, "title": ep_title,
                "air_date": _parse_flixtor_date(air_date), "thumb": thumb,
            })
        episodes.sort(key=lambda e: e["episode"])
        return episodes

    @staticmethod
    def _extract_trailer(html):
        """Extract first YouTube trailer ID from detail page HTML."""
        m = re.search(r'data-ytlink="([^"]+)"', html)
        if m:
            return "plugin://plugin.video.youtube/play/?video_id=%s" % m.group(1)
        return ""

    @staticmethod
    def _extract_recommendations(html):
        """Extract recommendation cards from detail page HTML."""
        results = []
        rec_start = html.find("section-watch-recommendations")
        if rec_start < 0:
            return results
        # Section may not have </section> — use a generous slice
        rec_end = html.find("</section>", rec_start)
        if rec_end < 0:
            rec_end = min(rec_start + 50000, len(html))
        rec_html = html[rec_start:rec_end]
        seen = set()
        for match in re.finditer(
            r'data-href="(/watch/(movie|tv)/(\d+)/([^"]+))"', rec_html
        ):
            path, media_type, pid, slug = match.groups()
            if pid in seen:
                continue
            seen.add(pid)
            title = slug.replace("-", " ").title()
            # Try to get alt text or title from nearby img
            img_m = re.search(
                r'data-href="' + re.escape(path) + r'".*?alt="([^"]*)"',
                rec_html, re.DOTALL,
            )
            if img_m and img_m.group(1):
                title = img_m.group(1)
            poster_m = re.search(
                r'data-href="' + re.escape(path) + r'".*?src="([^"]+)"',
                rec_html, re.DOTALL,
            )
            poster = poster_m.group(1).replace("/w342/", "/w500/") if poster_m else ""
            results.append({
                "title": title, "pid": pid, "slug": slug,
                "media_type": media_type, "poster": poster,
                "year": "", "rating": "", "genres": "",
            })
        return results

    def get_show_info(self, pid, slug):
        html = self._fetch_show_html(pid, slug)
        info = {"title": slug.replace("-", " ").title(), "poster": "", "plot": "", "genres": "", "year": "", "rating": "", "trailer": ""}
        tm = re.search(r"<title>Watch (?:all Episodes of )?(.+?) \((\d{4})\)", html)
        if tm:
            info["title"] = tm.group(1)
            info["year"] = tm.group(2)
        img_m = re.search(r'src="(https://img\.xcdn\.to/t/p/w342[^"]+)"', html)
        if img_m:
            info["poster"] = img_m.group(1).replace("/w342/", "/w500/")
        rating_m = re.search(r'Rated:.*?([\d.]+)\s*out of 10', html)
        if rating_m:
            info["rating"] = rating_m.group(1)
        plot_m = re.search(r'watch-moreless-less"[^>]*>([^<]+)<', html)
        if plot_m:
            info["plot"] = plot_m.group(1).strip()
        genre_m = re.search(r'genres[^>]*>([^<]+)<', html)
        if genre_m:
            info["genres"] = genre_m.group(1).strip()
        info["trailer"] = self._extract_trailer(html)
        return info

    # ── movie detail ──────────────────────────────────────────────────

    def get_movie_info(self, pid, slug):
        key = "movie_%s" % pid
        cached = self._get_cached(key, SHOW_CACHE_TTL)
        if cached:
            return cached
        self._ensure_login()
        try:
            html = self._get(
                "%s/watch/movie/%s/%s" % (BASE, pid, slug),
                headers={"Referer": BASE + "/home"},
            )
        except Exception as e:
            _log("get_movie_info: network error: %s" % e)
            return {"plot": "", "genres": "", "year": "", "rating": "", "mpaa": "", "trailer": "", "recommendations": []}
        info = {"plot": "", "genres": "", "year": "", "rating": "", "mpaa": "", "trailer": "", "recommendations": []}
        tm = re.search(r"<title>Watch .+? \((\d{4})\)", html)
        if tm:
            info["year"] = tm.group(1)
        rating_m = re.search(r'Rated:.*?([\d.]+)\s*out of 10', html)
        if rating_m:
            info["rating"] = rating_m.group(1)
        plot_m = re.search(r'watch-moreless-less"[^>]*>([^<]+)<', html)
        if plot_m:
            info["plot"] = plot_m.group(1).strip()
        genre_m = re.search(r'genres[^>]*>([^<]+)<', html)
        if genre_m:
            info["genres"] = genre_m.group(1).strip()
        mpaa_m = re.search(r'fa-certificate[^>]*></span>\s*([A-Z][A-Z0-9-]*)', html)
        if mpaa_m:
            info["mpaa"] = mpaa_m.group(1).strip()
        info["trailer"] = self._extract_trailer(html)
        info["recommendations"] = self._extract_recommendations(html)
        return self._set_cached(key, info, SHOW_CACHE_TTL)

    def get_recommendations(self, pid, slug, media_type="movie"):
        """Get recommended titles from a movie/TV detail page."""
        if media_type == "movie":
            info = self.get_movie_info(pid, slug)
        else:
            html = self._fetch_show_html(pid, slug)
            return self._extract_recommendations(html)
        return info.get("recommendations", [])

    def get_trailer(self, pid, slug, media_type="movie"):
        """Get YouTube trailer URL from a movie/TV detail page."""
        if media_type == "movie":
            info = self.get_movie_info(pid, slug)
        else:
            info = self.get_show_info(pid, slug)
        return info.get("trailer", "")

    # ── resolve stream ────────────────────────────────────────────────

    def resolve_movie(self, pid, slug=""):
        return self._resolve("m", pid, slug=slug)

    def resolve_episode(self, pid, season, episode, slug=""):
        return self._resolve("e", pid, season, episode, slug=slug)

    def _resolve(self, kind, pid, season=None, episode=None, slug=""):
        _log("resolve: kind=%s pid=%s season=%s episode=%s" % (kind, pid, season, episode))
        self._ensure_login()
        # Visit the watch page first — CDN validates the token only after this.
        # The slug is required in the URL; without it the CDN rejects the stream.
        watch_type = "movie" if kind == "m" else "tv"
        watch_url = "%s/watch/%s/%s/%s" % (BASE, watch_type, pid, slug)
        try:
            page_html = self._get(watch_url, headers={"Referer": BASE + "/home"})
        except (urllib.error.URLError, OSError) as e:
            _log("resolve: watch page network error: %s" % e)
            return {"error": "network", "detail": str(e)}

        if self._looks_like_auth_failure(page_html):
            _log("resolve: auth failure on watch page, re-logging in")
            if not self._relogin():
                return {"error": "network", "detail": "Re-authentication failed"}
            try:
                self._get(watch_url, headers={"Referer": BASE + "/home"})
            except (urllib.error.URLError, OSError) as e:
                _log("resolve: watch page network error after relogin: %s" % e)
                return {"error": "network", "detail": str(e)}

        if kind == "e" and season is not None:
            url = "%s/%s/%s/%s/%s" % (VIDEO_AJAX, kind, pid, season, episode)
        else:
            url = "%s/%s/%s" % (VIDEO_AJAX, kind, pid)

        # Fetch stream data — retry once on auth failure
        for attempt in range(2):
            try:
                html = self._get(
                    url,
                    params={"_": int(time.time() * 1000)},
                    headers={
                        "Referer": watch_url,
                        "X-Requested-With": "XMLHttpRequest",
                    },
                )
            except (urllib.error.URLError, OSError) as e:
                _log("resolve: AJAX network error: %s" % e)
                return {"error": "network", "detail": str(e)}
            if not html:
                _log("resolve: empty response from AJAX")
                return {"error": "empty", "detail": "Server returned empty response"}
            try:
                decoded = self._decode_video_response(html)
                result = json.loads(decoded)
                if not isinstance(result, dict) or not isinstance(result.get("file"), str):
                    # Could be auth failure disguised as bad data — retry once
                    if attempt == 0:
                        _log("resolve: invalid stream data, retrying after relogin")
                        if self._relogin():
                            try:
                                self._get(watch_url, headers={"Referer": BASE + "/home"})
                            except (urllib.error.URLError, OSError):
                                pass
                            continue
                    _log("resolve: invalid stream data structure")
                    return {"error": "decode", "detail": "Invalid stream data"}
                if not isinstance(result.get("tracks"), list):
                    result["tracks"] = []
                _log("resolve: success, got m3u8 URL")
                return result
            except Exception as e:
                if attempt == 0:
                    _log("resolve: decode error on attempt 1, retrying: %s" % e)
                    if self._relogin():
                        try:
                            self._get(watch_url, headers={"Referer": BASE + "/home"})
                        except (urllib.error.URLError, OSError):
                            pass
                        continue
                _log("resolve: decode error: %s" % e)
                return {"error": "decode", "detail": str(e)}
        return {"error": "decode", "detail": "Failed after retry"}
