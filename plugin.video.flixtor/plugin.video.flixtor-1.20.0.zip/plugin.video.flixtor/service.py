"""Flixtor background service — tracks playback position and installs custom keymaps."""

import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from resources.lib.watchhistory import WatchHistory

NEXT_EPISODE_THRESHOLD = 0.97
NEXT_EPISODE_COUNTDOWN_SECONDS = 10

# Bundled third-party API keys seeded into TMDb Helper on first run so every
# Flixtor install gets the full Arctic Horizon 2 rating strip (IMDb, Metacritic,
# Rotten Tomatoes, Letterboxd, Trakt) without per-user setup. Users who already
# have their own keys in TMDb Helper keep them — we only seed empty slots.
#
# Free-tier limits apply per key: OMDb 1000/day, MDBList 1000/day. Fine for a
# small private circle; at scale the cap is hit. Users can override anytime by
# entering their own key in TMDb Helper's settings — the seed only runs when
# the target slot is blank.
#
# MDBList is the richer aggregator (IMDb + TMDb + Trakt + Letterboxd + RT +
# Metacritic + MAL in one call). Get one at https://mdblist.com/preferences/
# (requires a Trakt.tv account to sign in). OMDb at https://www.omdbapi.com/
BUNDLED_OMDB_APIKEY = ""
BUNDLED_MDBLIST_APIKEY = ""

KEYMAP_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<keymap>
  <FullscreenVideo>
    <keyboard>
      <backspace>Stop</backspace>
      <browser_back>Stop</browser_back>
      <escape>Stop</escape>
      <down>OSD</down>
    </keyboard>
    <remote>
      <back>Stop</back>
      <down>OSD</down>
    </remote>
  </FullscreenVideo>
  <FullscreenInfo>
    <keyboard>
      <backspace>Stop</backspace>
      <browser_back>Stop</browser_back>
      <escape>Stop</escape>
    </keyboard>
    <remote>
      <back>Stop</back>
    </remote>
  </FullscreenInfo>
</keymap>
"""


TMDB_PLAYER_JSON = """\
{
    "name": "Flixtor",
    "plugin": "plugin.video.flixtor",
    "priority": 10,
    "play_movie": "plugin://plugin.video.flixtor/?action=search_and_play&media_type=movie&title={title}&year={year}",
    "play_episode": "plugin://plugin.video.flixtor/?action=search_and_play&media_type=tv&title={title}&year={year}"
}
"""


def _install_keymap():
    """Install custom keymap for Fire TV remote during video playback."""
    profile = xbmcvfs.translatePath("special://profile/keymaps/")
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    keymap_path = os.path.join(profile, "flixtor.xml")
    if not os.path.exists(keymap_path):
        with open(keymap_path, "w") as f:
            f.write(KEYMAP_XML)
        xbmc.executebuiltin("Action(reloadkeymaps)")
        xbmc.log("FLIXTOR: installed custom keymap", xbmc.LOGINFO)


def _install_tmdb_player():
    """Install TMDb Helper player file so Similar/Recommended titles route to Flixtor."""
    players_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.themoviedb.helper/players/"
    )
    if not xbmcvfs.exists(players_dir):
        xbmcvfs.mkdirs(players_dir)
    player_path = os.path.join(players_dir, "flixtor.json")
    # Always overwrite to keep in sync with addon version
    with open(player_path, "w") as f:
        f.write(TMDB_PLAYER_JSON)
    xbmc.log("FLIXTOR: installed TMDb Helper player file", xbmc.LOGINFO)


def _seed_tmdb_helper_keys():
    """Populate TMDb Helper's OMDb and MDBList key slots with bundled values,
    but only for slots the user has left empty. This lights up the full AH2
    rating strip out-of-the-box without making every user register accounts."""
    try:
        tmdb_addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
    except RuntimeError:
        xbmc.log("FLIXTOR: TMDb Helper not installed — skipping rating-key seed",
                 xbmc.LOGINFO)
        return

    for setting_id, bundled in (
        ("omdb_apikey", BUNDLED_OMDB_APIKEY),
        ("mdblist_apikey", BUNDLED_MDBLIST_APIKEY),
    ):
        if not bundled:
            continue
        existing = (tmdb_addon.getSetting(setting_id) or "").strip()
        if existing:
            continue
        try:
            tmdb_addon.setSetting(setting_id, bundled)
            xbmc.log("FLIXTOR: seeded TMDb Helper %s" % setting_id, xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("FLIXTOR: failed to seed %s: %s" % (setting_id, exc),
                     xbmc.LOGINFO)


class FlixtorPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._history = WatchHistory()
        self._tracking = False
        self._metadata = None
        self._last_time = 0.0
        self._total_time = 0.0
        self._next_episode = None
        self._auto_play_next_enabled = False
        self._countdown_shown = False

    def onAVStarted(self):
        meta = self._history.get_now_playing()
        if not meta:
            self._tracking = False
            return
        self._history.clear_now_playing()
        self._tracking = True
        self._metadata = meta
        self._next_episode = meta.get("next_episode")
        self._auto_play_next_enabled = bool(meta.get("auto_play_next"))
        self._countdown_shown = False
        seek_to = meta.get("seek_on_start", 0.0)
        xbmc.log("FLIXTOR: onAVStarted: pid=%s title=%s seek=%.1f next=%s" %
                 (meta.get("pid"), meta.get("title"), seek_to,
                  bool(self._next_episode)), xbmc.LOGINFO)

        try:
            self._total_time = self.getTotalTime()
        except RuntimeError:
            self._total_time = 0.0

        if seek_to > 0:
            xbmc.sleep(500)
            try:
                self.seekTime(seek_to)
            except RuntimeError:
                xbmc.log("FLIXTOR: onAVStarted: seek failed", xbmc.LOGINFO)

        self._apply_subtitle_preferences(meta)

    def _apply_subtitle_preferences(self, meta):
        """Honor the user's subtitles_default and subtitles_language settings.

        Kodi's own global subtitle preference can otherwise auto-show subtitles
        (always-on bug) and pick whichever language Kodi's locale matches first
        (wrong-language bug). We explicitly select the preferred ISO stream and
        force visibility on/off to override Kodi's defaults. External subs load
        asynchronously, so we wait briefly for getAvailableSubtitleStreams() to
        populate before selecting.
        """
        preferred_iso = (meta.get("preferred_subtitle_iso") or "").lower()
        subtitles_on = bool(meta.get("subtitles_default"))

        # Wait up to ~2s for Kodi to load external subtitle streams.
        streams = []
        for _ in range(10):
            try:
                streams = self.getAvailableSubtitleStreams() or []
            except Exception:
                streams = []
            if streams:
                break
            xbmc.sleep(200)

        if preferred_iso and streams:
            # Prefer exact ISO 639-2 match, then 2-letter prefix as a fallback
            # since Kodi may normalize codes inconsistently across versions.
            chosen = -1
            for i, code in enumerate(streams):
                if (code or "").lower() == preferred_iso:
                    chosen = i
                    break
            if chosen < 0:
                pref2 = preferred_iso[:2]
                for i, code in enumerate(streams):
                    if (code or "").lower().startswith(pref2):
                        chosen = i
                        break
            if chosen >= 0:
                try:
                    self.setSubtitleStream(chosen)
                    xbmc.log("FLIXTOR: subtitle stream set to %d (%s)" %
                             (chosen, streams[chosen]), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("FLIXTOR: setSubtitleStream failed: %s" % e, xbmc.LOGINFO)
            else:
                xbmc.log("FLIXTOR: preferred subtitle %s not found in %s" %
                         (preferred_iso, streams), xbmc.LOGINFO)

        # Always set visibility explicitly — Kodi's global subtitle preference
        # otherwise overrides our setting.
        try:
            self.showSubtitles(subtitles_on)
            xbmc.log("FLIXTOR: subtitles %s by user setting" %
                     ("enabled" if subtitles_on else "disabled"), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log("FLIXTOR: showSubtitles failed: %s" % e, xbmc.LOGINFO)

    def onPlayBackStopped(self):
        self._save_position(completed=False)

    def onPlayBackEnded(self):
        self._save_position(completed=True)

    def onPlayBackError(self):
        self._save_position(completed=False)

    def _save_position(self, completed=False):
        if not self._tracking or not self._metadata:
            return
        meta = self._metadata.copy()
        meta.pop("seek_on_start", None)
        meta.pop("next_episode", None)
        meta.pop("auto_play_next", None)
        if completed:
            meta["resume_seconds"] = 0.0
        else:
            meta["resume_seconds"] = self._last_time
        meta["total_seconds"] = self._total_time
        xbmc.log("FLIXTOR: save_position: pid=%s resume=%.1f total=%.1f completed=%s" %
                 (meta.get("pid"), meta["resume_seconds"], meta["total_seconds"], completed),
                 xbmc.LOGINFO)
        self._history.update_position(meta)
        self._tracking = False
        self._metadata = None
        self._next_episode = None
        self._auto_play_next_enabled = False
        self._countdown_shown = False

    def poll_position(self):
        if not self._tracking:
            return
        try:
            self._last_time = self.getTime()
            self._total_time = self.getTotalTime()
        except RuntimeError:
            return
        if (
            self._auto_play_next_enabled
            and self._next_episode
            and not self._countdown_shown
            and self._total_time > 0
            and self._last_time / self._total_time >= NEXT_EPISODE_THRESHOLD
        ):
            self._countdown_shown = True
            self._show_next_episode_countdown()

    def _show_next_episode_countdown(self):
        """Block for up to 10s with a cancelable dialog; on completion chain-play the next episode."""
        ne = self._next_episode or {}
        season = ne.get("season")
        episode = ne.get("episode")
        heading = "Up next"
        subtitle = "S%02dE%02d — %s" % (
            int(season) if season is not None else 0,
            int(episode) if episode is not None else 0,
            ne.get("title", ""),
        )
        dialog = xbmcgui.DialogProgress()
        dialog.create(heading, subtitle)
        cancelled = False
        for remaining in range(NEXT_EPISODE_COUNTDOWN_SECONDS, 0, -1):
            if dialog.iscanceled():
                cancelled = True
                break
            pct = int((NEXT_EPISODE_COUNTDOWN_SECONDS - remaining) * 100 / NEXT_EPISODE_COUNTDOWN_SECONDS)
            dialog.update(pct, "%s\nStarting in %ds..." % (subtitle, remaining))
            xbmc.sleep(1000)
        dialog.close()
        if cancelled:
            xbmc.log("FLIXTOR: next-episode countdown cancelled by user", xbmc.LOGINFO)
            return
        params = {
            "action": "start_episode",
            "pid": ne.get("pid", ""),
            "slug": ne.get("slug", ""),
            "season": season,
            "episode": episode,
            "title": ne.get("title", ""),
            "poster": ne.get("poster", ""),
        }
        url = "plugin://plugin.video.flixtor/?" + urllib.parse.urlencode(
            {k: ("" if v is None else v) for k, v in params.items()}
        )
        xbmc.log("FLIXTOR: chain-playing next episode: %s" % url, xbmc.LOGINFO)
        xbmc.executebuiltin("PlayMedia(%s)" % url)


def run():
    monitor = xbmc.Monitor()
    player = FlixtorPlayer()

    _install_keymap()
    _install_tmdb_player()
    _seed_tmdb_helper_keys()

    # Auto-launch Flixtor on Kodi startup (configurable via settings)
    addon = xbmcaddon.Addon()
    if addon.getSetting("auto_launch") != "false":
        xbmc.sleep(2000)
        xbmc.executebuiltin("ActivateWindow(videos,plugin://plugin.video.flixtor/)")
    else:
        xbmc.log("FLIXTOR: auto-launch disabled in settings", xbmc.LOGINFO)

    xbmc.log("FLIXTOR: service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        player.poll_position()
        if monitor.waitForAbort(5):
            break

    xbmc.log("FLIXTOR: service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    run()
